﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FileUpload
{
    public class Logger
    {
        public static ILog Write = LogManager.GetLogger(Startup.repository.Name, typeof(HttpGlobalExceptionFilter));//日志记录
    }
}
