﻿using NPOI.HSSF.UserModel;
using NPOI.SS.Formula.Functions;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AIStudio.Core
{
    public static class NPOIBusHelper
    {
        /// <summary>
        /// Excel导入成Datable
        /// </summary>
        /// <param name="file">导入路径(包含文件名与扩展名)</param>
        /// <returns></returns>
        public static DataTable ExcelToTable(string file)
        {
            DataTable dt = new DataTable();

            IWorkbook workbook = null;
            try
            {
                workbook = NPOIHelper.GetWorkbook(file);

                //只考虑Sheet1的，不支持多sheet
                var worksheet = workbook.GetSheetAt(0);

                //表头  t.Columns["TaskState"].ColumnName = "工时状态"
                IRow header = worksheet.GetRow(worksheet.FirstRowNum);
                List<int> columns = new List<int>();
                for (int i = 0; i < header.LastCellNum; i++)
                {
                    

                    object obj = NPOIHelper.GetValueType(header.GetCell(i));

                    if (obj == null || obj.ToString() == string.Empty)
                    {
                        dt.Columns.Add(new DataColumn("Columns" + i.ToString()));
                    }
                    else
                        dt.Columns.Add(new DataColumn(obj.ToString()));
                    columns.Add(i);
                }
                //数据  
                for (int i = worksheet.FirstRowNum + 1; i <= worksheet.LastRowNum; i++)
                {
                    DataRow dr = dt.NewRow();
                    bool hasValue = false;
                    foreach (int j in columns)
                    {
                        if (worksheet.GetRow(i).GetCell(j).CellType == CellType.Numeric && DateUtil.IsCellDateFormatted(worksheet.GetRow(i).GetCell(j)))
                        {
                            dr[j] = worksheet.GetRow(i).GetCell(j).DateCellValue;
                        }
                        else
                        {
                            dr[j] = NPOIHelper.GetValueType(worksheet.GetRow(i).GetCell(j));
                        }
                        if (dr[j] != null && dr[j].ToString() != string.Empty)
                        {
                            hasValue = true;
                        }
                    }
                    if (hasValue)
                    {
                        dt.Rows.Add(dr);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (workbook != null)
                {
                    workbook.Close();
                }
            }

            return dt;
        }


        public static DataTable ImportExcelFile(string filePath)
        {
            XSSFWorkbook xssfworkbook;

            #region//初始化信息 
            try
            {
                using (FileStream file = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                {
                    xssfworkbook = new XSSFWorkbook(file);
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            #endregion

            NPOI.SS.UserModel.ISheet sheet = xssfworkbook.GetSheetAt(0);
            
            System.Collections.IEnumerator rows = sheet.GetRowEnumerator();
            
            DataTable dt = new DataTable();
            for (int j = 0; j < (sheet.GetRow(0).LastCellNum); j++)
            {
                dt.Columns.Add(Convert.ToChar(((int)'A') + j).ToString());
            }
            
            

            var events = new List<ManualResetEvent>();

            while (rows.MoveNext())
            {

                

               
                    var resetEvent = new ManualResetEvent(false);
                    ThreadPool.QueueUserWorkItem(
                        arg =>
                        {
                            XSSFRow row = (XSSFRow)rows.Current;
                            DataRow dr = dt.NewRow();
                            for (int i = 0; i < row.LastCellNum; i++)
                            {
                                NPOI.SS.UserModel.ICell cell = row.GetCell(i);
                                if (cell == null)
                                {
                                    dr[i] = null;
                                }
                                else
                                {
                                    dr[i] = cell.ToString();
                                }
                            }
                            dt.Rows.Add(dr);
                            resetEvent.Set();
                        });
                    events.Add(resetEvent);
                
               

            
            }

            WaitHandle.WaitAll(events.ToArray());

            return dt;
        }

        /// <summary>
        /// Excel导入成Datable
        /// </summary>
        /// <param name="file">导入路径(包含文件名与扩展名)</param>
        /// <returns></returns>
        public static DataTable ExcelToTable(string file,Dictionary<string,string> dic)
        {
            DataTable dt = new DataTable();

            IWorkbook workbook = null;
            try
            {
                workbook = NPOIHelper.GetWorkbook(file);

                //只考虑Sheet1的，不支持多sheet
                var worksheet = workbook.GetSheetAt(0);

                //表头  t.Columns["TaskState"].ColumnName = "工时状态"
                IRow header = worksheet.GetRow(worksheet.FirstRowNum);
                List<int> columns = new List<int>();
                for (int i = 0; i < header.LastCellNum; i++)
                {


                    object obj = NPOIHelper.GetValueType(header.GetCell(i));

                    if (obj == null || obj.ToString() == string.Empty)
                    {
                        dt.Columns.Add(new DataColumn("Columns" + i.ToString()));
                    }
                    else
                    {
                        string tempStr = obj.ToString();
                        
                        string tempColunName = dic[tempStr].ToString();
                        if (string.IsNullOrEmpty(tempColunName))
                        {
                             dt.Columns.Add(new DataColumn(obj.ToString()));
                        }
                        else
                        {
                            dt.Columns.Add(new DataColumn(tempColunName));
                        }
                       
                    }
                    columns.Add(i);
                }

                int singleCount = worksheet.LastRowNum / 10;
                int lastCountAdd =   worksheet.LastRowNum % 10;

                //var events = new List<ManualResetEvent>();

                List<Task> TaskList = new List<Task>();
                List<DataTable> dataTableList = new List<DataTable>();
                int c = 0;
                for (int a = 1;a<=10;a++)
                {
                    
                    int startIndex = worksheet.FirstRowNum + 1 + c;
                    int endIndex = startIndex + singleCount;
                    if (a == 10)
                    {
                        endIndex += lastCountAdd-1;
                    }

                    //  var resetEvent = new ManualResetEvent(false);
                    //ThreadPool.QueueUserWorkItem(
                    //    arg =>
                    //    {


                    DataTable tempDataTableModel = dt.Clone();
                 
                    TaskList.Add(Task.Factory.StartNew(() =>  {
                        DataTable tempDataTable = tempDataTableModel.Clone();


                        for (int i = startIndex; i <= endIndex; i++)
                        {
                            DataRow dr = tempDataTable.NewRow();
                            bool hasValue = false;
                            foreach (int j in columns)
                            {
                                if (worksheet.GetRow(i).GetCell(j).CellType == CellType.Numeric && DateUtil.IsCellDateFormatted(worksheet.GetRow(i).GetCell(j)))
                                {
                                    dr[j] = worksheet.GetRow(i).GetCell(j).DateCellValue;
                                }
                                else
                                {
                                    dr[j] = NPOIHelper.GetValueType(worksheet.GetRow(i).GetCell(j));
                                }
                                if (dr[j] != null && dr[j].ToString() != string.Empty)
                                {
                                    hasValue = true;
                                }
                            }
                            if (hasValue)
                            {
                                tempDataTable.Rows.Add(dr);
                            }
                        }

                        //dt.Rows.Add(tempDataTable.Rows);
                        dataTableList.Add(tempDataTable);
                       // dt.Merge(tempDataTable);
                       // tempDataTable.Clear();
                       // tempDataTable.Dispose();
                    }));
                   
                         //   resetEvent.Set();
                      //  });
                    //events.Add(resetEvent);


                    c += singleCount;
                }

                Task.WaitAll(TaskList.ToArray());
                foreach (var item in dataTableList)
                { 
                  dt.Merge(item);
                item.Clear();
                item.Dispose();
                }
                 

              //  WaitHandle.WaitAll(events.ToArray());



                //数据  
                //for (int i = worksheet.FirstRowNum + 1; i <= worksheet.LastRowNum; i++)
                //{
                //    DataRow dr = dt.NewRow();
                //    bool hasValue = false;
                //    foreach (int j in columns)
                //    {
                //        if (worksheet.GetRow(i).GetCell(j).CellType == CellType.Numeric && DateUtil.IsCellDateFormatted(worksheet.GetRow(i).GetCell(j)))
                //        {
                //            dr[j] = worksheet.GetRow(i).GetCell(j).DateCellValue;
                //        }
                //        else
                //        {
                //            dr[j] = NPOIHelper.GetValueType(worksheet.GetRow(i).GetCell(j));
                //        }
                //        if (dr[j] != null && dr[j].ToString() != string.Empty)
                //        {
                //            hasValue = true;
                //        }
                //    }
                //    if (hasValue)
                //    {
                //        dt.Rows.Add(dr);
                //    }
                //}
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (workbook != null)
                {
                    workbook.Close();
                }
            }

            return dt;
        }



        /// <summary>
        /// Datable导出成Excel
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="file">导出路径(包括文件名与扩展名)</param>
        public static void TableToExcel(DataTable dt, string file, Action<IWorkbook, ISheet> action)
        {
            try
            {
                IWorkbook workbook = NPOIHelper.CreateWorkbook(file);
                //添加一个sheet页
                ISheet workSheet = workbook.CreateSheet(string.IsNullOrEmpty(dt.TableName) ? "Sheet1" : dt.TableName);

                //表头  
                IRow headerRow = workSheet.CreateRow(0);
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    NPOIHelper.SetCell(headerRow, i, dt.Columns[i].ColumnName);
                }

                //数据  
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    IRow cellRow = workSheet.CreateRow(i + 1);
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        NPOIHelper.SetCell(cellRow, j, dt.Rows[i][j]);
                        if (dt.Rows[i][j].GetType().ToString() == "System.DateTime")
                        {
                            var cellStyle = NPOIHelper.CreateDataFormatCellStyle(workbook, null, "yyyy-MM-dd HH:mm:ss");
                            cellRow.GetCell(j).CellStyle = cellStyle;
                        }
                    }
                }

                if (action != null)
                {
                    action(workbook, workSheet);
                }

                NPOIHelper.SaveWorkbook(file, workbook);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Datable新增到Excel
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="file"></param>
        public static void AppendTableToExcel(DataTable dt, string file, Action<IWorkbook, ISheet> action)
        {
            try
            {
                IWorkbook workbook = null;

                string fileExt = Path.GetExtension(file).ToLower();
                bool IsNew = !File.Exists(file);
                if (!IsNew)
                {
                    workbook = NPOIHelper.GetWorkbook(file);
                }
                else
                {
                    workbook = NPOIHelper.CreateWorkbook(file);
                }

                ISheet workSheet = null;

                int num = 0;
                if (IsNew)
                {
                    workSheet = workbook.CreateSheet(string.IsNullOrEmpty(dt.TableName) ? "Sheet1" : dt.TableName);
                    //表头  
                    IRow headerRow = workSheet.CreateRow(0);
                    for (int i = 0; i < dt.Columns.Count; i++)
                    {
                        NPOIHelper.SetCell(headerRow, i, dt.Columns[i].ColumnName);
                    }
                }
                else
                {
                    workSheet = workbook.GetSheetAt(0);

                }

                num = workSheet.LastRowNum + 1;
                //数据  
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    IRow cellRow = workSheet.CreateRow(i + num);
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        NPOIHelper.SetCell(cellRow, j, dt.Rows[i][j]);
                        if (dt.Rows[i][j].GetType().ToString() == "System.DateTime")
                        {
                            var cellStyle = NPOIHelper.CreateDataFormatCellStyle(workbook, null, DateTimeStringFormat);
                            cellRow.GetCell(j).CellStyle = cellStyle;
                        }
                    }
                }

                if (action != null)
                {
                    action(workbook, workSheet);
                }

                NPOIHelper.SaveWorkbook(file, workbook, IsNew);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<T> ExcelToClass<T>(string file) where T : new()
        {
            DataTable dt = ExcelToTable(file);

            return ModelHandler<T>.FillModel(dt);
        }

        public static void ExcelToList(string fileDir)
        {
            FileStream fs = new FileStream(fileDir, FileMode.Open, FileAccess.Read,FileShare.ReadWrite);//创建一个文件流 参数（文件位置,打开此文件（如果没有会抛异常），文件访问权限（只读））
            StreamReader sr = new StreamReader(fs, Encoding.Default);//创建一个txt读取流，从字节流中读取字符 参数（流）
           
                try
                {
                    Stopwatch sw = new Stopwatch();//计时器
                    sw.Start();//开始计时
                    int num = 0;//计算总条数
                             　　//死循环，由于不知道到底有几行，跳出时机在循环体内部判断
                    while (true)
                    {
                        var arrList = new List<string>();//存放读取的数据
                        while (true)
                        {
                            var str = sr.ReadLine();//读取一行内容返回改行的字符串（一个换行符一行），fs有一个fs.position属性（流的位置），该属性在进行任何读取操作时会根据读取的实际情况进行移动，当该位置到达流的末尾时，此方法返回null，该位置也可手动设置fs.position=xxx(long类型)
                            if (str == null)
                                break;//跳出时机就是读完的时候
                            arrList.Add(str);
                            if (arrList.Count > 10000)
                                break;//该跳出用于入库，博主这里10000条入一次库

                        
                        }
                        if (arrList.Count == 0)
                            break;//当存放数据的list条数为0时，循环就可以结束了
                        num += arrList.Count();
                   //     ResBase res = Insert1306(arrList);//该方法就是具体的入库操作了，可根据自己的实际情况去写
                        //if (res.ErrCode == -1)
                        //{
                        //    MessageBox.Show(res.ErrMsg);
                        //    return;
                        //}
                    }
                  
                    fs.Close();//释放文件流
                    sw.Stop();//停止计时
                  
                    return;
                }
                catch (Exception e)
                {
                  
                }
            
        }

        /// <summary>
        /// Datable导出成Excel
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="file">导出路径(包括文件名与扩展名)</param>
        public static void ClassToExcel<T>(List<T> list, string file, Action<IWorkbook, ISheet> action) where T : new()
        {
            DataTable dt = ModelHandler<T>.FillDataTable(list);

            TableToExcel(dt, file, action);
        }

        /// <summary>
        /// Datable新增到Excel
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="file"></param>
        public static void AppendClassToExcel<T>(List<T> list, string file, Action<IWorkbook, ISheet> action = null) where T : new()
        {
            DataTable dt = ModelHandler<T>.FillDataTable(list);
            AppendTableToExcel(dt, file, action);
        }

        public static string DateTimeStringFormat {get;set;}="yyyy-MM-dd HH:mm:ss";
    }
}
