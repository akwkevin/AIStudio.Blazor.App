﻿using AIStudio.Core.Models;
using AIStudio.Core.Validation;
using AIStudio.Wpf.Entity.Models;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;

namespace AIStudio.Wpf.Entity.DTOModels
{
    public partial class CustomerRule_AddFanLiDTO : CustomerRule_AddFanLi, INotifyPropertyChanged, IIsChecked
    {
        private bool? _isChecked = false;
        public bool? IsChecked
        {
            get { return _isChecked; }
            set
            {
                if (value != _isChecked)
                {
                    _isChecked = value;
                    RaisePropertyChanged("IsChecked");
                }
            }
        }      

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void RaisePropertyChanged(string propertyName)
        {
            //this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }


        public string WeightOneStr
        {
            get
            {
                if (MinValueOne.HasValue && MaxValueOne.HasValue)
                {
                    return MinValueOne.Value.ToString() + "<=当前重量<=" + MaxValueOne.Value.ToString() + ",加返:" + AddAmountOne.Value.ToString();
                }
                else
                {
                    return "未设置重量段条件";
                }
            }
        }



        public string WeightTwoStr
        {
            get
            {
                if (MinValueTwo.HasValue && MaxValueTwo.HasValue)
                {
                    return MinValueTwo.Value.ToString() + "<=当前重量<=" + MaxValueTwo.Value.ToString() + ",加返:" + AddAmountTwo.Value.ToString();
                }
                else
                {
                    return "未设置重量段条件";
                }
            }
        }



        public string WeightThreeStr
        {
            get
            {
                if (MinValueThree.HasValue && MaxValueThree.HasValue)
                {
                    return MinValueThree.Value.ToString() + "<=当前重量<=" + MaxValueThree.Value.ToString() + ",加返:" + AddAmountThree.Value.ToString();
                }
                else
                {
                    return "未设置重量段条件";
                }
            }


        }


    
    }

    public partial class CustomerRule_AddFanLiDTO : IDataErrorInfo
    {
        [Browsable(false)]
        public string this[string columnName]
        {
            get
            {
                List<ValidationResult> validationResults = new List<ValidationResult>();

                bool result = Validator.TryValidateProperty(
                    GetType().GetProperty(columnName).GetValue(this),
                    new ValidationContext(this)
                    {
                        MemberName = columnName
                    },
                    validationResults);

                if (result)
                    return null;

                return validationResults.First().ErrorMessage;
            }
        }

        [Browsable(false)]
        public string Error
        {
            get
            {
                ICollection<ValidationResult> results;
                this.Validate(out results);

                return results.FirstOrDefault()?.ErrorMessage;
            }
        }
    }   
}
