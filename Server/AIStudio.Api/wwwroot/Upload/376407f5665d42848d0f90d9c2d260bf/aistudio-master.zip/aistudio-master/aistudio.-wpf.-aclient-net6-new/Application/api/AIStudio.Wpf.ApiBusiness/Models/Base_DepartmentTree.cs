﻿using AIStudio.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIStudio.Wpf.ApiBusiness.Models
{
    public class Base_DepartmentTree : TreeModel<Base_DepartmentTree>
    {
        public string? Name { get; set; }
        public string? ParentIds { get; set; }
    }
}
