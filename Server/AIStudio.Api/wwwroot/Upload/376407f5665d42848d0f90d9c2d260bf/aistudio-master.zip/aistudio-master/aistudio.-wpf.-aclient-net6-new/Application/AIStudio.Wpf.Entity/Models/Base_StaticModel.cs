﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace AIStudio.Wpf.Entity.Models
{
    public class Base_StaticModel
    {

        /// <summary>
        ///开始时间
        /// </summary>
        public DateTime? StartTime { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        public DateTime? EndTime { get; set; }

        /// <summary>
        /// 客户名称
        /// </summary>
        public string Customer { get; set; }


        /// <summary>
        /// 客户类型
        /// </summary>
        public string CustomerTypeStr { get; set; }


        /// <summary>
        /// 政策备注
        /// </summary>
        public string RuleRemark { get; set; }

        /// <summary>
        /// 客户充单价
        /// </summary>
        public decimal? Customer_CDJ { get; set; }

        /// <summary>
        /// 客户返利
        /// </summary>
        public decimal? Customer_FanLi { get; set; }

        /// <summary>
        /// 客户底价
        /// </summary>
        public decimal? Customer_DJ { get; set; }

        /// <summary>
        /// 操作人标识
        /// </summary>
        public string UserSign { get; set; }


        /// <summary>
        /// 站点
        /// </summary>
        public string KuaiDi { get; set; }

        /// <summary>
        /// 加返
        /// </summary>
        public decimal? AddFanLi { get; set; }

        /// <summary>
        /// 总票数
        /// </summary>
        public int AllOrderCount { get; set; }


        /// <summary>
        /// 均重票数
        /// </summary>
        public int JZ_OrderCount { get; set; }


        /// <summary>
        /// 均重
        /// </summary>
        public decimal? JZ_Weight { get; set; }

        public decimal? junfei { get; set; }

        /// <summary>
        /// 直营客户均费参考
        /// </summary>
        public decimal? ZY_JF { get {
                if (junfei.HasValue&&junfei.Value>=0)
                {
                    if (CustomerTypeStr=="业务")
                    {
                        return 0;
                    }
                    else
                    {
                        return junfei.Value;
                    }
                    
                }
                else
                {
                    return 0;
                }
            } }


        /// <summary>
        /// 业务客户均费参考
        /// </summary>
        public decimal? YW_JF { get {
                if (junfei.HasValue&&junfei.Value>=0)
                {
                    if (CustomerTypeStr=="业务")
                    {
                         return junfei.Value;
                    }
                    else
                    {
                        return 0;
                    }

                }
                else
                {
                    return 0;
                }
            } }


        /// <summary>
        /// 单票均费成本
        /// </summary>
        public decimal? DP_JF { get; set; }


        /// <summary>
        /// 重量段加收票数-1.01-1.5
        /// </summary>
        public int AddPay_Count1 { get; set; }

        /// <summary>
        /// 重量段加收金额-1.01-1.5
        /// </summary>
        public decimal? AddPay_Amount1 { get; set; }

        /// <summary>
        /// 重量段加收票数-1.51-2
        /// </summary>
        public int AddPay_Count2 { get; set; }

        /// <summary>
        /// 重量段加收金额-1.51-2
        /// </summary>
        public decimal? AddPay_Amount2 { get; set; }

        public int AddPay_Count3 { get; set; }

        public decimal? AddPay_Amount3 { get; set; }

        public int AddPay_Count4 { get; set; }

        public decimal? AddPay_Amount4 { get; set; }

        /// <summary>
        ///正常超3KG 票数
        /// </summary>
        public int ZC_C3_Count { get; set; }


        /// <summary>
        /// 正常超3KG金额
        /// </summary>
        public decimal? ZC_C3_Amount { get; set; }


        /// <summary>
        /// 后2小于等于0.5KG票数
        /// </summary>
        public int H2_Count { get; set; }

        /// <summary>
        /// 后2小于等于0.5KG金额
        /// </summary>
        public decimal? H2_Amount { get; set; }

        /// <summary>
        /// 后2 0.51-3KG 票数
        /// </summary>
        public int H2_Count2 { get; set; }

        /// <summary>
        /// 后2 0.51-3KG 金额
        /// </summary>
        public decimal? H2_Amount2 { get; set; }

        /// <summary>
        /// 后2大于3KG票数
        /// </summary>
        public int H2_Count3 { get; set; }

        /// <summary>
        /// 后2大于3KG金额
        /// </summary>
        public decimal? H2_Amount3 { get; set; }


        /// <summary>
        /// 出港票数
        /// </summary>
        public int CG_Count { get; set; }


        /// <summary>
        /// 出港费用
        /// </summary>
        public decimal? CG_Amount { get; set; }

        /// <summary>
        /// 后2统100结果（统的过，统不过）
        /// </summary>
        public string H2_T100 { get; set; }

        /// <summary>
        /// 合计应收
        /// </summary>
        public decimal? AllAmount { get; set; }


        /// <summary>
        /// 单票成本
        /// </summary>
        public decimal? DP_Amount { get; set; }

        /// <summary>
        /// 预计返利
        /// </summary>
        public decimal? YJ_FanLi { get; set; }

        /// <summary>
        /// 利润参考
        /// </summary>
        public decimal? LR_CK { get; set; }

        /// <summary>
        /// 费用预存
        /// </summary>
        public decimal? YC_FY { get; set; }


        /// <summary>
        /// 直营利润参考
        /// </summary>
        public decimal? ZY_LR_CK { get {
                if (CustomerTypeStr == "直营")
                {
                    return LR_CK.Value - AllAmount;
                }
                else
                {
                    return 0;
                }
            } }
        /// <summary>
        /// 出货利润参考
        /// </summary>
        public decimal? CH_LR_CK { get {
                return LR_CK;
            } }


        /// <summary>
        /// 实际利润参考
        /// </summary>
        public decimal? SJ_LR_CK { get {
                return LR_CK - AllAmount;
            } }

        /// <summary>
        /// 后2统不过应收
        /// </summary>
        public decimal? H2_T100_Amount { get; set; }

        public string Id { get; set; }


        /// <summary>
        /// 对应均重规则的-均重平均值
        /// </summary>
        public decimal? JZ_PJ { get; set; }
    }
}
