﻿using Prism.Events;

namespace AIStudio.Wpf.PrismAvalonExtensions.Events
{
    public class SelectedDocumentEvent : PubSubEvent<string>
    {
    }
}
