﻿using AIStudio.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIStudio.Wpf.Entity.TreeModel
{
    public class Base_DictionaryTree : TreeModel<Base_DictionaryTree>
    {
        public DictionaryType Type { get; set; }
        public ControlType ControlType { get; set; }
        public int Sort { get; set; }

        public string TypeText { get => ((DictionaryType)Type).ToString(); }
        public string? Code { get; set; }

        public string? Remark { get; set; }

    }

    public enum DictionaryType
    {
        字典项 = 0,
        数据集 = 1,
    }
}
