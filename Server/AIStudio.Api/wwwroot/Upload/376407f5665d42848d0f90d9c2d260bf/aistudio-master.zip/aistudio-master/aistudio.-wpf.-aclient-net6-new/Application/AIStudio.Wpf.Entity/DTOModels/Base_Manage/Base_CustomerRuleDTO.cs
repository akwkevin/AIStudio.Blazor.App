﻿using AIStudio.Core;
using AIStudio.Core.Models;
using AIStudio.Core.Validation;
using AIStudio.Wpf.Entity.Models;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace AIStudio.Wpf.Entity.DTOModels
{
    public partial class Base_CustomerRuleDTO : Base_CustomerRule, INotifyPropertyChanged, IIsChecked
    {

     

        private bool? _isChecked = false;
        public bool? IsChecked
        {
            get { return _isChecked; }
            set
            {
                if (value != _isChecked)
                {
                    _isChecked = value;
                    RaisePropertyChanged("IsChecked");
                }
            }
        }

        private List<SelectOption> _CustomerTypeList;
        public List<SelectOption> CustomerTypeList
        {
            get { return _CustomerTypeList; }
            set
            {
                if (_CustomerTypeList != value)
                {
                    _CustomerTypeList = value;
                    RaisePropertyChanged("CustomerTypeList");
                }
            }
        }

        public ISelectOption _CustomerTypeItem;
        public ISelectOption CustomerTypeItem
        {
            get { return _CustomerTypeItem; }
            set
            {
                if (_CustomerTypeItem != value)
                {
                    _CustomerTypeItem = value;
                    RaisePropertyChanged("CustomerTypeItem");
                }
            }
        }

        private ObservableCollection<ISelectOption> _AddFanLi_List;
        public ObservableCollection<ISelectOption> AddFanLi_List
        {
            get { return _AddFanLi_List; }
            set
            {
                if (value != _AddFanLi_List)
                {
                    _AddFanLi_List = value;
                    RaisePropertyChanged("AddFanLi_List");
                }
            }
        }

        private ISelectOption _AddFanLi_Item;
        public ISelectOption AddFanLi_Item
        {
            get { return _AddFanLi_Item; }
            set
            {
                if (value != _AddFanLi_Item)
                {
                    _AddFanLi_Item = value;
                    RaisePropertyChanged("AddFanLi_Item");
                }
            }
        }

        private ObservableCollection<ISelectOption> _AddPay_List;
        public ObservableCollection<ISelectOption> AddPay_List
        {
            get { return _AddPay_List; }
            set
            {
                if (value != _AddPay_List)
                {
                    _AddPay_List = value;
                    RaisePropertyChanged("AddPay_List");
                }
            }
        }

        private ISelectOption _AddPay_Item;
        public ISelectOption AddPay_Item
        {
            get { return _AddPay_Item; }
            set
            {
                if (value != _AddPay_Item)
                {
                    _AddPay_Item = value;
                    RaisePropertyChanged("AddPay_Item");
                }
            }
        }

        private ObservableCollection<ISelectOption> _FanLi_List;
        public ObservableCollection<ISelectOption> FanLi_List
        {
            get { return _FanLi_List; }
            set
            {
                if (value != _FanLi_List)
                {
                    _FanLi_List = value;
                    RaisePropertyChanged("FanLi_List");
                }
            }
        }

        private ISelectOption _FanLi_Item;
        public ISelectOption FanLi_Item
        {
            get { return _FanLi_Item; }
            set
            {
                if (value != _FanLi_Item)
                {
                    _FanLi_Item = value;
                    RaisePropertyChanged("FanLi_Item");
                }
            }
        }

        private ObservableCollection<ISelectOption> _JZ_List;
        public ObservableCollection<ISelectOption> JZ_List
        {
            get { return _JZ_List; }
            set
            {
                if (value != _JZ_List)
                {
                    _JZ_List = value;
                    RaisePropertyChanged("JZ_List");
                }
            }
        }

        private ISelectOption _JZ_Item;
        public ISelectOption JZ_Item
        {
            get { return _JZ_Item; }
            set
            {
                if (value != _JZ_Item)
                {
                    _JZ_Item = value;
                    RaisePropertyChanged("JZ_Item");
                }
            }
        }

        private ObservableCollection<ISelectOption> _H2_List;
        public ObservableCollection<ISelectOption> H2_List
        {
            get { return _H2_List; }
            set
            {
                if (value != _H2_List)
                {
                    _H2_List = value;
                    RaisePropertyChanged("H2_List");
                }
            }
        }

        private ISelectOption _H2_Item;
        public ISelectOption H2_Item
        {
            get { return _H2_Item; }
            set
            {
                if (value != _H2_Item)
                {
                    _H2_Item = value;
                    RaisePropertyChanged("H2_Item");
                }
            }
        }






        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void RaisePropertyChanged(string propertyName)
        {
            //this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    public partial class Base_CustomerRuleDTO : IDataErrorInfo
    {
        [Browsable(false)]
        public string this[string columnName]
        {
            get
            {
                List<ValidationResult> validationResults = new List<ValidationResult>();

                bool result = Validator.TryValidateProperty(
                    GetType().GetProperty(columnName).GetValue(this),
                    new ValidationContext(this)
                    {
                        MemberName = columnName
                    },
                    validationResults);

                if (result)
                    return null;

                return validationResults.First().ErrorMessage;
            }
        }

        [Browsable(false)]
        public string Error
        {
            get
            {
                ICollection<ValidationResult> results;
                this.Validate(out results);

                return results.FirstOrDefault()?.ErrorMessage;
            }
        }
    }   
}
