﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIStudio.Wpf.Entity.Models
{
    /// <summary>
    /// 
    /// </summary>
    [Table("CustomerRule_AddPay")]
    public class CustomerRule_AddPay
    {

        /// <summary>
        /// Id
        /// </summary>
        public String Id { get; set; }

        /// <summary>
        /// 规则名称
        /// </summary>
        public String Name { get; set; }

        /// <summary>
        /// 客户重量段加收费_最小值
        /// </summary>
        public Decimal? MinValueOne { get; set; }

        /// <summary>
        /// 客户重量段加收费_最大值
        /// </summary>
        public Decimal? MaxValueOne { get; set; }

        /// <summary>
        /// 客户重量段加收费_收费金额
        /// </summary>
        public Decimal? AddAmountOne { get; set; }

        public decimal? MinValueTwo { get; set; }

        public decimal? MaxValueTwo { get; set; }

        public decimal? AddAmountTwo { get; set; }

        public decimal? MinValueThree { get; set; }

        public decimal? MaxValueThree { get; set; }

        public decimal? AddAmountThree { get; set; }

        public decimal? MinValueFour { get; set; }

        public decimal? MaxValueFour { get; set; }

        public decimal? AddAmountFour { get; set; }

        public decimal? MinValueFive { get; set; }

        public decimal? MaxValueFive { get; set; }

        public decimal? AddAmountFive { get; set; }

        /// <summary>
        /// CreateTime
        /// </summary>
        public DateTime? CreateTime { get; set; }

        public string RuleRemark { get; set; }

    }
}