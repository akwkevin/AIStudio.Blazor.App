﻿namespace AIStudio.Core
{
    /// <summary>
    /// 系统日志类型
    /// </summary>
    public enum UserLogType
    {
        系统任务,  
        工作流程
    }
}
