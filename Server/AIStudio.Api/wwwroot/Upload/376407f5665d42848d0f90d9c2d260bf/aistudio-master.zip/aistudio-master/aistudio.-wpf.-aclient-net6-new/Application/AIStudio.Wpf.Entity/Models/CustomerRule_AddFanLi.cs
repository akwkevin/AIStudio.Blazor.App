﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIStudio.Wpf.Entity.Models
{
    /// <summary>
    /// 
    /// </summary>
    [Table("CustomerRule_AddFanLi")]
    public class CustomerRule_AddFanLi
    {

        /// <summary>
        /// Id
        /// </summary>
        public String Id { get; set; }

        /// <summary>
        /// Name
        /// </summary>
        public String Name { get; set; }

        /// <summary>
        /// 客户重量段加返利_最小值
        /// </summary>
        public Decimal? MinValueOne { get; set; }

        /// <summary>
        /// 客户重量段加返利_最大值
        /// </summary>
        public Decimal? MaxValueOne { get; set; }

        /// <summary>
        /// AddAmount
        /// </summary>
        public Decimal? AddAmountOne { get; set; }

        /// <summary>
        /// 客户重量段加返利_最小值
        /// </summary>
        public Decimal? MinValueTwo { get; set; }

        /// <summary>
        /// 客户重量段加返利_最大值
        /// </summary>
        public Decimal? MaxValueTwo { get; set; }

        /// <summary>
        /// AddAmount
        /// </summary>
        public Decimal? AddAmountTwo { get; set; }


        /// <summary>
        /// 客户重量段加返利_最小值
        /// </summary>
        public Decimal? MinValueThree { get; set; }

        /// <summary>
        /// 客户重量段加返利_最大值
        /// </summary>
        public Decimal? MaxValueThree { get; set; }

        /// <summary>
        /// AddAmount
        /// </summary>
        public Decimal? AddAmountThree { get; set; }


        /// <summary>
        /// 客户重量段加返利_最小值
        /// </summary>
        public Decimal? MinValueFour { get; set; }

        /// <summary>
        /// 客户重量段加返利_最大值
        /// </summary>
        public Decimal? MaxValueFour { get; set; }

        /// <summary>
        /// AddAmount
        /// </summary>
        public Decimal? AddAmountFour { get; set; }


        /// <summary>
        /// 客户重量段加返利_最小值
        /// </summary>
        public Decimal? MinValueFive { get; set; }

        /// <summary>
        /// 客户重量段加返利_最大值
        /// </summary>
        public Decimal? MaxValueFive { get; set; }

        /// <summary>
        /// AddAmount
        /// </summary>
        public Decimal? AddAmountFive { get; set; }

        public string RuleRemark { get; set; }

        /// <summary>
        /// CreateTime
        /// </summary>
        public DateTime? CreateTime { get; set; }


        


    }
}