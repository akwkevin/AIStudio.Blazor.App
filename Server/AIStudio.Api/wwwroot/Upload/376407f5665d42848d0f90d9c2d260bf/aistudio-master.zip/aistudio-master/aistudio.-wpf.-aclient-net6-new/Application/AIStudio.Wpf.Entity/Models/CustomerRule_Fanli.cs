﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIStudio.Wpf.Entity.Models
{
    /// <summary>
    /// 
    /// </summary>
    [Table("CustomerRule_Fanli")]
    public class CustomerRule_Fanli
    {

        /// <summary>
        /// Id
        /// </summary>
        public String Id { get; set; }

        /// <summary>
        /// 返利省份条件_逗号分隔
        /// </summary>
        public String Fanli_ProvinceStr { get; set; }

        /// <summary>
        /// Fanli_Weight
        /// </summary>
        public Decimal? Fanli_Weight { get; set; }

        /// <summary>
        /// CreateTime
        /// </summary>
        public DateTime? CreateTime { get; set; }

   
        /// <summary>
        /// Name
        /// </summary>
        public String Name { get; set; }

        public string RuleRemark { get; set; }

    }
}