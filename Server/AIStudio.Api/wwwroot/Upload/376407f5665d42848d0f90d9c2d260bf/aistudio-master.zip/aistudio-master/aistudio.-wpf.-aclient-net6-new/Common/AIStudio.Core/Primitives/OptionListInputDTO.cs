﻿using System.Collections.Generic;

namespace AIStudio.Core
{
    public class OptionListInputDTO
    {
        public List<string> selectedValues { get; set; }
        public string q { get; set; }
    }
}