﻿using NPOI.HPSF;
using NPOI.HSSF.UserModel;
using NPOI.HSSF.Util;
using NPOI.SS.UserModel;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Data.OleDb;
using System.Windows.Data;
using System.Net.Http;
using ExcelDataReader;

namespace AIStudio.Core.Helper
{
    public class ExcelHelper
    {
        public static object CellHorizontalAlignment { get; private set; }

        //private void Button_Click_1(object sender, RoutedEventArgs e)
        //{

        //    ExportDataGridSaveAs(true, this.data);
        //}
        #region wpf客户端 导出DataGrid数据到Excel

        /// <summary>
        /// CSV格式化
        /// </summary>
        /// <param name="data">数据</param>
        /// <returns>格式化数据</returns>
        private static string FormatCsvField(string data)
        {
            return String.Format("\"{0}\"", data.Replace("\"", "\"\"\"").Replace("\n", "").Replace("\r", ""));
        }



        /// <summary>
        /// 导出DataGrid数据到Excel
        /// </summary>
        /// <param name="withHeaders">是否需要表头</param>
        /// <param name="grid">DataGrid</param>
        /// <param name="dataBind"></param>
        /// <returns>Excel内容字符串</returns>
        public static string ExportDataGrid(bool withHeaders, System.Windows.Controls.DataGrid grid, bool dataBind)
        {
            try
            {
                var strBuilder = new System.Text.StringBuilder();
                var source = (grid.ItemsSource as System.Collections.IList);
                if (source == null) return "";
                var headers = new List<string>();
                List<string> bt = new List<string>();

                foreach (var hr in grid.Columns)
                {
                    // DataGridTextColumn textcol = hr. as DataGridTextColumn;
                    headers.Add(hr.Header.ToString());
                    if (hr is DataGridTextColumn)//列绑定数据
                    {
                        DataGridTextColumn textcol = hr as DataGridTextColumn;
                        if (textcol != null)
                            bt.Add((textcol.Binding as Binding).Path.Path.ToString()); //获取绑定源

                    }
                    else if (hr is DataGridTemplateColumn)
                    {
                        if (hr.Header.Equals("操作"))
                            bt.Add("Id");
                    }
                    else
                    {

                    }
                }
                strBuilder.Append(String.Join(",", headers.ToArray())).Append("\r\n");
                foreach (var data in source)
                {
                    var csvRow = new List<string>();
                    foreach (var ab in bt)
                    {
                        string s = ReflectionUtil.GetProperty(data, ab).ToString();
                        if (s != null)
                        {
                            if (s == "TRUE")
                            {
                                s = "男";
                            }
                            else if (s == "FALSE")
                            {
                                s = "女";
                            }
                            csvRow.Add(FormatCsvField(s));
                        }
                        else
                        {
                            csvRow.Add("\t");
                        }
                    }
                    strBuilder.Append(String.Join(",", csvRow.ToArray())).Append("\r\n");
                    // strBuilder.Append(String.Join(",", csvRow.ToArray())).Append("\t");
                }
                return strBuilder.ToString();
            }
            catch (Exception ex)
            {
                // LogHelper.Error(ex);
                return "";
            }
        }
        public class ReflectionUtil
        {
            public static object GetProperty(object obj, string propertyName)
            {
                PropertyInfo info = obj.GetType().GetProperty(propertyName);
                if (info == null && propertyName.Split('.').Count() > 0)
                {
                    object o = ReflectionUtil.GetProperty(obj, propertyName.Split('.')[0]);
                    int index = propertyName.IndexOf('.');
                    string end = propertyName.Substring(index + 1, propertyName.Length - index - 1);
                    return ReflectionUtil.GetProperty(o, end);
                }
                object result = null;
                try
                {
                    result = info.GetValue(obj, null);
                }
                catch (TargetException)
                {
                    return "";
                }
                return result == null ? "" : result;
            }
        }
        /// <summary>
        /// 导出DataGrid数据到Excel为CVS文件
        /// 使用utf8编码 中文是乱码 改用Unicode编码
        ///
        /// </summary>
        /// <param name="withHeaders">是否带列头</param>
        /// <param name="grid">DataGrid</param>
        public static void ExportDataGridSaveAs(bool withHeaders, System.Windows.Controls.DataGrid grid)
        {
            try
            {
                string data = ExportDataGrid(true, grid, true);
                var sfd = new Microsoft.Win32.SaveFileDialog
                {

                    DefaultExt = "xls",
                    Filter = "Excel 文件(*.xls)|*.xls|Excel 文件(*.xlsx)|*.xlsx|所有文件(*.*)|*.*",
                    FilterIndex = 1
                };
                if (sfd.ShowDialog() == true)
                {

                    using (Stream stream = sfd.OpenFile())
                    {
                        using (var writer = new StreamWriter(stream, System.Text.Encoding.Unicode))
                        {
                            data = data.Replace(",", "\t");
                            writer.Write(data);
                            writer.Close();
                        }
                        stream.Close();
                    }
                }
                MessageBox.Show("导出成功！");
            }
            catch (Exception ex)
            {
                // LogHelper.Error(ex);
            }
        }

        #endregion 导出DataGrid数据到Excel


        #region 222

        public static bool IsNullable(Type t)
        {
            return !t.IsValueType || (t.IsGenericType && t.GetGenericTypeDefinition() == typeof(Nullable<>));
        }

        /// <summary>
        /// Return underlying type if type is Nullable otherwise return the type
        /// </summary>
        public static Type GetCoreType(Type t)
        {
            if (t != null && IsNullable(t))
            {
                if (!t.IsValueType)
                {
                    return t;
                }
                else
                {
                    return Nullable.GetUnderlyingType(t);
                }
            }
            else
            {
                return t;
            }
        }

        public static System.Data.DataTable ListToDataTable<T>(List<T> items)
        {
            var tb = new System.Data.DataTable(typeof(T).Name);

            PropertyInfo[] props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

            foreach (PropertyInfo prop in props)
            {
                Type t = GetCoreType(prop.PropertyType);
                tb.Columns.Add(prop.Name, t);
            }

            foreach (T item in items)
            {
                var values = new object[props.Length];

                for (int i = 0; i < props.Length; i++)
                {
                    values[i] = props[i].GetValue(item, null);
                }

                tb.Rows.Add(values);
            }

            return tb;
        }

        public static void ExportToExcel(System.Data.DataTable table)
        {
            try
            {

                var sfd = new Microsoft.Win32.SaveFileDialog
                {

                    DefaultExt = "xls",
                    Filter = "Excel 文件(*.xls)|*.xls|Excel 文件(*.xlsx)|*.xlsx|所有文件(*.*)|*.*",
                    FilterIndex = 1
                };
                if (sfd.ShowDialog() == true)
                {
                    string fileName = sfd.FileName;
                    DataTableToExcel(table, fileName);
                    MessageBox.Show("导出成功！");
                }

            }
            catch (Exception ex)
            {
                // LogHelper.Error(ex);
            }
        }




        /// <summary>
        /// 将数据导出至Excel文件
        /// </summary>
        /// <param name="Table">DataTable对象</param>
        /// <param name="ExcelFilePath">Excel文件路径</param>
        //public static bool OutputToExcel(DataTable Table, string ExcelFilePath)
        //{
        //    if (File.Exists(ExcelFilePath))
        //    {
        //        throw new Exception("该文件已经存在！");
        //    }

        //    if ((Table.TableName.Trim().Length == 0) || (Table.TableName.ToLower() == "table"))
        //    {
        //        Table.TableName = "Sheet1";
        //    }

        //    //数据表的列数
        //    int ColCount = Table.Columns.Count;

        //    //用于记数，实例化参数时的序号
        //    int i = 0;

        //    //创建参数
        //    OleDbParameter[] para = new OleDbParameter[ColCount];

        //    //创建表结构的SQL语句
        //    string TableStructStr = @"Create Table " + Table.TableName + "(";

        //    //连接字符串
        //    string connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + ExcelFilePath + ";Extended Properties=Excel 8.0;";
        //    OleDbConnection objConn = new OleDbConnection(connString);

        //    //创建表结构
        //    OleDbCommand objCmd = new OleDbCommand();

        //    //数据类型集合
        //    ArrayList DataTypeList = new ArrayList();
        //    DataTypeList.Add("System.Decimal");
        //    DataTypeList.Add("System.Double");
        //    DataTypeList.Add("System.Int16");
        //    DataTypeList.Add("System.Int32");
        //    DataTypeList.Add("System.Int64");
        //    DataTypeList.Add("System.Single");

        //    //遍历数据表的所有列，用于创建表结构
        //    foreach (DataColumn col in Table.Columns)
        //    {
        //        //如果列属于数字列，则设置该列的数据类型为double
        //        if (DataTypeList.IndexOf(col.DataType.ToString()) >= 0)
        //        {
        //            para[i] = new OleDbParameter("@" + col.ColumnName, OleDbType.Double);
        //            objCmd.Parameters.Add(para[i]);

        //            //如果是最后一列
        //            if (i + 1 == ColCount)
        //            {
        //                TableStructStr += col.ColumnName + " double)";
        //            }
        //            else
        //            {
        //                TableStructStr += col.ColumnName + " double,";
        //            }
        //        }
        //        else
        //        {
        //            para[i] = new OleDbParameter("@" + col.ColumnName, OleDbType.VarChar);
        //            objCmd.Parameters.Add(para[i]);

        //            //如果是最后一列
        //            if (i + 1 == ColCount)
        //            {
        //                TableStructStr += col.ColumnName + " varchar)";
        //            }
        //            else
        //            {
        //                TableStructStr += col.ColumnName + " varchar,";
        //            }
        //        }
        //        i++;
        //    }

        //    //创建Excel文件及文件结构
        //    try
        //    {
        //        objCmd.Connection = objConn;
        //        objCmd.CommandText = TableStructStr;

        //        if (objConn.State == ConnectionState.Closed)
        //        {
        //            objConn.Open();
        //        }
        //        objCmd.ExecuteNonQuery();
        //    }
        //    catch (Exception exp)
        //    {
        //        throw exp;
        //    }

        //    //插入记录的SQL语句
        //    string InsertSql_1 = "Insert into " + Table.TableName + " (";
        //    string InsertSql_2 = " Values (";
        //    string InsertSql = "";

        //    //遍历所有列，用于插入记录，在此创建插入记录的SQL语句
        //    for (int colID = 0; colID < ColCount; colID++)
        //    {
        //        if (colID + 1 == ColCount)  //最后一列
        //        {
        //            InsertSql_1 += Table.Columns[colID].ColumnName + ")";
        //            InsertSql_2 += "@" + Table.Columns[colID].ColumnName + ")";
        //        }
        //        else
        //        {
        //            InsertSql_1 += Table.Columns[colID].ColumnName + ",";
        //            InsertSql_2 += "@" + Table.Columns[colID].ColumnName + ",";
        //        }
        //    }

        //    InsertSql = InsertSql_1 + InsertSql_2;

        //    //遍历数据表的所有数据行
        //    for (int rowID = 0; rowID < Table.Rows.Count; rowID++)
        //    {
        //        for (int colID = 0; colID < ColCount; colID++)
        //        {
        //            if (para[colID].DbType == DbType.Double && Table.Rows[rowID][colID].ToString().Trim() == "")
        //            {
        //                para[colID].Value = 0;
        //            }
        //            else
        //            {
        //                para[colID].Value = Table.Rows[rowID][colID].ToString().Trim();
        //            }
        //        }
        //        try
        //        {
        //            objCmd.CommandText = InsertSql;
        //            objCmd.ExecuteNonQuery();
        //        }
        //        catch (Exception exp)
        //        {
        //            string str = exp.Message;
        //        }
        //    }
        //    try
        //    {
        //        if (objConn.State == ConnectionState.Open)
        //        {
        //            objConn.Close();
        //        }
        //    }
        //    catch (Exception exp)
        //    {
        //        throw exp;
        //    }
        //    return true;
        //}


        #endregion

        public static void DataTableToExcel(System.Data.DataTable dt, string path)
        {
            //instance excel object 
            //Excel excel = new Excel(65536); 
            Excel excel = new Excel();
            //create a sheet 
            excel.CreateSheet(dt.Columns);
            //write value into rows 
            //excel.SetRowValue(dt.Rows); 
            foreach (DataRow row in dt.Rows)
            {
                excel.SetRowValue(row);
            }
            // set excel protected 
            excel.SetProtectPassword("etimes2011@", "baiyi");
            // save excel file to local 
            excel.SaveAs(path);
        }

        public static void ExportExcelTwo(System.Data.DataTable dt,string path)
        {


            //设置新建文件路径及名称
            string savePath = path ;

            //创建文件
            using (var file = new FileStream(savePath, FileMode.CreateNew, FileAccess.Write))
            {
                //Encoding.GetEncoding("GB2312")
                //以指定的字符编码向指定的流写入字符
                using (var sw = new StreamWriter(file, Encoding.GetEncoding("gb2312")))
                {
                    StringBuilder strbu = new StringBuilder();


                    //写入标题
                    for (int i = 0; i < dt.Columns.Count; i++)
                    {
                        strbu.Append(dt.Columns[i].ColumnName.ToString() + "\t");
                    }
                    //加入换行字符串
                    strbu.Append(Environment.NewLine);

                    //写入内容
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        for (int j = 0; j < dt.Columns.Count; j++)
                        {
                            var temp = dt.Rows[i][j].ToString();
                            strbu.Append(dt.Rows[i][j].ToString()+ "\t");
                        }
                        strbu.Append(Environment.NewLine);
                    }

                    sw.Write(strbu.ToString());
                    sw.Flush();
                    file.Flush();

                    sw.Close();
                    sw.Dispose();

                    strbu.Remove(0, strbu.Length);
                }


                file.Close();
                file.Dispose();
            }

            dt.Clear();
            dt.Dispose();
            dt = null;
            System.GC.Collect();
        }

        public static DataTable ExcelToDataSet(string filename)
        {

            System.Text.EncodingProvider ppp = System.Text.CodePagesEncodingProvider.Instance;
            Encoding.RegisterProvider(ppp);


            using (var stream = File.Open(filename, FileMode.Open, FileAccess.Read))
            {
                using (IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream))
                {
                    //读取数据表
                     var ds = reader.AsDataSet();
                    
                    return ds.Tables[0];
                }
            }
        }

    }



    public class Excel
    {
        private HSSFWorkbook _workBook;
        private ISheet _wbSheet = null;
        private DataColumnCollection _columns = null;
        private int _col = 0; //total columns 
        private int _row = 0; //total rows 
        private int _sheet = 0; //total sheets 
        private int _sheetRowNum = 65536; //each sheet allow rows 

        //   public object FillPatternType { get; private set; }

        public Excel()
        {
            InstanceWorkBook();
        }
        /// <summary> 
        /// 实例方法 
        /// </summary> 
        /// <param name="sheetRowNum">单个表单允许的最大行数</param> 
        public Excel(int sheetRowNum)
        {
            _sheetRowNum = sheetRowNum;
            InstanceWorkBook();
        }
        /// <summary> 
        /// 实例方法 
        /// </summary> 
        /// <param name="columns">表头</param> 
        public Excel(DataColumnCollection columns)
        {
            _columns = columns;
            InstanceWorkBook();
        }
        private void InstanceWorkBook()
        {
            /////cretate WorkBook 
            _workBook = new HSSFWorkbook();
            var dsi = PropertySetFactory.CreateDocumentSummaryInformation();
            dsi.Company = "BaiyiTimes";
            _workBook.DocumentSummaryInformation = dsi;
            ////create a entry of SummaryInformation 
            var si = PropertySetFactory.CreateSummaryInformation();
            si.Subject = "Etimes Secure Document System Log Backup";
            _workBook.SummaryInformation = si;
        }
        private DataColumnCollection GetColumns(DataColumnCollection columns)
        {
            return columns == null || columns.Count == 0 ? _columns : columns;
        }
        private ISheet GetSheet(ISheet sheet)
        {
            return sheet == null ? _wbSheet : sheet;
        }
        private void CreateHeader(ISheet sheet, DataColumnCollection columns)
        {
            _columns = GetColumns(columns);
            /////create row of column 
            var oRow = sheet.CreateRow(0);
            foreach (DataColumn column in _columns)
            {
                var oCell = oRow.CreateCell(_col);
                var style1 = _workBook.CreateCellStyle();
                style1.FillForegroundColor = HSSFColor.Blue.Index2;
                style1.FillPattern = FillPattern.SolidForeground;
                style1.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
                style1.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Center;
                var font = _workBook.CreateFont();
                font.Color = HSSFColor.White.Index;
                style1.SetFont(font);
                oCell.CellStyle = style1;
                var name = column.ColumnName;
                oCell.SetCellValue(name.ToString());
                _col++;
            }
            ///// header belong to rows 
            _row++;
        }
        private void CreateHeader(ISheet sheet)
        {
            CreateHeader(sheet, null);
        }
        public ISheet CreateSheet()
        {
            return CreateSheet(null);
        }
        public ISheet CreateSheet(DataColumnCollection columns)
        {
            _wbSheet = _workBook.CreateSheet((_sheet + 1).ToString());
            CreateHeader(_wbSheet, columns);
            _sheet++;
            return _wbSheet;
        }
        public void SetRowValue(DataRowCollection rows, ISheet sheet)
        {
            _wbSheet = GetSheet(sheet);
            foreach (DataRow row in rows)
            {
                SetRowValue(row);
            }
        }
        public void SetRowValue(DataRowCollection rows)
        {
            SetRowValue(rows, null);
        }
        public void SetRowValue(DataRow row)
        {
            // create a new sheet 
            if (_row % _sheetRowNum == 0)
            {
                CreateSheet();
            }
            var oRow = _wbSheet.CreateRow(_row % _sheetRowNum);
            var obj = string.Empty;
            var cell = 0;
            foreach (DataColumn column in _columns)
            {
                obj = row[column.ColumnName].ToString();
                oRow.CreateCell(cell).SetCellValue(obj);
                cell++;
            }
            _row++;
        }
        public void SetProtectPassword(string password, string username)
        {
            _workBook.WriteProtectWorkbook(password, username);
        }
        public void SaveAs(string filePath)
        {
            if (File.Exists(filePath)) File.Delete(filePath);
            var file = new FileStream(filePath, FileMode.Create);
            _workBook.Write(file);
            file.Close();
        }
    }
}
