﻿using System.Collections.Generic;

namespace AIStudio.Wpf.Business
{
    public interface IAppHeader
    {
        Dictionary<string, string> GetHeader();
    }
}
