﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIStudio.Wpf.Entity.Models
{
    /// <summary>
    /// 
    /// </summary>
    [Table("Base_KuaiDi")]
    public class Base_KuaiDi
    {

        /// <summary>
        /// Id
        /// </summary>
        [Key, Column(Order = 1)]
        public String Id { get; set; }

        /// <summary>
        /// KuaiDi
        /// </summary>
        public String KuaiDi { get; set; }

        /// <summary>
        /// UserSign
        /// </summary>
        public String UserSign { get; set; }

        /// <summary>
        /// CDJ
        /// </summary>
        public Decimal? CDJ { get; set; }

        /// <summary>
        /// FL
        /// </summary>
        public Decimal? FL { get; set; }

        /// <summary>
        /// DJ
        /// </summary>
        public Decimal? DJ { get; set; }

        /// <summary>
        /// Remark
        /// </summary>
        public String Remark { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        public DateTime? StartTime { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        public DateTime? EndTime { get; set; }


    }
}