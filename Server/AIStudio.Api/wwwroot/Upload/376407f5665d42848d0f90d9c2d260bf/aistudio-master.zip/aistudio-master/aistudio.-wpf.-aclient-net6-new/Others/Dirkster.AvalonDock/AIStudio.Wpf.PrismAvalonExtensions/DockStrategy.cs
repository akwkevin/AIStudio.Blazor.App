﻿namespace AIStudio.Wpf.PrismAvalonExtensions
{
    public abstract class DockStrategy
    {
    }
}
