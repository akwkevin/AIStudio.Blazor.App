﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIStudio.Wpf.Entity.Models
{
    /// <summary>
    /// 
    /// </summary>
    [Table("CustomerRule_Hou2")]
    public class CustomerRule_Hou2
    {

        /// <summary>
        /// Id
        /// </summary>
        public String Id { get; set; }



        /// <summary>
        /// 后2统重量条件
        /// </summary>
        public Decimal? Hou2_Weight { get; set; }

        /// <summary>
        /// 后2统100%比
        /// </summary>
        public Int32? Hou2_100 { get; set; }

        /// <summary>
        /// SinglePrice
        /// </summary>
        public Decimal? SinglePrice { get; set; }

        /// <summary>
        /// CreateTime
        /// </summary>
        public DateTime? CreateTime { get; set; }



        /// <summary>
        /// Name
        /// </summary>
        public String Name { get; set; }

        public string RuleRemark { get; set; }

    }
}