﻿namespace AIStudio.Wpf.PrismAvalonExtensions
{
    public class DocumentDockStrategy : DockStrategy
    {
    }
}
