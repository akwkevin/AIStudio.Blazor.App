﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIStudio.Wpf.Entity.Models
{
    /// <summary>
    /// 
    /// </summary>
    [Table("Base_SellRecord")]
    public class Base_SellRecord
    {

        /// <summary>
        /// Id
        /// </summary>
        public String Id { get; set; }

        /// <summary>
        /// 单号
        /// </summary>
        public String OrderNo { get; set; }

        /// <summary>
        /// 日期
        /// </summary>
        public DateTime? OrderDate { get; set; }

        /// <summary>
        /// 旺旺
        /// </summary>
        public String Wangwang { get; set; }

        /// <summary>
        /// 业务员
        /// </summary>
        public String YeWuYuan { get; set; }

        /// <summary>
        /// 快递
        /// </summary>
        public String KuaiDi { get; set; }

        /// <summary>
        /// 件数
        /// </summary>
        public Int32? Quantity { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public String Remark { get; set; }

        /// <summary>
        /// 费用
        /// </summary>
        public Decimal? Cost { get; set; }

        /// <summary>
        /// 重量
        /// </summary>
        public Decimal? Weight { get; set; }

        /// <summary>
        /// 省份
        /// </summary>
        public String Province { get; set; }

        /// <summary>
        /// 操作人标识
        /// </summary>
        public String UserSign { get; set; }

        /// <summary>
        /// 客户
        /// </summary>
        public String Customer { get; set; }

        /// <summary>
        /// 店铺
        /// </summary>
        public String Shop { get; set; }


        /// <summary>
        /// 省份类型
        /// </summary>
        public string ProvinceTypeStr { get; set; }


        /// <summary>
        /// 重量段类型
        /// </summary>
        public string WeightTypeStr { get; set; }

        /// <summary>
        /// 是否已匹配
        /// </summary>
        public bool? HasMatch { get; set; }

      
        public string HasMatchStr { get {
                if (this.HasMatch.HasValue && this.HasMatch.Value)
                {
                    return "是";
                }
                else
                {
                    return "否";
                }
            } }
    }
}