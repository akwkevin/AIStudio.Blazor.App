﻿namespace AIStudio.Core
{
    /// <summary>
    /// 类型,菜单=0,页面=1,权限=2
    /// </summary>
    public enum ActionType
    {
        菜单 = 0,
        页面 = 1,
        权限 = 2
    }
}
