﻿using AIStudio.AOP;
using AIStudio.Core;
using AIStudio.Core.Models;
using AIStudio.DbFactory.DataAccess;
using AIStudio.Wpf.ApiBusiness;
using AIStudio.Wpf.Business;
using AIStudio.Wpf.DataBusiness.AOP;
using AIStudio.Wpf.Entity.DTOModels;
using AIStudio.Wpf.Entity.DTOModels.Base_Manage;
using AIStudio.Wpf.Entity.DTOModels.Base_Manage.InputDTO;
using AIStudio.Wpf.Entity.Models;
using AIStudio.Wpf.Entity.TreeModel;
using Castle.Core.Internal;
using Castle.Core.Resource;
using Microsoft.Office.Interop.Excel;
using Microsoft.VisualBasic;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using NodaTime;
using NPOI.POIFS.Properties;
using NPOI.SS.Formula.Functions;
using NPOI.Util;
using NPOI.XWPF.UserModel;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Utilities.Collections;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Linq.Expressions;
using System.Net.Http;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.CompilerServices;
using System.Security.Claims;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Windows.Automation.Provider;
using System.Windows.Forms;

namespace AIStudio.Wpf.ApiBusiness
{
    public class ApiDataProvider : IDataProvider
    {
        private IHttpClientFactory _httpClientFactory;
        private SqlServerHelper _dbHelper;
        private string _connectionString;
     
        public ApiDataProvider(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
            _connectionString = "Data Source=123.249.9.250,1433;Initial Catalog=AIStudio.Blazor.App;User Id =sa;Password=@SHIpeng88;Pooling=true";
            _dbHelper = new SqlServerHelper(_connectionString);
        }
        #region 设置信息
        public string Url { get; set; }
        public IAppHeader Header { get; set; }
        public TimeSpan TimeOut { get; set; }

        public string CurrentUserSign { get; set; }

        public Dictionary<string, string> GetHeader()
        {
            return Header.GetHeader();
        }
        #endregion

        #region 密匙模式
        public void Init(string url, string appId, string appSecret, TimeSpan timeout)
        {
            var header = new AppSecretHeader(appId, appSecret);
            Url = url;
            Header = header;
            TimeOut = timeout;
        }
        #endregion

        #region Token模式
        public void Init(string url, string userName, string password, int headMode, TimeSpan timeout)
        {
            var header = new AppTokenHeader(userName, password);
            Url = url;
            Header = header;
            TimeOut = timeout;
        }
        #endregion

     
       
        public async Task<AjaxResult> GetToken(string url, string userName, string password, int headMode, TimeSpan timeout)
        {
            Init(url, userName, password, headMode, timeout);
            try
            {
                if (Header is AppTokenHeader)
                {
                    AppTokenHeader header = Header as AppTokenHeader;

                    var content = await PostAsyncJson((string.Format("{0}/Base_Manage/Home/SubmitLogin", Url)), JsonConvert.SerializeObject(new { userName = header.UserName, password = header.Password }), TimeOut);
                    var result = JsonConvert.DeserializeObject<AjaxResult>(content);
                    header.Token = result.Data as string;

                    return result;
                }
                else
                {
                    throw new Exception("暂不支持");
                }
            }
            catch (Exception ex)
            {
                return new AjaxResult() { Msg = ex.Message, Success = false };
            }

        }

        [LoggerAttribute]
        public async Task<AjaxResult<T>> PostData<T>(string url, Dictionary<string, string> data)
        {
            try
            {
                if (!url.StartsWith("http"))
                {
                    url = Url + url;
                }
                MultipartFormDataContent stringContent = null;
                if (data != null)
                {
                    stringContent = new MultipartFormDataContent();

                    foreach (var item in data)
                    {
                        stringContent.Add(new StringContent(item.Value), item.Key);
                    }
                }
                var content = await PostAsync(url, content: stringContent, TimeOut, Header.GetHeader());
                var result = JsonConvert.DeserializeObject<AjaxResult<T>>(content);
                return result;
            }
            catch (Exception ex)
            {
                return new AjaxResult<T>() { Msg = ex.Message, Success = false };
            }
        }

        [LoggerAttribute]
        public async Task<AjaxResult<T>> PostData<T>(string url, string json)
        {
            try
            {
                if (!url.StartsWith("http"))
                {
                    url = Url + url;
                }
                var content = await PostAsyncJson(url, json, TimeOut, Header.GetHeader());
                var result = JsonConvert.DeserializeObject<AjaxResult<T>>(content);
                return result;
            }
            catch (Exception ex)
            {
                return new AjaxResult<T>() { Msg = ex.Message, Success = false };
            }
        }

        [LoggerAttribute]
        public async Task<AjaxResult<T>> PostData<T>(string url, object data)
        {
            return await PostData<T>(url, JsonConvert.SerializeObject(data));
        }

        /// <summary>
        /// 上传文件
        /// </summary>
        /// <typeparam name="T">类型</typeparam>
        /// <param name="primaryKeyColumn">类型的主键，目前系统都是id</param>
        /// <param name="ids">需要删除的id列表</param>
        /// <returns></returns>
        public async Task<AjaxResult> UploadFile(string path, string fileName, string remark)
        {
            try
            {
                var data = new MultipartFormDataContent();
                ////添加字符串参数，参数名为qq
                //data.Add(new StringContent(qq), "qq");

                //添加文件参数，参数名为files，文件名为123.png
                data.Add(new ByteArrayContent(System.IO.File.ReadAllBytes(path)), "file", fileName);

                var content = await PostAsync(string.Format("{0}/api/FileServer/SaveFile", Url), data, TimeOut, Header.GetHeader());
                var result = JsonConvert.DeserializeObject<AjaxResult>(content);
                return result;
            }
            catch (Exception ex)
            {
                return new AjaxResult() { Msg = ex.Message, Success = false };
            }
        }

        /// <summary>
        /// 下载文件
        /// </summary>
        /// <typeparam name="T">类型</typeparam>
        /// <param name="primaryKeyColumn">类型的主键，目前系统都是id</param>
        /// <param name="ids">需要删除的id列表</param>
        /// <returns></returns>
        public async Task<AjaxResult> DownLoadFile(string fullpath, string savepath)
        {
            try
            {
                FileStream fs = null;
                try
                {
                    var content = await GetByteArrayAsync(fullpath, TimeOut);
                    fs = new FileStream(savepath, FileMode.Create);
                    fs.Write(content, 0, content.Length);
                    return new AjaxResult() { Success = true };
                }
                catch (Exception ex)
                {
                    return new AjaxResult() { Success = false, Msg = ex.ToString() };
                }
                finally
                {
                    if (fs != null)
                        fs.Close();
                }
            }
            catch (Exception ex)
            {
                return new AjaxResult() { Msg = ex.Message, Success = false };
            }
        }

        /// <summary>
        /// 上传文件
        /// </summary>
        /// <typeparam name="T">类型</typeparam>
        /// <param name="primaryKeyColumn">类型的主键，目前系统都是id</param>
        /// <param name="ids">需要删除的id列表</param>
        /// <returns></returns>
        public async Task<UploadResult> UploadFileByForm(string path)
        {
            try
            {
                var data = new MultipartFormDataContent();

                FileStream fStream = File.Open(path, FileMode.Open, FileAccess.Read);
                data.Add(new StreamContent(fStream, (int)fStream.Length), "file", Path.GetFileName(path));

                var content = await PostAsync(string.Format("{0}/Base_Manage/Upload/UploadFileByForm", Url), data, TimeOut, Header.GetHeader());
                var result = JsonConvert.DeserializeObject<UploadResult>(content);

                fStream.Close();
                return result;
            }
            catch (Exception ex)
            {
                return new UploadResult() { status = ex.Message };
            }
        }


        #region HttpClient
        /// <summary>
        /// 使用post方法异步请求
        /// </summary>
        /// <param name="url">目标链接</param>
        /// <param name="json">发送的参数字符串，只能用json</param>
        /// <returns>返回的字符串</returns>
        public async Task<string> PostAsyncJson(string url, string json, TimeSpan timeSpan, Dictionary<string, string> header = null)
        {
            HttpClient client = _httpClientFactory.CreateClient();
            client.Timeout = timeSpan;
            HttpContent content = new StringContent(json);
            if (header != null)
            {
                client.DefaultRequestHeaders.Clear();
                foreach (var item in header)
                {
                    client.DefaultRequestHeaders.Add(item.Key, item.Value);
                }
            }
            content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");

            string responseBody = string.Empty;
            try
            {
                HttpResponseMessage response = await client.PostAsync(url, content);
                response.EnsureSuccessStatusCode();
                responseBody = await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return responseBody;
        }

        /// <summary>
        /// 使用post方法异步请求
        /// </summary>
        /// <param name="url">目标链接</param>
        /// <param name="data">发送的参数字符串</param>
        /// <returns>返回的字符串</returns>
        public async Task<string> PostAsync(string url, HttpContent content, TimeSpan timeSpan, Dictionary<string, string> header = null)
        {
            //HttpClient client = new HttpClient(new HttpClientHandler() { UseCookies = false });
            HttpClient client = _httpClientFactory.CreateClient();
            client.Timeout = timeSpan;
            if (header != null)
            {
                client.DefaultRequestHeaders.Clear();
                foreach (var item in header)
                {
                    client.DefaultRequestHeaders.Add(item.Key, item.Value);
                }
            }

            string responseBody = string.Empty;
            try
            {
                HttpResponseMessage response = await client.PostAsync(url, content);
                response.EnsureSuccessStatusCode();
                responseBody = await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return responseBody;
        }

        /// <summary>
        /// 使用post方法异步请求
        /// </summary>
        /// <param name="url">目标链接</param>
        /// <param name="data">发送的参数字符串</param>
        /// <returns>返回的字符串</returns>
        public async Task<string> PostAsync(string url, string data, TimeSpan timeSpan, Dictionary<string, string> header = null)
        {
            //HttpClient client = new HttpClient(new HttpClientHandler() { UseCookies = false });
            HttpClient client = _httpClientFactory.CreateClient();
            client.Timeout = timeSpan;
            HttpContent content = new StringContent(data);
            if (header != null)
            {
                client.DefaultRequestHeaders.Clear();
                foreach (var item in header)
                {
                    client.DefaultRequestHeaders.Add(item.Key, item.Value);
                }
            }

            string responseBody = string.Empty;
            try
            {
                HttpResponseMessage response = await client.PostAsync(url, content);
                response.EnsureSuccessStatusCode();
                responseBody = await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return responseBody;
        }

        public async Task<byte[]> GetByteArrayAsync(string uri, TimeSpan timeSpan, Dictionary<string, string> header = null)
        {
            HttpClient client = _httpClientFactory.CreateClient();
            client.Timeout = timeSpan;
            if (header != null)
            {
                client.DefaultRequestHeaders.Clear();
                foreach (var item in header)
                {
                    client.DefaultRequestHeaders.Add(item.Key, item.Value);
                }
            }

            byte[] urlContents = await client.GetByteArrayAsync(uri);
            return urlContents;
        }

        /// <summary>
        /// 使用get方法异步请求
        /// </summary>
        /// <param name="url">目标链接</param>
        /// <returns>返回的字符串</returns>
        public async Task<string> GetAsync(string url, TimeSpan timeSpan, Dictionary<string, string> header = null)
        {
            HttpClient client = _httpClientFactory.CreateClient();
            client.Timeout = timeSpan;
            if (header != null)
            {
                client.DefaultRequestHeaders.Clear();
                foreach (var item in header)
                {
                    client.DefaultRequestHeaders.Add(item.Key, item.Value);
                }
            }

            string responseBody = string.Empty;

            try
            {
                HttpResponseMessage response = await client.GetAsync(url);
                response.EnsureSuccessStatusCode();//用来抛异常的
                responseBody = await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return responseBody;
        }
        #endregion


        public async Task<AjaxResult<List<Base_DbLinkDTO>>> GetAllDbLink()
        {
            AjaxResult<List<Base_DbLinkDTO>> result = new AjaxResult<List<Base_DbLinkDTO>>();

            List<Base_DbLinkDTO> tempData;
            try
            {

                tempData = _dbHelper.GetListBySql<Base_DbLinkDTO>("select * from Base_DbLink");
                if (tempData != null && tempData.Count > 0)
                {
                    result.Data = tempData;
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.Msg = "没查询到相关记录";
                }


            }
            catch (Exception)
            {
                result.Success = false;
                result.Msg = "sql操作报错";
            }

            return result;
        }

        
        public async Task<int> DeleteByIds(string tableName, List<string> ids)
        {
            if (ids == null || ids.Count == 0)
                return 0;

            string sql = "delete from "+tableName+" where Id in (";

            foreach (var item in ids)
            {
                sql += "'" + item + "',";
            }

            sql = sql.Substring(0, sql.Length - 1);

            sql += ")";

            return _dbHelper.ExecuteSql(sql);
        }




        public async Task<AjaxResult<List<BuildCode>>> GetDbTableList(string linkId)
        {
            AjaxResult<List<BuildCode>> result = new AjaxResult<List<BuildCode>>();


            string sql = @"select
                        [TableName] = a.name,
                        [Description] = g.value
                        from
                          sys.tables a left join sys.extended_properties g
                          on (a.object_id = g.major_id AND g.minor_id = 0 AND g.name= 'MS_Description')
                        UNION
                        select
                        [TableName] = a.name,
                        [Description] = g.value
                        from
                          sys.views a left join sys.extended_properties g
                          on (a.object_id = g.major_id AND g.minor_id = 0 AND g.name= 'MS_Description')";
            var tempResult = _dbHelper.GetListBySql<DbTableInfo>(sql);

            var tempListBuildCpde = tempResult.Select(s => new BuildCode
            {
                Description = s.Description,

                TableName = s.TableName
            });

            return new AjaxResult<List<BuildCode>> { Success = true, Data = tempListBuildCpde.ToList() };



        }

        public Dictionary<string, List<TableInfo>> GetDbTableInfo(BuildInputDTO input)
        {
            Dictionary<string, List<TableInfo>> tabInfoDictionary = new Dictionary<string, List<TableInfo>>();
            string linkId = input.linkId;
            List<string> tables = input.tables;

            ////内部成员初始化
            //_dbHelper = GetTheDbHelper(linkId);

            tables.ForEach(aTable =>
            {
                List<TableInfo> tableFieldInfo = _dbHelper.GetDbTableInfo(aTable);
                tabInfoDictionary.Add(aTable, tableFieldInfo);
            });

            return tabInfoDictionary;
        }


        /// <summary>
        /// sqlbulk批量插入（DataTable）
        /// </summary>
        /// <param name="TableName"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public int SqlBulkCopyByDatatable(string TableName, System.Data.DataTable dt)
        {
            int result = _dbHelper.SqlBulkCopyByDatatable(TableName, dt);
            return result;
        }

        /// <summary>
        /// sqlbulk批量插入（DataTable）
        /// </summary>
        /// <param name="TableName"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public int SqlBulkCopyByDatatable(string TableName, System.Data.DataTable dt, string thenSql)
        {
            int result = _dbHelper.SqlBulkCopyByDatatable(TableName, dt, thenSql);
            return result;
        }

        public async Task<int> CheckBeforeUpdate(string tableName, string colunName, string value,string Id=null)
        {

            if (string.IsNullOrEmpty(tableName) || string.IsNullOrEmpty(colunName))
            {
                return -1;
            }

            string sql = "select Id, " + colunName + " from " + tableName + " where " + colunName + " = '" + value + "'";
          

            System.Data.DataTable tempTable = _dbHelper.GetDataTableWithSql(sql);
            if (tempTable != null && tempTable.Rows.Count > 0)
            {
                if (!string.IsNullOrEmpty(Id))
                {
                    DataRow dataRow = tempTable.Rows[0];
                    if (dataRow["Id"].ToString() == Id)
                    {
                        return 1;
                    }
                
                }

                return -1;
            }
            else
            {
                return 1;
            }



        }

        public async Task<AjaxResult<Base_UserDTO>> CheckLogin(string userName, string password)
        {
            if (string.IsNullOrEmpty(userName) || string.IsNullOrEmpty(password))
            {
                return new AjaxResult<Base_UserDTO> {
                    Success = false,
                    Msg = "用户名或密码不能为空"
                };
            }

            string sql = "select * from Base_User where UserName = '" + userName + "'";
            sql += " and Password = '" + password + "'";

            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(sql);
            if (table != null && table.Rows.Count > 0)
            {

                try
                {
                    Base_UserDTO user = new Base_UserDTO
                    {
                        Id = table.Rows[0]["Id"].ToString(),
                        Avatar = table.Rows[0]["Avatar"].ToString(),
                        Birthday = table.Rows[0]["Birthday"] != DBNull.Value ? Convert.ToDateTime(table.Rows[0]["Birthday"]) : null,
                        CreateTime = Convert.ToDateTime(table.Rows[0]["CreateTime"]),
                        CreatorId = table.Rows[0]["CreatorId"].ToString(),
                        CreatorName = table.Rows[0]["CreatorName"].ToString(),
                        Deleted = Convert.ToBoolean(table.Rows[0]["Deleted"]),
                        DepartmentId = table.Rows[0]["DepartmentId"].ToString(),
                        ModifyId = table.Rows[0]["ModifyId"].ToString(),
                        ModifyName = table.Rows[0]["ModifyName"].ToString(),
                        ModifyTime = table.Rows[0]["ModifyTime"] != DBNull.Value ? Convert.ToDateTime(table.Rows[0]["ModifyTime"]) : null,
                        Password = table.Rows[0]["Password"].ToString(),
                        PhoneNumber = table.Rows[0]["PhoneNumber"].ToString(),
                        RealName = table.Rows[0]["RealName"].ToString(),
                        Sex = Convert.ToInt32(table.Rows[0]["Sex"]),
                        TenantId = table.Rows[0]["TenantId"].ToString(),
                        UserName = table.Rows[0]["UserName"].ToString()
                    };

                    return new AjaxResult<Base_UserDTO>
                    {
                        Success = true,
                        Data = user
                    };
                }
                catch (Exception e)
                {


                }
            }

            return new AjaxResult<Base_UserDTO> {
                Success = false,
                Msg = "未找到当前用户"
            };

        }


        public async Task<string[]> GetUserActionIds(string userId, bool isAdmin)
        {
            string sql = "";

            if (isAdmin)
            {
                sql = " select Id from Base_Action ";
            }
            else
            {
                sql = "select Id from Base_Action c left join ";
                sql += " (select b.ActionId from Base_UserRole a left join  Base_RoleAction b on a.Id = b.RoleId where a.UserId = '" + userId + "' ) d on c.Id = d.ActionId and c.NeedAction = 0";
            }

            System.Data.DataTable tempTable = _dbHelper.GetDataTableWithSql(sql);
            string[] result = null;
            if (tempTable != null && tempTable.Rows.Count > 0)
            {
                result = Array.ConvertAll<DataRow, string>(tempTable.Rows.Cast<DataRow>().ToArray(), r => r["Id"].ToString());
            }

            return result;

        }

        public async Task<ObservableCollection<SelectOption>> GetRoleOptionList()
        {
            string sql = " select RoleName,Id from Base_Role";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(sql);
            List<Base_Role> roleList = Extention.ToList<Base_Role>(table);

            List<SelectOption> tempResult = roleList.Select(s => new SelectOption {
                Text = s.RoleName,
                Value = s.Id
            }).ToList();

            ObservableCollection<SelectOption> result = new ObservableCollection<SelectOption>();
            result.AddRange(tempResult);

            return result;
        }

        public async Task<ObservableCollection<TreeModel>> GetDepartmentTreeDataList(SearchInput input)
        {

            string sql = " select * from Base_Department ";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(sql);

            List<Base_Department> dpList = Extention.ToList<Base_Department>(table);


            var treeList = dpList
                .Select(x => new Base_DepartmentTree
                {
                    Id = x.Id,
                    ParentId = x.ParentId,
                    Name = x.Name,
                    Text = x.Name,
                    Value = x.Id
                }).ToList();

            var tree = TreeHelper.BuildGenericsTree(treeList);

            //按字典筛选
            if (input.SearchKeyValues?.Count > 0)
            {
                IEnumerable<Base_DepartmentTree> treeList2 = TreeHelper.GetTreeToList(tree);
                foreach (var keyValuePair in input.SearchKeyValues.Where(p => !string.IsNullOrEmpty(p.Key) && !string.IsNullOrEmpty(p.Value?.ToString())))
                {
                    var newWhere = DynamicExpressionParser.ParseLambda<Base_DepartmentTree, bool>(
                        ParsingConfig.Default, false, $@"{keyValuePair.Key}.Contains(@0)", keyValuePair.Value);
                    treeList2 = treeList2.Where(newWhere.Compile());
                }

                tree = treeList2.ToList();
            }

            ObservableCollection<TreeModel> result = new ObservableCollection<TreeModel>();

            result.AddRange(tree);

            return result;
        }


        public async Task<PageResult<Base_DepartmentDTO>> Department_GetTheData(string id)
        {
            if (string.IsNullOrEmpty(id))
                return null;

            string sql = string.Format("select * from Base_Department  where Id = '{0}';", id);
            List<Base_DepartmentDTO> tempData = _dbHelper.GetListBySql<Base_DepartmentDTO>(sql);
            var list = new PageResult<Base_DepartmentDTO> { Data = tempData, Total = 1 };
            list.Success = true;
            return list;
       
        }

        public async Task<AjaxResult<int>> Department_Update(Base_Department model)
        {
            string sql = "";
            if (!string.IsNullOrEmpty(model.Id))
            {
                sql = "update Base_Department set ";

                if (!string.IsNullOrEmpty(model.Name))
                {
                    sql += " Name='" + model.Name + "',";
                }
                else
                {
                    sql += " Name='',";
                }

                if (!string.IsNullOrEmpty(model.ParentId))
                {
                    sql += " ParentId='" + model.ParentId + "',";
                }
                else
                {
                    sql += " ParentId='',";
                }

                if (model.Deleted)
                {
                    sql += " Deleted=1,";
                }
                else
                {
                    sql += " Deleted=1,";
                }

                if (model.ModifyTime.HasValue)
                {
                    sql += " ModifyTime='" + model.ModifyTime.ToString() + "',";
                }
                else
                {
                    sql += " ModifyTime=null,";
                }

                if (!string.IsNullOrEmpty(model.ModifyId))
                {
                    sql += " ModifyId='" + model.ModifyId.ToString() + "',";
                }
                else
                {
                    sql += " ModifyId=null,";
                }

                if (!string.IsNullOrEmpty(model.ModifyName))
                {
                    sql += " ModifyName='" + model.ModifyName.ToString() + "',";
                }
                else
                {
                    sql += " ModifyName=null,";
                }

                 sql += " CreateTime='" + model.CreateTime.ToString() + "',";
               
               

                if (!string.IsNullOrEmpty(model.CreatorId))
                {
                    sql += " CreatorId='" + model.CreatorId.ToString() + "',";
                }
                else
                {
                    sql += " CreatorId=null,";
                }

                if (!string.IsNullOrEmpty(model.CreatorName))
                {
                    sql += " CreatorName='" + model.CreatorName.ToString() + "',";
                }
                else
                {
                    sql += " CreatorName=null,";
                }

                if (!string.IsNullOrEmpty(model.TenantId))
                {
                    sql += " TenantId='" + model.TenantId.ToString() + "',";
                }
                else
                {
                    sql += " TenantId=null,";
                }

                sql = sql.Substring(0, sql.Length - 1);

                sql += " where Id ='" + model.Id.ToString() + "'";


            }
            else
            {
                string strNull = " null,";

                sql = "insert into Base_Department (Id,Name,ParentId,Deleted,ModifyTime,ModifyId,ModifyName,CreateTime,CreatorId,CreatorName,TenantId) values('";

                //Id
                sql += Guid.NewGuid() + "',";

                //Name
                if (string.IsNullOrEmpty(model.Name))
                {
                    sql += strNull;
                }
                else
                {
                    sql += "'" + model.Name + "',";
                }

                //ParentId
                if (string.IsNullOrEmpty(model.ParentId))
                {
                    sql += strNull;
                }
                else
                {
                    sql += "'" + model.ParentId + "',";
                }

                if (model.Deleted)
                {
                    sql += "1,";
                }
                else
                {
                    sql += "0,";
                }

                if (model.ModifyTime.HasValue)
                {
                    sql += "'" + model.ModifyTime.ToString() + "',";
                }
                else
                {
                    sql += "null,";
                }

                if (!string.IsNullOrEmpty(model.ModifyId))
                {
                    sql += "'" + model.ModifyId.ToString() + "',";
                }
                else
                {
                    sql += "null,";
                }

                if (!string.IsNullOrEmpty(model.ModifyName))
                {
                    sql += "'" + model.ModifyName.ToString() + "',";
                }
                else
                {
                    sql += "null,";
                }

                sql += "'" + model.CreateTime.ToString() + "',";

                if (!string.IsNullOrEmpty(model.CreatorId))
                {
                    sql += "'" + model.CreatorId.ToString() + "',";
                }
                else
                {
                    sql += "null,";
                }

                if (!string.IsNullOrEmpty(model.CreatorName))
                {
                    sql += "'" + model.CreatorName.ToString() + "',";
                }
                else
                {
                    sql += "null,";
                }

                if (!string.IsNullOrEmpty(model.TenantId))
                {
                    sql += "'" + model.TenantId.ToString() + "',";
                }
                else
                {
                    sql += "null,";
                }

            

                sql = sql.Substring(0, sql.Length - 1) + ")";




            }

            int result = _dbHelper.ExecuteSql(sql);

            AjaxResult<int> backResult;
            if (result >= 0)
            {
                backResult = new AjaxResult<int>
                {
                    Success = true,
                    Msg = ""
                };
            }
            else
            {
                backResult = new AjaxResult<int>
                {
                    Success = false,
                    Msg = "数据保存失败"
                };
            }

            return backResult;
        }


        public async Task<List<Base_ActionTree>> GetMenuTreeList(Base_ActionsInputDTO input)
        {
            input.Types = new ActionType[] { ActionType.菜单, ActionType.页面 };

            return await GetActionTreeDataList(input);
        }

        public async Task<List<Entity.TreeModel.Base_ActionTree>> GetActionTreeDataList(Base_ActionsInputDTO input)
        {



            var qList = await GetTreeDataListAsync(input);
            var treeList = qList.Data.Select(x => new Entity.TreeModel.Base_ActionTree
            {
                Id = x.Id,
                NeedAction = x.NeedAction,
                Text = x.Name,
                ParentId = x.ParentId,
                Type = (ActionType)x.Type,
                Url = x.Url,
                Value = x.Id,
                Icon = x.Icon,
                Sort = x.Sort
            }).OrderBy(p => p.Sort).ToList();

            //菜单节点中,若子节点为空则移除父节点
            //treeList = treeList.Where(x => x.Type != 0 || TreeHelper.GetChildren(treeList, x, false).Count > 0).ToList();

            await SetProperty(treeList);

            return TreeHelper.BuildGenericsTree(treeList); ;

            async Task SetProperty(List<Entity.TreeModel.Base_ActionTree> _list)
            {
                var ids = _list.Select(x => x.Id).ToList();

                //var allPermissions = await GetIQueryable()
                //    .Where(x => ids.Contains(x.ParentId) && (int)x.Type == (int)ActionType.权限)
                //    .ToListAsync();

                string sql = "select * from Base_Action where Type = " + (int)ActionType.权限;

                if (ids.Count > 0)
                {
                    string idQuerySql = " and ParentId in (";

                    foreach (var idItem in ids)
                    {
                        idQuerySql += "'" + idItem + "',";
                    }

                    idQuerySql = idQuerySql.Substring(0, idQuerySql.Length - 1);

                    idQuerySql += ")";

                    sql += idQuerySql;
                }

                System.Data.DataTable table = _dbHelper.GetDataTableWithSql(sql);
                List<Base_Action> allPermissions = Extention.ToList<Base_Action>(table);

                _list.ForEach(aData =>
                {
                    var permissionValues = allPermissions
                        .Where(x => x.ParentId == aData.Id)
                        .Select(x => $"{x.Name}({x.Value})")
                        .ToList();

                    aData.PermissionValues = permissionValues;
                });
            }
        }

        public async Task<List<Base_Dictionary>> GetDictionaryDataList(SearchInput input)
        {
            string sql = " select * from Base_Dictionary order by  " + input.SortField + " " + input.SortType;
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(sql);

            if (table != null && table.Rows.Count > 0)
            {
                //List<Base_Dictionary> dicList = Extention.ToList<Base_Dictionary>(table);

                List<Base_Dictionary> dicList = new List<Base_Dictionary>();
                foreach (DataRow itemRow in table.Rows)
                {
                    try
                    {


                        dicList.Add(new Base_Dictionary
                        {
                            Code = itemRow["Code"].ToString(),
                            ControlType = (ControlType)Convert.ToInt32(itemRow["ControlType"]),
                            CreateTime = itemRow["CreateTime"] != DBNull.Value ? Convert.ToDateTime(itemRow["CreateTime"]) : DateTime.MinValue,
                            ModifyTime = itemRow["ModifyTime"] != DBNull.Value ? Convert.ToDateTime(itemRow["ModifyTime"]) : null,
                            ModifyName = itemRow["ModifyName"].ToString(),
                            CreatorId = itemRow["CreatorId"].ToString(),
                            Value = itemRow["Value"].ToString(),
                            CreatorName = itemRow["CreatorName"].ToString(),
                            Deleted = Convert.ToBoolean(itemRow["Deleted"]),
                            Id = itemRow["Id"].ToString(),
                            ModifyId = itemRow["ModifyId"].ToString(),
                            ParentId = itemRow["ParentId"].ToString(),
                            Remark = itemRow["Remark"].ToString(),
                            Sort = Convert.ToInt32(itemRow["Sort"]),
                            TenantId = itemRow["TenantId"].ToString(),
                            Text = itemRow["Text"].ToString(),
                            Type = Convert.ToInt32(itemRow["Type"])

                        });
                    }
                    catch (Exception e) {

                    }

                }

                return dicList;
            }

            return null;


        }

        public async Task<List<Base_DictionaryTree>> GetDic_TreeDataList(SearchInput input)
        {
            input.SortField = "Sort";
            var qList = await GetDictionaryDataList(input);


            if (qList != null && qList.Count > 0)
            {

                var treeList = qList.Select(x => new Base_DictionaryTree
                {
                    Id = x.Id,
                    Code = x.Code,
                    ParentId = x.ParentId,
                    Type = (DictionaryType)x.Type,
                    ControlType = x.ControlType,
                    Text = x.Text,
                    Value = x.Value,
                    Sort = x.Sort,
                    Remark = x.Remark

                }).ToList();

                return TreeHelper.BuildGenericsTree(treeList);
            }

            return null;

        }

        public async Task<ObservableCollection<SelectOption>> GetBase_UserOptionList()
        {
            string sql = " select * from Base_User";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(sql);
            List<Base_User> userList = Extention.ToList<Base_User>(table);

            List<SelectOption> tempResult = userList.Select(s => new SelectOption
            {
                Text = s.UserName,
                Value = s.Id
            }).ToList();


            ObservableCollection<SelectOption> result = new ObservableCollection<SelectOption>();
            result.AddRange(tempResult);

            return result;

        }



        /// <summary>
        /// 获取菜单
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<AjaxResult<List<Base_Action>>> GetTreeDataListAsync(Base_ActionsInputDTO input)
        {

            string typeArrayStr = "";
            string actionIdArrayStr = "";

            string sql = "select * from Base_Action where 1=1  ";


            if (!string.IsNullOrEmpty(input.ParentId))
            {
                sql += " And ParentId ='" + input.ParentId + "'";
            }

            if (input.Types != null && input.Types.Length > 0)
            {
                string typeQuerySql = " and Type in (";

                foreach (var typeItem in input.Types)
                {
                    typeQuerySql += (int)typeItem + ",";
                }

                typeQuerySql = typeQuerySql.Substring(0, typeQuerySql.Length - 1);

                typeQuerySql += ")";

                sql += typeQuerySql;

            }

            if (input.ActionIds != null && input.ActionIds.Length > 0)
            {
                string idQuerySql = " and Id in (";

                foreach (var idItem in input.ActionIds)
                {
                    idQuerySql += "'" + idItem + "',";
                }

                idQuerySql = idQuerySql.Substring(0, idQuerySql.Length - 1);

                idQuerySql += ")";

                sql += idQuerySql;
            }

            sql += " order by CreateTime ";

            System.Data.DataTable tempTable = _dbHelper.GetDataTableWithSql(sql);

            if (tempTable != null && tempTable.Rows.Count > 0)
            {

                List<Base_Action> list = Extention.ToList<Base_Action>(tempTable);

                return new AjaxResult<List<Base_Action>> {
                    Success = true,
                    Data = list
                };
            }

            return new AjaxResult<List<Base_Action>> {
                Success = false,
                Msg = "获取菜单数据为空"
            };

        }

        #region  Base_Action

        public async Task<List<Base_ActionTree>> Action_GetDataList(Base_ActionsInputDTO input)
        {
            input.Types = new ActionType[] { ActionType.菜单, ActionType.页面 };
            return await this.GetActionTreeDataList(input);
        }


        /// <summary>
        /// Base_YunData  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<Base_ActionDTO> Action_GetTheData(string id)
        {

            if (string.IsNullOrEmpty(id))
                return null;

            string sql = string.Format("select * from Base_Action  where Id = '{0}';", id);
            List<Base_ActionDTO> tempData = _dbHelper.GetListBySql<Base_ActionDTO>(sql);

            return tempData.FirstOrDefault();
        }

        public async Task<AjaxResult<List<Base_ActionDTO>>> GetPermissionList(Base_ActionsInputDTO input)
        {
            input.Types = new ActionType[] { ActionType.权限 };

            AjaxResult<List<Base_Action>> tempResult = await GetTreeDataListAsync(input);

            if (tempResult.Success)
            {
                List<Base_ActionDTO> result = tempResult.Data.Select(d => new Base_ActionDTO
                {
                    CreateTime = d.CreateTime,
                    CreatorId = d.CreatorId,
                    CreatorName = d.CreatorName,
                    Deleted = d.Deleted,
                    ModifyId = d.ModifyId,
                    ModifyName = d.ModifyName,
                    ModifyTime = d.ModifyTime,
                    NeedAction = d.NeedAction,
                    Name = d.Name,
                    ParentId = d.ParentId,
                    Sort = d.Sort,
                    TenantId = d.TenantId,
                    Type = d.Type,
                    Url = d.Url,
                    Value = d.Value,
                    Id = d.Id,
                    Icon = d.Icon


                }).ToList();


                return new AjaxResult<List<Base_ActionDTO>> { Success = true, Data = result };
            }
            else
            {
                return new AjaxResult<List<Base_ActionDTO>> { Success = false, Msg = tempResult.Msg };
            }


        }
        /// <summary>
        /// 删除Base_Action记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public async Task<int> Action_Delete(List<string> ids)
        {
            return await DeleteByIds("Base_Action",ids);
        }

        /// <summary>
        /// 修改Base_Action记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<AjaxResult<int>> Action_Update(Base_Action model)
        {
            int beforeUpdateResult = await this.CheckBeforeUpdate("Base_Action", "Name", model.Name,model.Id);
            if (beforeUpdateResult < 0)
            {
                return new AjaxResult<int>
                {
                    Success = false,
                    Msg = "添加失败，已存在重复数据"
                };
            }

            string sql = "";
            if (!string.IsNullOrEmpty(model.Id))
            {
                sql = "update Base_Action set ";

                if (!string.IsNullOrEmpty(model.ParentId))
                {
                    sql += " ParentId='" + model.ParentId + "',";
                }
                else
                {
                    sql += " ParentId='',";
                }

                sql += " Type=" + model.Type + ",";

                if (!string.IsNullOrEmpty(model.Name))
                {
                    sql += " Name='" + model.Name + "',";
                }
                else
                {
                    sql += " Name='',";
                }

                if (!string.IsNullOrEmpty(model.Url))
                {
                    sql += " Url='" + model.Url + "',";
                }
                else
                {
                    sql += " Url='',";
                }

                if (!string.IsNullOrEmpty(model.Value))
                {
                    sql += " Value='" + model.Value + "',";
                }
                else
                {
                    sql += " Value='',";
                }

                int needAction = Convert.ToInt32(model.NeedAction);
                sql += " NeedAction=" + needAction + ",";

                if (!string.IsNullOrEmpty(model.Icon))
                {
                    sql += " Icon='" + model.Icon + "',";
                }
                else
                {
                    sql += " Icon='',";
                }

                sql += " Sort=" + model.Sort + ",";

                int deleted = Convert.ToInt32(model.Deleted);
                sql += " Deleted=" + deleted + ",";

                if (model.ModifyTime.HasValue)
                {
                    sql += " ModifyTime='" + model.ModifyTime.ToString() + "',";
                }
                else
                {
                    sql += " ModifyTime = null,";
                }

                if (!string.IsNullOrEmpty(model.ModifyId))
                {
                    sql += " ModifyId='" + model.ModifyId.ToString() + "',";
                }
                else
                {
                    sql += " ModifyId ='',";
                }

                if (!string.IsNullOrEmpty(model.ModifyName))
                {
                    sql += " ModifyName='" + model.ModifyName.ToString() + "',";
                }
                else
                {
                    sql += " ModifyName ='',";
                }


                sql += " CreateTime='" + model.CreateTime.ToString() + "',";


                if (!string.IsNullOrEmpty(model.CreatorId))
                {
                    sql += " CreatorId='" + model.CreatorId.ToString() + "',";
                }
                else
                {
                    sql += " CreatorId ='',";
                }

                if (!string.IsNullOrEmpty(model.CreatorName))
                {
                    sql += " CreatorName='" + model.CreatorName.ToString() + "',";
                }
                else
                {
                    sql += " CreatorName ='',";
                }

                if (!string.IsNullOrEmpty(model.TenantId))
                {
                    sql += " TenantId='" + model.TenantId.ToString() + "',";
                }
                else
                {
                    sql += " TenantId ='',";
                }

                sql = sql.Substring(0, sql.Length - 1);

                sql += " where Id ='" + model.Id.ToString() + "'";


            }
            else
            {

              

                string strNull = " null,";

                sql = "insert into Base_Action (Id,ParentId,Type,Name,Url,Value,NeedAction,Icon,Sort,Deleted,ModifyTime,ModifyId,ModifyName,CreateTime,CreatorId,CreatorName,TenantId) values('";

                //Id
                sql += Guid.NewGuid() + "',";

                //ParentId
                if (string.IsNullOrEmpty(model.ParentId))
                {
                    sql += strNull;
                }
                else
                {
                    sql += "'" + model.ParentId + "',";
                }

                //Type
                sql += model.Type + ",";

                //Name
                if (string.IsNullOrEmpty(model.Name))
                {
                    sql += strNull;
                }
                else
                {
                    sql += "'" + model.Name + "',";
                }

                //Url
                if (string.IsNullOrEmpty(model.Url))
                {
                    sql += strNull;
                }
                else
                {
                    sql += "'" + model.Url + "',";
                }

                //Value
                if (string.IsNullOrEmpty(model.Value))
                {
                    sql += strNull;
                }
                else
                {
                    sql += "'" + model.Value + "',";
                }

                //NeedAction
                if (model.NeedAction)
                {
                    sql += "1,";
                }
                else
                {
                    sql += "0,";
                }

                //Icon
                if (string.IsNullOrEmpty(model.Icon))
                {
                    sql += strNull;
                }
                else
                {
                    sql += "'" + model.Icon + "',";
                }

                //Sort
                sql += model.Sort + ",";

                //Deleted
                if (model.Deleted)
                {
                    sql += "1,";
                }
                else
                {
                    sql += "0,";
                }

                //ModifyTime
                if (!model.ModifyTime.HasValue)
                {
                    sql += strNull;
                }
                else
                {
                    sql += "'" + model.ModifyTime.ToString() + "',";
                }

                //ModifyId
                if (string.IsNullOrEmpty(model.ModifyId))
                {
                    sql += strNull;
                }
                else
                {
                    sql += "'" + model.ModifyId + "',";
                }

                //ModifyName
                if (string.IsNullOrEmpty(model.ModifyName))
                {
                    sql += strNull;
                }
                else
                {
                    sql += "'" + model.ModifyName + "',";
                }

                //CreateTime
                sql += "'" + DateTime.Now.ToString() + "',";

                //CreatorId
                if (string.IsNullOrEmpty(model.CreatorId))
                {
                    sql += strNull;
                }
                else
                {
                    sql += "'" + model.CreatorId + "',";
                }

                //CreatorName
                if (string.IsNullOrEmpty(model.CreatorName))
                {
                    sql += strNull;
                }
                else
                {
                    sql += "'" + model.CreatorName + "',";
                }

                //TenantId
                if (string.IsNullOrEmpty(model.TenantId))
                {
                    sql += strNull;
                }
                else
                {
                    sql += "'" + model.TenantId + "',";
                }

                sql = sql.Substring(0, sql.Length - 1) + ")";




            }

            int result = _dbHelper.ExecuteSql(sql);

            AjaxResult<int> backResult;
            if (result >= 0)
            {
                backResult = new AjaxResult<int>
                {
                    Success = true,
                    Msg = ""
                };
            }
            else
            {
                backResult = new AjaxResult<int>
                {
                    Success = false,
                    Msg = "数据保存失败"
                };
            }

            return backResult;

        }

        #endregion

        #region   Base_YunData

        /// <summary>
        /// Base_YunData表根据ids删除记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public async Task<int> YunData_Delete(List<string> ids)
        {
            return await DeleteByIds("Base_YunData", ids);
        }

        /// <summary>
        /// 查询展示yun_data
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<PageResult<Base_YunDataDTO>> YunData_GetDataList(PageInput input)
        {
            if (input.PageIndex < 1)
                input.PageIndex = 1;

            string sql = "select OrderDate,OrderNo,Customer,Shop,UserSign,Id from Base_YunData where 1=1";
            string countSql = "select count(*) from Base_YunData where 1=1";



            if (input.StartTime.HasValue)
            {
                sql += " And OrderDate>='" + input.StartTime.Value + "'";
                countSql += " And OrderDate>='" + input.StartTime.Value + "'";
            }

            if (input.EndTime.HasValue)
            {
                sql += " And OrderDate<='" + input.EndTime.Value + "'";
                countSql += " And OrderDate<='" + input.EndTime.Value + "'";
            }

            if (input.SearchKeyValues.Count > 0)
            {
                if (input.SearchKeyValues["OrderNo"] != null && input.SearchKeyValues["OrderNo"].ToString() != "")
                {
                    sql += " And OrderNo='" + input.SearchKeyValues["OrderNo"].ToString() + "'";
                    countSql += " And OrderNo='" + input.SearchKeyValues["OrderNo"].ToString() + "'";
                }
                if (input.SearchKeyValues["Shop"] != null && input.SearchKeyValues["Shop"].ToString() != "")
                {
                    sql += " And Shop='" + input.SearchKeyValues["Shop"].ToString() + "'";
                    countSql += " And Shop='" + input.SearchKeyValues["Shop"].ToString() + "'";
                }
                if (input.SearchKeyValues["Customer"] != null && input.SearchKeyValues["Customer"].ToString() != "")
                {
                    sql += " And Customer='" + input.SearchKeyValues["Customer"].ToString() + "'";
                    countSql += " And Customer='" + input.SearchKeyValues["Customer"].ToString() + "'";
                }
                if (input.SearchKeyValues["UserSign"] != null && input.SearchKeyValues["UserSign"].ToString() != "")
                {
                    if (!string.IsNullOrEmpty(CurrentUserSign))
                    {
                        if (CurrentUserSign == "admin")
                        {
                            sql += " And UserSign='" + input.SearchKeyValues["UserSign"].ToString() + "'";
                            countSql += " And UserSign='" + input.SearchKeyValues["UserSign"].ToString() + "'";
                        }
                        else
                        {
                            sql += " And UserSign='" + CurrentUserSign + "'";
                            countSql += " And UserSign='" + CurrentUserSign + "'";
                        }
                    }
                }
            }


            if (!string.IsNullOrEmpty(CurrentUserSign) && CurrentUserSign != "admin")
            {
                sql += " And UserSign='" + CurrentUserSign + "'";
                countSql += " And UserSign='" + CurrentUserSign + "'";
            }

            sql += " order by Id ";

            string pageSql = string.Format(" offset {0} rows fetch next {1} rows only ;", (input.PageIndex - 1) * input.PageRows, input.PageRows);

            string pageResultSql = sql + pageSql;


            List<Base_YunDataDTO> tempData = _dbHelper.GetListBySql<Base_YunDataDTO>(pageResultSql);

            // string sql1 = "select count(*) from Base_YunData";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(countSql);
            string countStr = table.Rows[0][0].ToString();
            int total = Convert.ToInt32(countStr);
            var list = new PageResult<Base_YunDataDTO> { Data = tempData, Total = total };

            list.Success = true;

            return list;

        }


        /// <summary>
        /// 查询导出yun_data
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<System.Data.DataTable> YunData_GetDataTableToExcel(PageInput input)
        {
            if (input.PageIndex < 1)
                input.PageIndex = 1;

            string sql = "select top 500000 OrderDate as '日期',OrderNo as '单号',Customer as '客户',shop as '店铺',UserSign as '操作人标识'  from Base_YunData where 1=1";

            if (input.StartTime.HasValue)
            {
                sql += " And OrderDate>=" + input.StartTime.Value;
            }

            if (input.EndTime.HasValue)
            {
                sql += " And OrderDate>=" + input.EndTime.Value;
            }

            if (input.SearchKeyValues.Count > 0)
            {
                if (input.SearchKeyValues["OrderNo"] != null && !string.IsNullOrEmpty(input.SearchKeyValues["OrderNo"].ToString()))
                {
                    sql += " And OrderNo='" + input.SearchKeyValues["OrderNo"].ToString() + "'";
                }
                if (input.SearchKeyValues["Shop"] != null && !string.IsNullOrEmpty(input.SearchKeyValues["Shop"].ToString()))
                {
                    sql += " And Shop='" + input.SearchKeyValues["Shop"].ToString() + "'";
                }
                if (input.SearchKeyValues["Customer"] != null && !string.IsNullOrEmpty(input.SearchKeyValues["Customer"].ToString()))
                {
                    sql += " And Customer='" + input.SearchKeyValues["Customer"].ToString() + "'";
                }
                if (input.SearchKeyValues["UserSign"] != null&& !string.IsNullOrEmpty(input.SearchKeyValues["UserSign"].ToString()))
                {
                    sql += " And UserSign='" + input.SearchKeyValues["UserSign"].ToString() + "'";
                }
            }


            sql += " order by OrderDate;";


            System.Data.DataTable tempTable = _dbHelper.GetDataTableWithSql(sql);

            return tempTable;



        }


        /// <summary>
        /// 根据id查询yun_data 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<PageResult<Base_YunDataDTO>> YunData_GetTheData(string id)
        {
            if (string.IsNullOrEmpty(id))
                return null;

            string sql = string.Format("select * from Base_YunData  where Id = '{0}' order by OrderDate;", id);
            List<Base_YunDataDTO> tempData = _dbHelper.GetListBySql<Base_YunDataDTO>(sql);
            var list = new PageResult<Base_YunDataDTO> { Data = tempData, Total = 1 };
            list.Success = true;
            return list;

        }


        /// <summary>
        /// 修改Base_YunData记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<int> UpdateYunDataById(Base_YunData model)
        {
            if (string.IsNullOrEmpty(model.Id))
                return 0;

            string sql = "update Base_YunData set ";

            if (model.OrderDate.HasValue)
            {
                sql += " OrderDate='" + model.OrderDate.ToString() + "',";
            }
            else {
                sql += " OrderDate=null,";
            }

            if (!string.IsNullOrEmpty(model.OrderNo))
            {
                sql += " OrderNo='" + model.OrderNo + "',";
            }
            else
            {
                sql += " OrderNo='',";
            }

            if (!string.IsNullOrEmpty(model.Shop))
            {
                sql += " Shop='" + model.Shop + "',";
            }
            else
            {
                sql += " Shop='',";
            }

            if (!string.IsNullOrEmpty(model.Customer))
            {
                sql += " Customer='" + model.Customer + "',";
            }
            else
            {
                sql += " Customer='',";
            }

            if (!string.IsNullOrEmpty(model.UserSign))
            {
                sql += " UserSign='" + model.UserSign + "',";
            }
            else
            {
                sql += " UserSign='',";
            }

            sql = sql.Substring(0, sql.Length - 1);

            sql += " where Id ='" + model.Id.ToString() + "'";

            int result = _dbHelper.ExecuteSql(sql);

            return result;

        }


        /// <summary>
        /// Base_YunData 根据OrderNo,UserSign 去重
        /// </summary>
        /// <returns></returns>
        public async Task<int> YunData_DeleteSameRecord(int count)
        {
            if (count < 50000)
            {
                count = 50000;
            }

            //根据OrderNo,UserSign 两个个字段查询出重复的数据
            string sql = "DELETE FROM Base_YunData WHERE Id IN (";

            sql += "SELECT Id FROM (";
            sql += "SELECT top 300000 Id, DBCount = ROW_NUMBER() OVER(PARTITION BY OrderNo, UserSign ORDER BY Id)  FROM Base_YunData order by OrderDate desc ) Tmp ";
            sql += " WHERE DBCount > 1)";

            int result = _dbHelper.ExecuteSql(sql);

            return result;
        }


        #endregion

        #region  Base_CustomerRecord

        public async Task<System.Data.DataTable> CustomerRecord_ToExcel(PageInput input)
        {
            if (input.PageIndex < 1)
                input.PageIndex = 1;

            string sql = "select top 100000 Wangwang as '旺旺',Customer as '客户',shop as '店铺',UserSign as '操作人标识'  from Base_CustomerRecord where 1=1";



            if (input.SearchKeyValues.Count > 0)
            {
                if (input.SearchKeyValues["Wangwang"] != null && !string.IsNullOrEmpty(input.SearchKeyValues["Wangwang"].ToString()))
                {
                    sql += " And Wangwang='" + input.SearchKeyValues["Wangwang"].ToString() + "'";
                }
                if (input.SearchKeyValues["Shop"] != null&& !string.IsNullOrEmpty(input.SearchKeyValues["Shop"].ToString()))
                {
                    sql += " And Shop='" + input.SearchKeyValues["Shop"].ToString() + "'";
                }
                if (input.SearchKeyValues["Customer"] != null && !string.IsNullOrEmpty(input.SearchKeyValues["Customer"].ToString()))
                {
                    sql += " And Customer='" + input.SearchKeyValues["Customer"].ToString() + "'";
                }
                if (input.SearchKeyValues["UserSign"] != null && !string.IsNullOrEmpty(input.SearchKeyValues["UserSign"].ToString()))
                {
                    sql += " And UserSign='" + input.SearchKeyValues["UserSign"].ToString() + "'";
                }
            }


            System.Data.DataTable tempTable = _dbHelper.GetDataTableWithSql(sql);

            return tempTable;
        }


        /// <summary>
        /// 客户资料查询分页
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<PageResult<Base_CustomerRecordDTO>> CustomerRecord_GetDataList(PageInput input)
        {
            if (input.PageIndex < 1)
                input.PageIndex = 1;

            string sql = "select * from Base_CustomerRecord where 1=1";
            string countSql = "select count(*) from Base_CustomerRecord where 1=1";



            if (input.SearchKeyValues.Count > 0)
            {
                if (input.SearchKeyValues["Wangwang"] != null && input.SearchKeyValues["Wangwang"].ToString() != "")
                {
                    sql += " And Wangwang='" + input.SearchKeyValues["Wangwang"].ToString() + "'";
                    countSql += " And Wangwang='" + input.SearchKeyValues["Wangwang"].ToString() + "'";
                }
                if (input.SearchKeyValues["Shop"] != null && input.SearchKeyValues["Shop"].ToString() != "")
                {
                    sql += " And Shop='" + input.SearchKeyValues["Shop"].ToString() + "'";
                    countSql += " And Shop='" + input.SearchKeyValues["Shop"].ToString() + "'";
                }
                if (input.SearchKeyValues["Customer"] != null && input.SearchKeyValues["Customer"].ToString() != "")
                {
                    sql += " And Customer='" + input.SearchKeyValues["Customer"].ToString() + "'";
                    countSql += " And Customer='" + input.SearchKeyValues["Customer"].ToString() + "'";
                }
                if (input.SearchKeyValues["UserSign"] != null && input.SearchKeyValues["UserSign"].ToString() != "")
                {
                    if (!string.IsNullOrEmpty(CurrentUserSign))
                    {
                        if ( CurrentUserSign == "admin")
                        {
                            sql += " And UserSign='" + input.SearchKeyValues["UserSign"].ToString() + "'";
                            countSql += " And UserSign='" + input.SearchKeyValues["UserSign"].ToString() + "'";
                        }
                        else
                        {
                            sql += " And UserSign='" +CurrentUserSign + "'";
                            countSql += " And UserSign='" + CurrentUserSign + "'";
                        }
                    }
                   

                }
               
            }


            if (!string.IsNullOrEmpty(CurrentUserSign)&&CurrentUserSign != "admin")
            {
                sql += " And UserSign='" + CurrentUserSign + "'";
                countSql += " And UserSign='" + CurrentUserSign + "'";
            }


            sql += " order by Id desc";

            string pageSql = string.Format(" offset {0} rows fetch next {1} rows only ;", (input.PageIndex - 1) * input.PageRows, input.PageRows);

            string pageResultSql = sql + pageSql;


            List<Base_CustomerRecordDTO> tempData = _dbHelper.GetListBySql<Base_CustomerRecordDTO>(pageResultSql);

            // string sql1 = "select count(*) from Base_YunData";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(countSql);
            string countStr = table.Rows[0][0].ToString();
            int total = Convert.ToInt32(countStr);
            var list = new PageResult<Base_CustomerRecordDTO> { Data = tempData, Total = total };

            list.Success = true;

            return list;

        }


        /// <summary>
        /// Base_YunData  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<PageResult<Base_CustomerRecordDTO>> CustomerRecord_GetTheData(string id)
        {
            if (string.IsNullOrEmpty(id))
                return null;

            string sql = string.Format("select * from Base_CustomerRecord  where Id = '{0}';", id);
            List<Base_CustomerRecordDTO> tempData = _dbHelper.GetListBySql<Base_CustomerRecordDTO>(sql);
            var list = new PageResult<Base_CustomerRecordDTO> { Data = tempData, Total = 1 };
            list.Success = true;
            return list;
        }


        /// <summary>
        /// 删除Base_YunData记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public async Task<int> CustomerRecord_Delete(List<string> ids)
        {


            return await DeleteByIds("Base_CustomerRecord", ids);
        }

        /// <summary>
        /// 修改Base_CustomerRecord记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<AjaxResult<int>> CustomerRecord_Update(Base_CustomerRecord model)
        {
            int beforeUpdateResult = await this.CheckBeforeUpdate("Base_CustomerRecord", "UserSign", model.UserSign,model.Id);
            if (beforeUpdateResult < 0)
            {
                return new AjaxResult<int>
                {
                    Success = false,
                    Msg = "已存在重复数据[操作人标识]"
                };
            }

            string sql = "";

            if (!string.IsNullOrEmpty(model.Id))
            {

                 sql = "update Base_CustomerRecord set ";


                if (!string.IsNullOrEmpty(model.Wangwang))
                {
                    sql += " Wangwang='" + model.Wangwang + "',";
                }
                else
                {
                    sql += " Wangwang='',";
                }

                if (!string.IsNullOrEmpty(model.Shop))
                {
                    sql += " Shop='" + model.Shop + "',";
                }
                else
                {
                    sql += " Shop='',";
                }

                if (!string.IsNullOrEmpty(model.Customer))
                {
                    sql += " Customer='" + model.Customer + "',";
                }
                else
                {
                    sql += " Customer='',";
                }

                if (!string.IsNullOrEmpty(model.UserSign))
                {
                    sql += " UserSign='" + model.UserSign + "',";
                }
                else
                {
                    sql += " UserSign='',";
                }

                sql = sql.Substring(0, sql.Length - 1);

                sql += " where Id ='" + model.Id.ToString() + "'";
            }
            else
            {

                model.Id = Guid.NewGuid().ToString();

                sql = "insert into Base_CustomerRecord (Shop,Wangwang,Customer,UserSign,Id) values('";

              


                if (!string.IsNullOrEmpty(model.Shop))
                {
                    sql += "'" + model.Shop + "',";
                }
                else
                {
                    sql += "'',";
                }

                if (!string.IsNullOrEmpty(model.Wangwang))
                {
                    sql += "'" + model.Wangwang + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.Customer))
                {
                    sql += "'" + model.Customer + "',";
                }
                else
                {
                    sql += " null,";
                }


                if (!string.IsNullOrEmpty(model.UserSign))
                {
                    sql += "'" + model.UserSign + "',";
                }
                else
                {
                    sql += " null,";
                }

                sql +="'"+ model.Id + "',";

                sql = sql.Substring(0, sql.Length - 1);

                sql += ");";
            }

            int result = _dbHelper.ExecuteSql(sql);

            AjaxResult<int> returnResult;
            if (result >= 0)
            {

                //新增或修改后，更新未匹配的出货记录
                UpdateSellRecordByNewCustomer();

                returnResult = new AjaxResult<int>
                {
                    Success = true,
                    Data = result
                };

            }
            else
            {
                returnResult = new AjaxResult<int>
                {
                    Success = false,
                    Msg = "数据库保存失败"
                };
            }
            return returnResult;

        
        }



        /// <summary>
        /// 新增或修改客户信息后，更新未匹配的出货记录
        /// </summary>
        /// <returns></returns>
        public async Task<int> UpdateSellRecordByNewCustomer()
        {
            string sql = " UPDATE a SET a.Customer = b.Customer,a.Shop = b.Shop,a.HasMatch = 1 FROM ";
            sql += " (SELECT  OrderNo, Shop, HasMatch, Customer, OrderDate, Wangwang FROM Base_SellRecord where HasMatch = 0 order by OrderDate desc) a,";
            sql += " (SELECT Customer, Shop, Wangwang FROM Base_CustomerRecord where Customer is not null ) b WHERE  a.Wangwang = b.Wangwang;";

           int result  =   _dbHelper.ExecuteSql(sql);

            return 1;
        }

        #endregion

        #region  Base_User

        public async Task<PageResult<Base_UserDTO>> User_GetDataList(PageInput input)
        {
            if (input.PageIndex < 1)
                input.PageIndex = 1;

            string sql = "select * from Base_User where 1=1";
            string countSql = "select count(*) from Base_User where 1=1";



            if (input.SearchKeyValues.Count > 0)
            {
                if (input.SearchKeyValues["UserName"] != null && input.SearchKeyValues["Wangwang"].ToString() != "")
                {
                    sql += " And UserName like '" + input.SearchKeyValues["UserName"].ToString() + "%'";
                    countSql += " And UserName like '" + input.SearchKeyValues["UserName"].ToString() + "%'";
                }
                if (input.SearchKeyValues["RealName"] != null && input.SearchKeyValues["RealName"].ToString() != "")
                {
                    sql += " And RealName like '" + input.SearchKeyValues["RealName"].ToString() + "%'";
                    countSql += " And RealName like '" + input.SearchKeyValues["RealName"].ToString() + "%'";
                }

                if (input.SearchKeyValues["UserSign"] != null && input.SearchKeyValues["UserSign"].ToString() != "")
                {
                    sql += " And UserSign='" + input.SearchKeyValues["UserSign"].ToString() + "'";
                    countSql += " And UserSign='" + input.SearchKeyValues["UserSign"].ToString() + "'";
                }

            }

            sql += " order by Id desc";

            string pageSql = string.Format(" offset {0} rows fetch next {1} rows only ;", (input.PageIndex - 1) * input.PageRows, input.PageRows);

            string pageResultSql = sql + pageSql;


            List<Base_UserDTO> tempData = _dbHelper.GetListBySql<Base_UserDTO>(pageResultSql);

            // string sql1 = "select count(*) from Base_YunData";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(countSql);
            string countStr = table.Rows[0][0].ToString();
            int total = Convert.ToInt32(countStr);
            var list = new PageResult<Base_UserDTO> { Data = tempData, Total = total };

            list.Success = true;

            return list;
        }


        /// <summary>
        /// Base_YunData  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<PageResult<Base_UserDTO>> User_GetTheData(string id)
        {
            if (string.IsNullOrEmpty(id))
                return null;

            string sql = string.Format("select * from Base_User  where Id = '{0}';", id);
            List<Base_UserDTO> tempData = _dbHelper.GetListBySql<Base_UserDTO>(sql);
            var list = new PageResult<Base_UserDTO> { Data = tempData, Total = 1 };
            list.Success = true;
            return list;
        }


        /// <summary>
        /// 删除Base_YunData记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public async Task<int> User_Delete(List<string> ids)
        {
            return await DeleteByIds("Base_User", ids);
        }

        /// <summary>
        /// 修改Base_YunData记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<AjaxResult<int>> User_Update(Base_User model)
        {
            int beforeUpdateResult = await this.CheckBeforeUpdate("Base_User", "UserSign", model.UserSign, model.Id);
            if (beforeUpdateResult < 0)
            {
                return new AjaxResult<int>
                {
                    Success = false,
                    Msg = "已存在重复数据[操作人标识]"
                };
            }

            string sql = "";


            if (string.IsNullOrEmpty(model.Id))
            {
                model.Id = Guid.NewGuid().ToString();

                sql = "insert into Base_User (Id,UserName,PassWord,RealName,Sex,Birthday,DepartmentId,PhoneNumber,Avatar,Deleted,ModifyTime,ModifyId,ModifyName,CreateTime,CreatorId,CreatorName,TenantId) values('";

                sql += model.Id + "',";


                if (!string.IsNullOrEmpty(model.UserName))
                {
                    sql += "'" + model.UserName + "',";
                }
                else
                {
                    sql += "'',";
                }

                if (!string.IsNullOrEmpty(model.Password))
                {
                    sql += "'" + model.Password + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.RealName))
                {
                    sql += "'" + model.RealName + "',";
                }
                else
                {
                    sql += " null,";
                }

                sql += model.Sex + ",";

                if (model.Birthday.HasValue)
                {
                    sql += "'"+model.Birthday.Value.ToString() + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.DepartmentId))
                {
                    sql += "'" + model.DepartmentId + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.PhoneNumber))
                {
                    sql += "'" + model.PhoneNumber + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.Avatar))
                {
                    sql += "'" + model.Avatar + "',";
                }
                else
                {
                    sql += " null,";
                }

                sql += "0,";

                if (model.ModifyTime.HasValue)
                {
                    sql += "'" + model.ModifyTime.Value.ToString() + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.ModifyId))
                {
                    sql += "'" + model.ModifyId.ToString() + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.ModifyName))
                {
                    sql += "'" + model.ModifyName.ToString() + "',";
                }
                else
                {
                    sql += " null,";
                }

                
                    sql += "'" + model.CreateTime.ToString() + "',";

                if (!string.IsNullOrEmpty(model.CreatorId))
                {
                    sql += "'" + model.CreatorId.ToString() + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.CreatorName))
                {
                    sql += "'" + model.CreatorName.ToString() + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.TenantId))
                {
                    sql += "'" + model.TenantId.ToString() + "',";
                }
                else
                {
                    sql += " null,";
                }

               
                sql = sql.Substring(0, sql.Length - 1);

                sql += ");";
            }
            else
            {

                 sql = "update Base_User set ";


                if (!string.IsNullOrEmpty(model.UserName))
                {
                    sql += " UserName='" + model.UserName + "',";
                }
                else
                {
                    sql += " UserName='',";
                }

                if (!string.IsNullOrEmpty(model.Password))
                {
                    sql += " Password='" + model.Password + "',";
                }
                else
                {
                    sql += " Password='',";
                }

                if (!string.IsNullOrEmpty(model.RealName))
                {
                    sql += " RealName='" + model.RealName + "',";
                }
                else
                {
                    sql += " RealName='',";
                }

                sql += "Sex="+model.Sex+",";

                if (model.Birthday.HasValue)
                {
                    sql += " Birthday='" + model.Birthday.ToString() + "',";
                }
                else
                {
                    sql += " Birthday='',";
                }

                if (!string.IsNullOrEmpty(model.DepartmentId))
                {
                    sql += " DepartmentId='" + model.DepartmentId + "',";
                }
                else
                {
                    sql += " DepartmentId='',";
                }

                if (!string.IsNullOrEmpty(model.PhoneNumber))
                {
                    sql += " PhoneNumber='" + model.PhoneNumber + "',";
                }
                else
                {
                    sql += " PhoneNumber='',";
                }

                if (!string.IsNullOrEmpty(model.Avatar))
                {
                    sql += " Avatar='" + model.Avatar + "',";
                }
                else
                {
                    sql += " Avatar='',";
                }

                if (model.Deleted)
                {
                    sql += " Deleted=1,";
                }
                else
                {
                    sql += " Deleted=0,";
                }

                if (model.ModifyTime.HasValue)
                {
                    sql += " ModifyTime='" + model.ModifyTime.ToString() + "',";
                }


                if (!string.IsNullOrEmpty(model.ModifyId))
                {
                    sql += " ModifyId='" + model.ModifyId + "',";
                }
                else
                {
                    sql += " ModifyId='',";
                }

                if (!string.IsNullOrEmpty(model.ModifyName))
                {
                    sql += " ModifyName='" + model.ModifyName + "',";
                }
                else
                {
                    sql += " ModifyName='',";
                }

                sql += " CreateTime='" + model.CreateTime.ToString() + "',";

                if (!string.IsNullOrEmpty(model.CreatorId))
                {
                    sql += " CreatorId='" + model.CreatorId + "',";
                }
                else
                {
                    sql += " CreatorId='',";
                }

                if (!string.IsNullOrEmpty(model.CreatorName))
                {
                    sql += " CreatorName='" + model.CreatorName + "',";
                }
                else
                {
                    sql += " CreatorName='',";
                }

                if (!string.IsNullOrEmpty(model.TenantId))
                {
                    sql += " TenantId='" + model.TenantId + "',";
                }
                else
                {
                    sql += " TenantId='',";
                }

                if (!string.IsNullOrEmpty(model.UserSign))
                {
                    sql += " UserSign='" + model.UserSign + "',";
                }
                else
                {
                    sql += " UserSign='',";
                }


                sql = sql.Substring(0, sql.Length - 1);

                sql += " where Id ='" + model.Id.ToString() + "'";
            }

            int result = _dbHelper.ExecuteSql(sql);

            AjaxResult<int> returnResult;
            if (result >= 0)
            {
                returnResult = new AjaxResult<int>
                {
                    Success = true,
                    Data = result
                };

            }
            else
            {
                returnResult = new AjaxResult<int>
                {
                    Success = false,
                    Msg = "数据库保存失败"
                };
            }
            return returnResult;
        }

        #endregion




        #region  Base_SellRecord

        /// <summary>
        /// 出货记录查询导出
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<System.Data.DataTable> SellRecord_ToExcel(PageInput input)
        {
            if (input.PageIndex < 1)
                input.PageIndex = 1;

            string sql = "select top 100000 OrderNo as '单号',OrderDate as '日期',YeWuYuan as '业务员',KuaiDi as '快递',Quantity as '件数',Remark as '备注',Cost as '费用',Weight as '重量',Province as '省份', Wangwang as '旺旺',Customer as '客户',shop as '店铺',UserSign as '操作人'  from Base_SellRecord where 1=1";



            if (input.SearchKeyValues.Count > 0)
            {
                if (input.SearchKeyValues["Wangwang"] != null && !string.IsNullOrEmpty(input.SearchKeyValues["Wangwang"].ToString()))
                {
                    sql += " And Wangwang='" + input.SearchKeyValues["Wangwang"].ToString()+"'";
                }
                if (input.SearchKeyValues["Shop"] != null && !string.IsNullOrEmpty(input.SearchKeyValues["Shop"].ToString()))
                {
                    sql += " And Shop='" + input.SearchKeyValues["Shop"].ToString() + "'";
                }
                if (input.SearchKeyValues["Customer"] != null && !string.IsNullOrEmpty(input.SearchKeyValues["Customer"].ToString()))
                {
                    sql += " And Customer='" + input.SearchKeyValues["Customer"].ToString() + "'";
                }
                if (input.SearchKeyValues["UserSign"] != null&& !string.IsNullOrEmpty(input.SearchKeyValues["UserSign"].ToString()))
                {
                    sql += " And UserSign='" + input.SearchKeyValues["UserSign"].ToString() + "'";
                }
                if (input.SearchKeyValues["YeWuYuan"] != null&& !string.IsNullOrEmpty(input.SearchKeyValues["YeWuYuan"].ToString()))
                {
                    sql += " And YeWuYuan='" + input.SearchKeyValues["YeWuYuan"].ToString() + "'";
                }
                if (input.SearchKeyValues["KuaiDi"] != null&& !string.IsNullOrEmpty(input.SearchKeyValues["KuaiDi"].ToString()))
                {
                    sql += " And KuaiDi='" + input.SearchKeyValues["KuaiDi"].ToString() + "'";
                }
                if (input.SearchKeyValues["OrderNo"] != null&& !string.IsNullOrEmpty(input.SearchKeyValues["OrderNo"].ToString()))
                {
                    sql += " And OrderNo='" + input.SearchKeyValues["OrderNo"].ToString()+"'";
                }
            }


            System.Data.DataTable tempTable = _dbHelper.GetDataTableWithSql(sql);

            return tempTable;
        }


        /// <summary>
        /// 出货记录查询分页
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<PageResult<Base_SellRecordDTO>> SellRecord_GetDataList(PageInput input)
        {
            if (input.PageIndex < 1)
                input.PageIndex = 1;

            string sql = "select Id,OrderNo,OrderDate,Wangwang,YeWuYuan,KuaiDi,Quantity,Remark,Cost,Weight,Province,UserSign,Customer,Shop from Base_SellRecord where 1=1";
            string countSql = "select count(*) from Base_SellRecord where 1=1";



            if (input.SearchKeyValues.Count > 0)
            {
                if (input.SearchKeyValues["Wangwang"] != null&&!string.IsNullOrEmpty(input.SearchKeyValues["Wangwang"].ToString()))
                {
                    sql += " And Wangwang='" + input.SearchKeyValues["Wangwang"].ToString()+"'";
                    countSql += " And Wangwang='" + input.SearchKeyValues["Wangwang"].ToString() + "'";
                }
                if (input.SearchKeyValues["Shop"] != null&&!string.IsNullOrEmpty(input.SearchKeyValues["Shop"].ToString()))
                {
                    sql += " And Shop='" + input.SearchKeyValues["Shop"].ToString() + "'";
                    countSql += " And Shop='" + input.SearchKeyValues["Shop"].ToString() + "'";
                }
                if (input.SearchKeyValues["Customer"] != null&&!string.IsNullOrEmpty(input.SearchKeyValues["Customer"].ToString()))
                {
                    sql += " And Customer='" + input.SearchKeyValues["Customer"].ToString()+"'";
                    countSql += " And Customer='" + input.SearchKeyValues["Customer"].ToString() + "'";
                }
                if (input.SearchKeyValues["UserSign"] != null&&!string.IsNullOrEmpty(input.SearchKeyValues["UserSign"].ToString()))
                {
                    if (!string.IsNullOrEmpty(CurrentUserSign))
                    {
                        if (CurrentUserSign == "admin")
                        {
                            sql += " And UserSign='" + input.SearchKeyValues["UserSign"].ToString() + "'";
                            countSql += " And UserSign='" + input.SearchKeyValues["UserSign"].ToString() + "'";
                        }
                        else
                        {
                            sql += " And UserSign='" + CurrentUserSign + "'";
                            countSql += " And UserSign='" + CurrentUserSign + "'";
                        }
                    }
                }
                if (input.SearchKeyValues["YeWuYuan"] != null&&!string.IsNullOrEmpty(input.SearchKeyValues["YeWuYuan"].ToString()))
                {
                    sql += " And YeWuYuan='" + input.SearchKeyValues["YeWuYuan"].ToString()+"'";
                    countSql += " And YeWuYuan='" + input.SearchKeyValues["YeWuYuan"].ToString() + "'";
                }
                if (input.SearchKeyValues["KuaiDi"] != null&&!string.IsNullOrEmpty(input.SearchKeyValues["KuaiDi"].ToString()))
                {
                    sql += " And KuaiDi='" + input.SearchKeyValues["KuaiDi"].ToString()+"'";
                    countSql += " And KuaiDi='" + input.SearchKeyValues["KuaiDi"].ToString() + "'";
                }
                if (input.SearchKeyValues["OrderNo"] != null&&!string.IsNullOrEmpty(input.SearchKeyValues["OrderNo"].ToString()))
                {
                    sql += " And OrderNo='" + input.SearchKeyValues["OrderNo"].ToString()+"'";
                    countSql += " And OrderNo='" + input.SearchKeyValues["OrderNo"].ToString() + "'";
                }
                if (input.SearchKeyValues["HasMatch"] != null)
                {
                    int hasMatchInt = 0;
                    if (input.SearchKeyValues["HasMatch"].ToString() == "已匹配")
                    {
                        hasMatchInt = 1;
                    }
                    sql += " And HasMatch=" + hasMatchInt;
                    countSql += " And HasMatch=" + hasMatchInt;
                }


            }

            if (!string.IsNullOrEmpty(CurrentUserSign) && CurrentUserSign != "admin")
            {
                sql += " And UserSign='" + CurrentUserSign + "'";
                countSql += " And UserSign='" + CurrentUserSign + "'";
            }




            sql += " order by Id desc";

            string pageSql = string.Format(" offset {0} rows fetch next {1} rows only ;", (input.PageIndex - 1) * input.PageRows, input.PageRows);

            string pageResultSql = sql + pageSql;


            List<Base_SellRecordDTO> tempData = _dbHelper.GetListBySql<Base_SellRecordDTO>(pageResultSql);

            // string sql1 = "select count(*) from Base_YunData";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(countSql);
            string countStr = table.Rows[0][0].ToString();
            int total = Convert.ToInt32(countStr);
            var list = new PageResult<Base_SellRecordDTO> { Data = tempData, Total = total };

            list.Success = true;

            return list;
        }


        /// <summary>
        /// Base_YunData  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<PageResult<Base_SellRecordDTO>> SellRecord_GetTheData(string id)
        {
            if (string.IsNullOrEmpty(id))
                return null;

            string sql = string.Format("select * from Base_SellRecord  where Id = '{0}';", id);
            List<Base_SellRecordDTO> tempData = _dbHelper.GetListBySql<Base_SellRecordDTO>(sql);
            var list = new PageResult<Base_SellRecordDTO> { Data = tempData, Total = 1 };
            list.Success = true;
            return list;
        }


        /// <summary>
        /// 删除Base_YunData记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public async Task<int> SellRecord_Delete(List<string> ids)
        {
            return await DeleteByIds("Base_SellRecord", ids);
        }

        /// <summary>
        /// 修改Base_SellRecord记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<int> SellRecord_Update(Base_SellRecord model)
        {
            if (string.IsNullOrEmpty(model.Id))
                return 0;

            string sql = "update Base_SellRecord set ";


            if (!string.IsNullOrEmpty(model.Wangwang))
            {
                sql += " Wangwang='" + model.Wangwang + "',";
            }
            else
            {
                sql += " Wangwang='',";
            }

            if (!string.IsNullOrEmpty(model.Shop))
            {
                sql += " Shop='" + model.Shop + "',";
            }
            else
            {
                sql += " Shop='',";
            }

            if (!string.IsNullOrEmpty(model.Customer))
            {
                sql += " Customer='" + model.Customer + "',";
            }
            else
            {
                sql += " Customer='',";
            }

            if (!string.IsNullOrEmpty(model.UserSign))
            {
                sql += " UserSign='" + model.UserSign + "',";
            }
            else
            {
                sql += " UserSign='',";
            }

            if (!string.IsNullOrEmpty(model.OrderNo))
            {
                sql += " OrderNo='" + model.OrderNo + "',";
            }
            else
            {
                sql += " OrderNo='',";
            }


            if (!string.IsNullOrEmpty(model.Province))
            {
                sql += " Province='" + model.Province + "',";
            }
            else
            {
                sql += " Province='',";
            }

            if (model.Weight.HasValue)
            {
                sql += " Weight='" + model.Weight.Value + "',";
            }
            else
            {
                sql += " Weight=null,";
            }

            if (model.OrderDate.HasValue)
            {
                sql += " OrderDate='" + model.OrderDate.Value.ToString("yyyy-MM-dd") + "',";
            }
            else
            {
                sql += " OrderDate=null,";
            }

            if (!string.IsNullOrEmpty(model.YeWuYuan))
            {
                sql += " YeWuYuan='" + model.YeWuYuan + "',";
            }
            else
            {
                sql += " YeWuYuan='',";
            }

            if (!string.IsNullOrEmpty(model.KuaiDi))
            {
                sql += " KuaiDi='" + model.KuaiDi + "',";
            }
            else
            {
                sql += " KuaiDi='',";
            }

            if (model.Quantity.HasValue)
            {
                sql += " Quantity='" + model.Quantity.Value + "',";
            }
            else
            {
                sql += " Quantity=null,";
            }

            if (!string.IsNullOrEmpty(model.Remark))
            {
                sql += " Remark='" + model.Remark + "',";
            }
            else
            {
                sql += " Remark='',";
            }

            if (model.Cost.HasValue)
            {
                sql += " Cost='" + model.Cost.Value + "',";
            }
            else
            {
                sql += " Cost=null,";
            }


            sql = sql.Substring(0, sql.Length - 1);

            sql += " where Id ='" + model.Id.ToString() + "'";

            int result = _dbHelper.ExecuteSql(sql);

            return result;
        }


        /// <summary>
        /// 删除出货记录中的重复数据（根据orderno,UserSign）
        /// </summary>
        /// <returns></returns>
        public async Task<int> SellRecord_DeleteSameRecord(int count)
        {
            if (count < 50000)
            {
                count = 50000;
            }

            count = count * 2;

            //根据OrderNo,UserSign 两个个字段查询出重复的数据
            string sql = "DELETE FROM Base_SellRecord WHERE Id IN (";

            sql += "SELECT Id FROM (";
            sql += "SELECT top "+count+" Id, DBCount = ROW_NUMBER() OVER(PARTITION BY OrderNo, UserSign ORDER BY Id)  FROM Base_SellRecord order by OrderDate desc ) Tmp ";
            sql += " WHERE DBCount > 1)";

            int result = _dbHelper.ExecuteSql(sql);

            return result;

        }


       



        /// <summary>
        /// 更新导入的出货记录，去云仓或客户表里查 客户  店铺信息
        /// </summary>
        /// <param name="count"></param>
        /// <returns></returns>
        public async Task<int> DealNewSellRecord(int count)
        {
            if (count < 1000)
            {
                count = 1000;
            }

            count = count * 2;
           

            string updateSqlOne = "UPDATE a SET a.Customer = b.Customer,a.Shop = b.Shop,a.HasMatch = 1 FROM ";
            updateSqlOne += " (SELECT Top " + count + " OrderNo, Shop, HasMatch, Customer,OrderDate FROM Base_SellRecord where Customer is null order by OrderDate desc) a,";
            updateSqlOne += "   (SELECT Customer, Shop, OrderNo FROM Base_YunData where Customer is not null ) b WHERE  a.OrderNo = b.OrderNo";

            string updateSqlTwo = "UPDATE a SET a.Customer = b.Customer,a.Shop = b.Shop,a.HasMatch = 1 FROM ";
            updateSqlTwo += " (SELECT Top " + count + " Wangwang, Shop, HasMatch, Customer,OrderDate FROM Base_SellRecord where Customer is null order by OrderDate desc) a,";
            updateSqlTwo += " (SELECT Customer, Shop, Wangwang FROM Base_CustomerRecord where Customer is not null ) b WHERE  a.Wangwang = b.Wangwang";


            int result = _dbHelper.ExecuteSql(updateSqlOne);

            int result2 = _dbHelper.ExecuteSql(updateSqlTwo);

            return 1;

        }



        /// <summary>
        /// 根据匹配总表已匹配的数据，新增云仓数据没有的记录。
        /// </summary>
        /// <param name="startTime"></param>
        /// <param name="endTime"></param>
        /// <param name="count"></param>
        /// <returns></returns>
        public async Task<int> UpdateYunDataBySellData(DateTime startTime,DateTime endTime,int count)
        {

            endTime = endTime.AddDays(1);

            //查询匹配总表中已匹配的若干记录，根据时间降序。匹配添加到云仓数据里没有的记录，根据Customer,OrderNo匹配

            string sql = "insert into Base_YunData(OrderDate, OrderNo, Customer, Shop, UserSign, Id, CreateTime)";
            sql += "select top "+count+" OrderDate,OrderNo,Customer,Shop,UserSign,NEWID(),GETDATE() from Base_SellRecord  where NOT EXISTS(";
            sql += "select OrderNo, Customer from Base_YunData where Base_YunData.OrderNo = Base_SellRecord.OrderNo and Base_YunData.Customer = Base_SellRecord.Customer and  OrderDate between '"+startTime.ToString()+"' and '"+endTime.ToString()+"') and Base_SellRecord.HasMatch = 1  order by Base_SellRecord.OrderDate desc";


            int result = _dbHelper.ExecuteSql(sql);

            return 1;
        }


        #endregion

        #region  Base_CustomerRule

        public async Task<PageResult<Base_CustomerRuleDTO>> CustomerRule_GetDataList(PageInput input)
        {
            if (input.PageIndex < 1)
                input.PageIndex = 1;

            string sql = "select c.Id,c.Customer,c.UserSign,c.KHCDJ,c.KHFL,c.ZDCDJ,c.ZDFL,c.CustomerType,c.RuleRemark,c.StartTime,c.EndTime,c.Limit,c.KuaiDi,c.AddFanLi_Id,c.AddPay_Id,c.FanLi_Id,c.JZ_Id,c.H2_Id,c.RuleRemark,";
                sql+="afl.Name as AddFanLi_Name,ap.Name as AddPay_Name,fl.Name as FanLi_Name,jz.Name as JZ_Name,h2.Name as H2_Name";
              sql+=  " from Base_CustomerRule c left join CustomerRule_AddFanLi afl on c.AddFanLi_Id=afl.Id left join CustomerRule_Fanli fl on c.FanLi_Id=fl.Id left join CustomerRule_JZ jz on c.JZ_Id=jz.Id left join CustomerRule_Hou2 h2 on c.H2_Id = h2.Id left join CustomerRule_AddPay ap on c.AddPay_Id=ap.Id   where 1=1 ";
            string countSql = "select count(*) from Base_CustomerRule where 1=1";



            if (input.SearchKeyValues.Count > 0)
            {

                if (input.SearchKeyValues["Customer"] != null&&!string.IsNullOrEmpty(input.SearchKeyValues["Customer"].ToString()))
                {
                    sql += " And Customer like '%" + input.SearchKeyValues["Customer"].ToString()+"%'";
                    countSql += " And Customer like '%" + input.SearchKeyValues["Customer"].ToString() + "%'";
                }
                if (input.SearchKeyValues["UserSign"] != null&&!string.IsNullOrEmpty(input.SearchKeyValues["UserSign"].ToString()))
                {
                    if (!string.IsNullOrEmpty(CurrentUserSign))
                    {
                        if (CurrentUserSign == "admin")
                        {
                            sql += " And UserSign='" + input.SearchKeyValues["UserSign"].ToString() + "'";
                            countSql += " And UserSign='" + input.SearchKeyValues["UserSign"].ToString() + "'";
                        }
                        else
                        {
                            sql += " And UserSign='" + CurrentUserSign + "'";
                            countSql += " And UserSign='" + CurrentUserSign + "'";
                        }
                    }
                }

                if (input.SearchKeyValues["KuaiDi"] != null&&!string.IsNullOrEmpty(input.SearchKeyValues["KuaiDi"].ToString()))
                {
                    sql += " And KuaiDi='" + input.SearchKeyValues["KuaiDi"].ToString()+"'";
                    countSql += " And KuaiDi='" + input.SearchKeyValues["KuaiDi"].ToString() + "'";
                }

                if (input.SearchKeyValues["RuleRemark"] != null&&!string.IsNullOrEmpty(input.SearchKeyValues["KuaiDi"].ToString()))
                {
                    sql += " And RuleRemark like '%" + input.SearchKeyValues["RuleRemark"].ToString()+"%'";
                    countSql += " And RuleRemark like '%" + input.SearchKeyValues["RuleRemark"].ToString() + "%'";
                }


            }

            if (!string.IsNullOrEmpty(CurrentUserSign) && CurrentUserSign != "admin")
            {
                sql += " And UserSign='" + CurrentUserSign + "'";
                countSql += " And UserSign='" + CurrentUserSign + "'";
            }


            sql += " order by Id desc";

            string pageSql = string.Format(" offset {0} rows fetch next {1} rows only ;", (input.PageIndex - 1) * input.PageRows, input.PageRows);

            string pageResultSql = sql + pageSql;


            List<Base_CustomerRuleDTO> tempData = _dbHelper.GetListBySql<Base_CustomerRuleDTO>(pageResultSql);

            // string sql1 = "select count(*) from Base_YunData";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(countSql);
            string countStr = table.Rows[0][0].ToString();
            int total = Convert.ToInt32(countStr);
            var list = new PageResult<Base_CustomerRuleDTO> { Data = tempData, Total = total };

            list.Success = true;

            return list;
        }


        /// <summary>
        /// Base_YunData  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<PageResult<Base_CustomerRuleDTO>> CustomerRule_GetTheData(string id)
        {
            if (string.IsNullOrEmpty(id))
                return null;

            string sql = string.Format("select * from Base_CustomerRule  where Id = '{0}';", id);
            List<Base_CustomerRuleDTO> tempData = _dbHelper.GetListBySql<Base_CustomerRuleDTO>(sql);
            var list = new PageResult<Base_CustomerRuleDTO> { Data = tempData, Total = 1 };
            list.Success = true;
            return list;
        }


        /// <summary>
        /// 删除Base_YunData记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public async Task<int> CustomerRule_Delete(List<string> ids)
        {
            return await DeleteByIds("Base_CustomerRule", ids);



        }

        /// <summary>
        /// 修改客户政策记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<int> CustomerRule_Update(Base_CustomerRule model)
        {
            string sql = "";


            if (!string.IsNullOrEmpty(model.Id))
            {
               



                sql = "update Base_CustomerRule set ";


                if (!string.IsNullOrEmpty(model.Customer))
                {
                    sql += " Customer='" + model.Customer + "',";
                }
                else
                {
                    sql += " Customer='',";
                }

                if (!string.IsNullOrEmpty(model.UserSign))
                {
                    sql += " UserSign='" + model.UserSign + "',";
                }
                else
                {
                    sql += " UserSign='',";
                }

                if (model.KHCDJ.HasValue)
                {
                    sql += " KHCDJ=" + model.KHCDJ.Value + ",";
                }
                else
                {
                    sql += " KHCDJ=null,";
                }

                if (model.KHFL.HasValue)
                {
                    sql += " KHFL=" + model.KHFL.Value + ",";
                }
                else
                {
                    sql += " KHFL=null,";
                }


                if (model.ZDCDJ.HasValue)
                {
                    sql += " ZDCDJ=" + model.ZDCDJ.Value + ",";
                }
                else
                {
                    sql += " ZDCDJ=null,";
                }

                if (model.ZDFL.HasValue)
                {
                    sql += " ZDFL=" + model.ZDFL.Value + ",";
                }
                else
                {
                    sql += " ZDFL=null,";
                }

                if (!string.IsNullOrEmpty(model.CustomerType))
                {
                    sql += " CustomerType='" + model.CustomerType + "',";
                }
                else
                {
                    sql += " CustomerType='',";
                }

                if (!string.IsNullOrEmpty(model.RuleRemark))
                {
                    sql += " RuleRemark='" + model.RuleRemark + "',";
                }
                else
                {
                    sql += " RuleRemark='',";
                }



                if (model.StartTime.HasValue)
                {
                    sql += " StartTime='" + model.StartTime.Value + "',";
                }
                else
                {
                    sql += " StartTime=null,";
                }

                if (model.EndTime.HasValue)
                {
                    sql += " EndTime='" + model.EndTime.Value + "',";
                }
                else
                {
                    sql += " EndTime=null,";
                }

              
                //返利规则
                if (!string.IsNullOrEmpty(model.FanLi_Id))
                {
                    sql += " FanLi_Id='" + model.FanLi_Id + "',";
                }
                else
                {
                    sql += " FanLi_Id='',";
                }

                //加返规则
                if (!string.IsNullOrEmpty(model.AddFanLi_Id))
                {
                    sql += " AddFanLi_Id='" + model.AddFanLi_Id + "',";
                }
                else
                {
                    sql += " AddFanLi_Id='',";
                }

                //加收规则
                if (!string.IsNullOrEmpty(model.AddPay_Id))
                {
                    sql += " AddPay_Id='" + model.AddPay_Id + "',";
                }
                else
                {
                    sql += " AddPay_Id='',";
                }

                //均重规则
                if (!string.IsNullOrEmpty(model.JZ_Id))
                {
                    sql += " JZ_Id='" + model.JZ_Id + "',";
                }
                else
                {
                    sql += " JZ_Id='',";
                }


                //后2规则
                if (!string.IsNullOrEmpty(model.H2_Id))
                {
                    sql += " H2_Id='" + model.H2_Id + "',";
                }
                else
                {
                    sql += " H2_Id='',";
                }




                if (model.Limit.HasValue)
                {
                    sql += " Limit=" + model.Limit.Value + ",";
                }
                else
                {
                    sql += " Limit=null,";
                }

                if (!string.IsNullOrEmpty(model.KuaiDi))
                {
                    sql += " KuaiDi='" + model.KuaiDi + "',";
                }
                else
                {
                    sql += " KuaiDi='',";
                }


                sql = sql.Substring(0, sql.Length - 1);

                sql += " where Id ='" + model.Id.ToString() + "'";

            }
            else
            {
                model.Id = Guid.NewGuid().ToString();

                sql = "insert into Base_CustomerRule (Id,Customer,UserSign,KHCDJ,KHFL,ZDCDJ,ZDFL,CustomerType,RuleRemark,StartTime,EndTime,Limit,KuaiDi,AddFanLi_Id,AddPay_Id,FanLi_Id,JZ_Id,H2_Id) values('";

                sql += model.Id + "',";



                if (!string.IsNullOrEmpty(model.Customer))
                {
                    sql += "'" + model.Customer + "',";
                }
                else
                {
                    sql += "'',";
                }

                if (!string.IsNullOrEmpty(model.UserSign))
                {
                    sql +="'"+model.UserSign + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (model.KHCDJ.HasValue)
                {
                    sql += model.KHCDJ.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.KHFL.HasValue)
                {
                    sql += model.KHFL.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.ZDCDJ.HasValue)
                {
                    sql += model.ZDCDJ.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.ZDFL.HasValue)
                {
                    sql += model.ZDFL.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.CustomerType))
                {
                    sql += "'" + model.CustomerType + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.RuleRemark))
                {
                    sql += "'" + model.RuleRemark + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (model.StartTime.HasValue)
                {
                    sql += "'" + model.StartTime.ToString() + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (model.EndTime.HasValue)
                {
                    sql += "'" + model.EndTime.ToString() + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (model.Limit.HasValue)
                {
                    sql += model.Limit.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.KuaiDi))
                {
                    sql += "'" + model.KuaiDi + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.AddFanLi_Id))
                {
                    sql += "'" + model.AddFanLi_Id + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.AddPay_Id))
                {
                    sql += "'" + model.AddPay_Id + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.FanLi_Id))
                {
                    sql += "'" + model.FanLi_Id + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.JZ_Id))
                {
                    sql += "'" + model.JZ_Id + "',";
                }
                else
                {
                    sql += " null,";
                }


                if (!string.IsNullOrEmpty(model.H2_Id))
                {
                    sql += "'" + model.H2_Id + "',";
                }
                else
                {
                    sql += " null,";
                }

                sql = sql.Substring(0, sql.Length - 1);

                sql += ");";
            }
          

            int result = _dbHelper.ExecuteSql(sql);

            return result;
        }


        

        #endregion

        #region  Base_KuaiDi

        public async Task<PageResult<Base_KuaiDiDTO>> KuaiDi_GetDataList(PageInput input)
        {
            if (input.PageIndex < 1)
                input.PageIndex = 1;

            string sql = "select * from Base_KuaiDi where 1=1";
            string countSql = "select count(*) from Base_KuaiDi where 1=1";



            if (input.SearchKeyValues.Count > 0)
            {
                if (input.SearchKeyValues["KuaiDi"] != null&&!string.IsNullOrEmpty(input.SearchKeyValues["KuaiDi"].ToString()))
                {
                    sql += " And KuaiDi='" + input.SearchKeyValues["KuaiDi"].ToString()+"'";
                    countSql += " And KuaiDi='" + input.SearchKeyValues["KuaiDi"].ToString() + "'";
                }
                if (input.SearchKeyValues["UserSign"] != null&&!string.IsNullOrEmpty(input.SearchKeyValues["UserSign"].ToString()))
                {
                    sql += " And UserSign='" + input.SearchKeyValues["UserSign"].ToString()+"'";
                    countSql += " And UserSign='" + input.SearchKeyValues["UserSign"].ToString() + "'";
                }
              

            }

            sql += " order by Id desc";

            string pageSql = string.Format(" offset {0} rows fetch next {1} rows only ;", (input.PageIndex - 1) * input.PageRows, input.PageRows);

            string pageResultSql = sql + pageSql;


            List<Base_KuaiDiDTO> tempData = _dbHelper.GetListBySql<Base_KuaiDiDTO>(pageResultSql);

            // string sql1 = "select count(*) from Base_YunData";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(countSql);
            string countStr = table.Rows[0][0].ToString();
            int total = Convert.ToInt32(countStr);
            var list = new PageResult<Base_KuaiDiDTO> { Data = tempData, Total = total };

            list.Success = true;

            return list;
        }


        /// <summary>
        /// Base_YunData  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<PageResult<Base_KuaiDiDTO>> KuaiDi_GetTheData(string id)
        {
            if (string.IsNullOrEmpty(id))
                return null;

            string sql = string.Format("select * from Base_KuaiDi  where Id = '{0}';", id);
            List<Base_KuaiDiDTO> tempData = _dbHelper.GetListBySql<Base_KuaiDiDTO>(sql);
            var list = new PageResult<Base_KuaiDiDTO> { Data = tempData, Total = 1 };
            list.Success = true;
            return list;
        }


        /// <summary>
        /// 删除Base_YunData记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public async Task<int> KuaiDi_Delete(List<string> ids)
        {
            return await DeleteByIds("Base_KuaiDi", ids);
        }

        /// <summary>
        /// 修改Base_YunData记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<AjaxResult<int>> KuaiDi_Update(Base_KuaiDi model)
        {
            

            string sql = "";


            if (string.IsNullOrEmpty(model.Id))
            {
                model.Id = Guid.NewGuid().ToString();

                sql = "insert into Base_KuaiDi (Id,KuaiDi,UserSign,CDJ,FL,DJ,Remark,StartTime,EndTime) values('";

                sql += model.Id + "',";


                if (!string.IsNullOrEmpty(model.KuaiDi))
                {
                    sql += "'" + model.KuaiDi + "',";
                }
                else
                {
                    sql += "'',";
                }

                if (!string.IsNullOrEmpty(model.UserSign))
                {
                    sql += "'" + model.UserSign + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (model.CDJ.HasValue)
                {
                    sql += model.CDJ.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.FL.HasValue)
                {
                    sql +=  model.FL.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.DJ.HasValue)
                {
                    sql += model.DJ.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.Remark))
                {
                    sql += "'" + model.Remark + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (model.StartTime.HasValue)
                {
                    sql += "'" + model.StartTime.Value.ToString() + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (model.EndTime.HasValue)
                {
                    sql += "'" + model.EndTime.Value.ToString() + "',";
                }
                else
                {
                    sql += " null,";
                }

                sql = sql.Substring(0, sql.Length - 1);

                sql += ");";
            }
            else
            {

                sql = "update Base_KuaiDi set ";


                if (!string.IsNullOrEmpty(model.KuaiDi))
                {
                    sql += " KuaiDi='" + model.KuaiDi + "',";
                }
                else
                {
                    sql += " KuaiDi='',";
                }

                if (!string.IsNullOrEmpty(model.UserSign))
                {
                    sql += " UserSign='" + model.UserSign + "',";
                }
                else
                {
                    sql += " UserSign='',";
                }

                if (model.CDJ.HasValue)
                {
                    sql += " CDJ=" + model.CDJ + ",";
                }
                else
                {
                    sql += " CDJ=null,";
                }

                if (model.FL.HasValue)
                {
                    sql += " FL=" + model.FL + ",";
                }
                else
                {
                    sql += " FL=null,";
                }


                if (model.DJ.HasValue)
                {
                    sql += " DJ=" + model.DJ + ",";
                }
                else
                {
                    sql += " DJ=null,";
                }

                if (!string.IsNullOrEmpty(model.Remark))
                {
                    sql += " Remark='" + model.Remark + "',";
                }
                else
                {
                    sql += " Remark='',";
                }

                if (model.StartTime.HasValue)
                {
                    sql += " StartTime='" + model.StartTime.ToString() + "',";
                }
                else
                {
                    sql += " StartTime=null,";
                }

                if (model.EndTime.HasValue)
                {
                    sql += " EndTime='" + model.EndTime.ToString() + "',";
                }
                else
                {
                    sql += " EndTime=null,";
                }



                sql = sql.Substring(0, sql.Length - 1);

                sql += " where Id ='" + model.Id.ToString() + "'";
            }

            int result = _dbHelper.ExecuteSql(sql);

            AjaxResult<int> returnResult;
            if (result >= 0)
            {
                returnResult = new AjaxResult<int>
                {
                    Success = true,
                    Data = result
                };

            }
            else
            {
                returnResult = new AjaxResult<int>
                {
                    Success = false,
                    Msg = "数据库保存失败"
                };
            }
            return returnResult;
        }



        #endregion

        #region CustomerRule_AddFanli

        /// <summary>
        /// CustomerRule_AddFanli 查询List
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<PageResult<CustomerRule_AddFanLiDTO>> AddFanli_GetDataList(PageInput input)
        {
            if (input.PageIndex < 1)
                input.PageIndex = 1;

            string sql = "select * from CustomerRule_AddFanli where 1=1";
            string countSql = "select count(*) from CustomerRule_AddFanli where 1=1";



            if (input.SearchKeyValues.Count > 0)
            {
                if (input.SearchKeyValues["Name"] != null && input.SearchKeyValues["Name"].ToString() != "")
                {
                    sql += " And Name='" + input.SearchKeyValues["Name"].ToString() + "'";
                    countSql += " And Name='" + input.SearchKeyValues["Name"].ToString() + "'";
                }
          
            }

            sql += " order by Id desc";

            string pageSql = string.Format(" offset {0} rows fetch next {1} rows only ;", (input.PageIndex - 1) * input.PageRows, input.PageRows);

            string pageResultSql = sql + pageSql;


            List<CustomerRule_AddFanLiDTO> tempData = _dbHelper.GetListBySql<CustomerRule_AddFanLiDTO>(pageResultSql);

            // string sql1 = "select count(*) from Base_YunData";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(countSql);
            string countStr = table.Rows[0][0].ToString();
            int total = Convert.ToInt32(countStr);
            var list = new PageResult<CustomerRule_AddFanLiDTO> { Data = tempData, Total = total };

            list.Success = true;

            return list;
        }


        /// <summary>
        /// CustomerRule_AddFanli  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<PageResult<CustomerRule_AddFanLiDTO>> AddFanli_GetTheData(string id)
        {
            if (string.IsNullOrEmpty(id))
                return null;

            string sql = string.Format("select * from CustomerRule_AddFanli  where Id = '{0}';", id);
            List<CustomerRule_AddFanLiDTO> tempData = _dbHelper.GetListBySql<CustomerRule_AddFanLiDTO>(sql);
            var list = new PageResult<CustomerRule_AddFanLiDTO> { Data = tempData, Total = 1 };
            list.Success = true;
            return list;
        }


        /// <summary>
        /// 删除CustomerRule_AddFanli记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public async Task<int> AddFanli_Delete(List<string> ids)
        {


            return await DeleteByIds("CustomerRule_AddFanli", ids);
        }

        /// <summary>
        /// 新增或修改CustomerRule_AddFanli记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<AjaxResult<int>> AddFanli_Update(CustomerRule_AddFanLi model)
        {

            int beforeUpdateResult = await this.CheckBeforeUpdate("CustomerRule_AddFanli", "Name", model.Name, model.Id);
            if (beforeUpdateResult < 0)
            {
                return new AjaxResult<int>
                {
                    Success = false,
                    Msg = "修改失败，已存在重复数据"
                };
            }

            string sql = "";

            if (!string.IsNullOrEmpty(model.Id))
            {

                sql = "update CustomerRule_AddFanli set ";


                if (!string.IsNullOrEmpty(model.Name))
                {
                    sql += " Name='" + model.Name + "',";
                }
                else
                {
                    sql += " Name='',";
                }


                if (model.MinValueOne.HasValue)
                {
                    sql += " MinValueOne=" + model.MinValueOne.Value + ",";
                }
                else
                {
                    sql += " MinValueOne=null,";
                }


                if (model.MaxValueOne.HasValue)
                {
                    sql += " MaxValueOne=" + model.MaxValueOne.Value + ",";
                }
                else
                {
                    sql += " MaxValueOne=null,";
                }


                if (model.AddAmountOne.HasValue)
                {
                    sql += " AddAmountOne=" + model.AddAmountOne.Value + ",";
                }
                else
                {
                    sql += " AddAmountOne=null,";
                }

                if (model.MinValueTwo.HasValue)
                {
                    sql += " MinValueTwo=" + model.MinValueTwo.Value + ",";
                }
                else
                {
                    sql += " MinValueTwo=null,";
                }


                if (model.MaxValueTwo.HasValue)
                {
                    sql += " MaxValueTwo=" + model.MaxValueTwo.Value + ",";
                }
                else
                {
                    sql += " MaxValueTwo=null,";
                }


                if (model.AddAmountTwo.HasValue)
                {
                    sql += " AddAmountTwo=" + model.AddAmountTwo.Value + ",";
                }
                else
                {
                    sql += " AddAmountTwo=null,";
                }

                if (model.MinValueThree.HasValue)
                {
                    sql += " MinValueThree=" + model.MinValueThree.Value + ",";
                }
                else
                {
                    sql += " MinValueThree=null,";
                }


                if (model.MaxValueThree.HasValue)
                {
                    sql += " MaxValueThree=" + model.MaxValueThree.Value + ",";
                }
                else
                {
                    sql += " MaxValueThree=null,";
                }


                if (model.AddAmountThree.HasValue)
                {
                    sql += " AddAmountThree=" + model.AddAmountThree.Value + ",";
                }
                else
                {
                    sql += " AddAmountThree=null,";
                }

                if (model.MinValueFour.HasValue)
                {
                    sql += " MinValueFour=" + model.MinValueFour.Value + ",";
                }
                else
                {
                    sql += " MinValueFour=null,";
                }


                if (model.MaxValueFour.HasValue)
                {
                    sql += " MaxValueFour=" + model.MaxValueFour.Value + ",";
                }
                else
                {
                    sql += " MaxValueFour=null,";
                }


                if (model.AddAmountFour.HasValue)
                {
                    sql += " AddAmountFour=" + model.AddAmountFour.Value + ",";
                }
                else
                {
                    sql += " AddAmountFour=null,";
                }

                if (model.MinValueFive.HasValue)
                {
                    sql += " MinValueFive=" + model.MinValueFive.Value + ",";
                }
                else
                {
                    sql += " MinValueFive=null,";
                }


                if (model.MaxValueFive.HasValue)
                {
                    sql += " MaxValueFive=" + model.MaxValueFive.Value + ",";
                }
                else
                {
                    sql += " MaxValueFive=null,";
                }


                if (model.AddAmountFive.HasValue)
                {
                    sql += " AddAmountFive=" + model.AddAmountFive.Value + ",";
                }
                else
                {
                    sql += " AddAmountFive=null,";
                }

                if (!string.IsNullOrEmpty(model.RuleRemark))
                {
                    sql += " RuleRemark='" + model.RuleRemark + "',";
                }
                else
                {
                    sql += " RuleRemark='',";
                }



                if (model.CreateTime.HasValue)
                {
                    sql += " CreateTime='" + model.CreateTime.Value.ToString() + "',";
                }
                else
                {
                    sql += " CreateTime=null,";
                }

              



                sql = sql.Substring(0, sql.Length - 1);

                sql += " where Id ='" + model.Id.ToString() + "'";
            }
            else
            {
                
                model.Id = Guid.NewGuid().ToString();

                sql = "insert into CustomerRule_AddFanli (Id,Name,MinValueOne,MaxValueOne,AddAmountOne,MinValueTwo,MaxValueTwo,AddAmountTwo,MinValueThree,MaxValueThree,AddAmountThree,MinValueFour,MaxValueFour,AddAmountFour,MinValueFive,MaxValueFive,AddAmountFive,RuleRemark,CreateTime) values('";

                sql +=  model.Id + "',";

                if (!string.IsNullOrEmpty(model.Name))
                {
                    sql += " '" + model.Name.ToString() + "',";
                }
                else
                {
                    sql += " '',";
                }

                if (model.MinValueOne.HasValue)
                {
                    sql +=  model.MinValueOne.Value + ",";
                }
                else
                {
                    sql += "null,";
                }

                if (model.MaxValueOne.HasValue)
                {
                    sql += model.MaxValueOne.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.AddAmountOne.HasValue)
                {
                    sql += model.AddAmountOne.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.MinValueTwo.HasValue)
                {
                    sql += model.MinValueTwo.Value + ",";
                }
                else
                {
                    sql += "null,";
                }

                if (model.MaxValueTwo.HasValue)
                {
                    sql += model.MaxValueTwo.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.AddAmountTwo.HasValue)
                {
                    sql += model.AddAmountTwo.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.MinValueThree.HasValue)
                {
                    sql += model.MinValueThree.Value + ",";
                }
                else
                {
                    sql += "null,";
                }

                if (model.MaxValueThree.HasValue)
                {
                    sql += model.MaxValueThree.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.AddAmountThree.HasValue)
                {
                    sql += model.AddAmountThree.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.MinValueFour.HasValue)
                {
                    sql += model.MinValueFour.Value + ",";
                }
                else
                {
                    sql += "null,";
                }

                if (model.MaxValueFour.HasValue)
                {
                    sql += model.MaxValueFour.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.AddAmountFour.HasValue)
                {
                    sql += model.AddAmountFour.Value + ",";
                }
                else
                {
                    sql += " null,";
                }


                if (model.MinValueFive.HasValue)
                {
                    sql += model.MinValueFive.Value + ",";
                }
                else
                {
                    sql += "null,";
                }

                if (model.MaxValueFive.HasValue)
                {
                    sql += model.MaxValueFive.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.AddAmountFive.HasValue)
                {
                    sql += model.AddAmountFive.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.RuleRemark))
                {
                    sql += " '" + model.RuleRemark.ToString() + "',";
                }
                else
                {
                    sql += " '',";
                }

                sql += " '" + model.CreateTime.ToString() + "',";

             


                sql = sql.Substring(0, sql.Length - 1);

                sql += ")";

            }

            int result = _dbHelper.ExecuteSql(sql);


            AjaxResult<int> returnResult;
            if (result >= 0)
            {

                returnResult = new AjaxResult<int>
                {
                    Success = true,
                    Data = result
                };
               
            }
            else
            {
                returnResult = new AjaxResult<int>
                {
                    Success = false,
                    Msg = "数据库保存失败"
                };
            }
            return returnResult;

        }

        #endregion

        #region CustomerRule_AddPay


        /// <summary>
        /// 查询 CustomerRule_AddPay  List
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<PageResult<CustomerRule_AddPayDTO>> AddPay_GetDataList(PageInput input)
        {
            if (input.PageIndex < 1)
                input.PageIndex = 1;

            string sql = "select * from CustomerRule_AddPay where 1=1";
            string countSql = "select count(*) from CustomerRule_AddPay where 1=1";



            if (input.SearchKeyValues.Count > 0)
            {
                if (input.SearchKeyValues["Name"] != null && input.SearchKeyValues["Name"].ToString() != "")
                {
                    sql += " And Name='" + input.SearchKeyValues["Name"].ToString() + "'";
                    countSql += " And Name='" + input.SearchKeyValues["Name"].ToString() + "'";
                }

            }

            sql += " order by Id desc";

            string pageSql = string.Format(" offset {0} rows fetch next {1} rows only ;", (input.PageIndex - 1) * input.PageRows, input.PageRows);

            string pageResultSql = sql + pageSql;


            List<CustomerRule_AddPayDTO> tempData = _dbHelper.GetListBySql<CustomerRule_AddPayDTO>(pageResultSql);

            // string sql1 = "select count(*) from Base_YunData";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(countSql);
            string countStr = table.Rows[0][0].ToString();
            int total = Convert.ToInt32(countStr);
            var list = new PageResult<CustomerRule_AddPayDTO> { Data = tempData, Total = total };

            list.Success = true;

            return list;
        }


        /// <summary>
        /// CustomerRule_AddPay  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<PageResult<CustomerRule_AddPayDTO>> AddPay_GetTheData(string id)
        {
            if (string.IsNullOrEmpty(id))
                return null;

            string sql = string.Format("select * from CustomerRule_AddPay  where Id = '{0}';", id);
            List<CustomerRule_AddPayDTO> tempData = _dbHelper.GetListBySql<CustomerRule_AddPayDTO>(sql);
            var list = new PageResult<CustomerRule_AddPayDTO> { Data = tempData, Total = 1 };
            list.Success = true;
            return list;
        }


        /// <summary>
        /// 删除CustomerRule_AddPay记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public async Task<int> AddPay_Delete(List<string> ids)
        {


            return await DeleteByIds("CustomerRule_AddPay",ids);
        }

        /// <summary>
        /// 新增或修改CustomerRule_AddPay记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<AjaxResult<int>> AddPay_Update(CustomerRule_AddPay model)
        {
            int beforeUpdateResult = await this.CheckBeforeUpdate("CustomerRule_AddPay", "Name", model.Name, model.Id);
            if (beforeUpdateResult < 0)
            {
                return new AjaxResult<int>
                {
                    Success = false,
                    Msg = "修改失败，已存在重复数据"
                };
            }

            string sql = "";

            if (!string.IsNullOrEmpty(model.Id))
            {

                sql = "update CustomerRule_AddPay set ";


                if (!string.IsNullOrEmpty(model.Name))
                {
                    sql += " Name='" + model.Name + "',";
                }
                else
                {
                    sql += " Name='',";
                }

                if (model.MinValueOne.HasValue)
                {
                    sql += " MinValueOne=" + model.MinValueOne.Value + ",";
                }
                else
                {
                    sql += " MinValueOne=null,";
                }


                if (model.MaxValueOne.HasValue)
                {
                    sql += " MaxValueOne=" + model.MaxValueOne.Value + ",";
                }
                else
                {
                    sql += " MaxValueOne=null,";
                }


                if (model.AddAmountOne.HasValue)
                {
                    sql += " AddAmountOne=" + model.AddAmountOne.Value + ",";
                }
                else
                {
                    sql += " AddAmountOne=null,";
                }

                if (model.MinValueTwo.HasValue)
                {
                    sql += " MinValueTwo=" + model.MinValueTwo.Value + ",";
                }
                else
                {
                    sql += " MinValueTwo=null,";
                }


                if (model.MaxValueTwo.HasValue)
                {
                    sql += " MaxValueTwo=" + model.MaxValueTwo.Value + ",";
                }
                else
                {
                    sql += " MaxValueTwo=null,";
                }


                if (model.AddAmountTwo.HasValue)
                {
                    sql += " AddAmountTwo=" + model.AddAmountTwo.Value + ",";
                }
                else
                {
                    sql += " AddAmountTwo=null,";
                }

                if (model.MinValueThree.HasValue)
                {
                    sql += " MinValueThree=" + model.MinValueThree.Value + ",";
                }
                else
                {
                    sql += " MinValueThree=null,";
                }


                if (model.MaxValueThree.HasValue)
                {
                    sql += " MaxValueThree=" + model.MaxValueThree.Value + ",";
                }
                else
                {
                    sql += " MaxValueThree=null,";
                }


                if (model.AddAmountThree.HasValue)
                {
                    sql += " AddAmountThree=" + model.AddAmountThree.Value + ",";
                }
                else
                {
                    sql += " AddAmountThree=null,";
                }

                if (model.MinValueFour.HasValue)
                {
                    sql += " MinValueFour=" + model.MinValueFour.Value + ",";
                }
                else
                {
                    sql += " MinValueFour=null,";
                }


                if (model.MaxValueFour.HasValue)
                {
                    sql += " MaxValueFour=" + model.MaxValueFour.Value + ",";
                }
                else
                {
                    sql += " MaxValueFour=null,";
                }


                if (model.AddAmountFour.HasValue)
                {
                    sql += " AddAmountFour=" + model.AddAmountFour.Value + ",";
                }
                else
                {
                    sql += " AddAmountFour=null,";
                }

                if (model.MinValueFive.HasValue)
                {
                    sql += " MinValueFive=" + model.MinValueFive.Value + ",";
                }
                else
                {
                    sql += " MinValueFive=null,";
                }


                if (model.MaxValueFive.HasValue)
                {
                    sql += " MaxValueFive=" + model.MaxValueFive.Value + ",";
                }
                else
                {
                    sql += " MaxValueFive=null,";
                }


                if (model.AddAmountFive.HasValue)
                {
                    sql += " AddAmountFive=" + model.AddAmountFive.Value + ",";
                }
                else
                {
                    sql += " AddAmountFive=null,";
                }

                if (model.CreateTime.HasValue)
                {
                    sql += " CreateTime='" + model.CreateTime.Value.ToString() + "',";
                }
                else
                {
                    sql += " CreateTime=null,";
                }

                if (!string.IsNullOrEmpty(model.RuleRemark))
                {
                    sql += " RuleRemark='" + model.RuleRemark + "',";
                }
                else
                {
                    sql += " RuleRemark='',";
                }



                sql = sql.Substring(0, sql.Length - 1);

                sql += " where Id ='" + model.Id.ToString() + "'";
            }
            else
            {
                model.Id = Guid.NewGuid().ToString();

                sql = "insert into CustomerRule_AddPay (Id,Name,MinValueOne,MaxValueOne,AddAmountOne,MinValueTwo,MaxValueTwo,AddAmountTwo,MinValueThree,MaxValueThree,AddAmountThree,MinValueFour,MaxValueFour,AddAmountFour,MinValueFive,MaxValueFive,AddAmountFive,RuleRemark,CreateTime) values('";

                sql +=  model.Id + "',";

                if (!string.IsNullOrEmpty(model.Name))
                {
                    sql += " '" + model.Name.ToString() + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (model.MinValueOne.HasValue)
                {
                    sql +=  model.MinValueOne.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.MaxValueOne.HasValue)
                {
                    sql +=  model.MaxValueOne.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.AddAmountOne.HasValue)
                {
                    sql +=  model.AddAmountOne.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.MinValueTwo.HasValue)
                {
                    sql += model.MinValueOne.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.MaxValueTwo.HasValue)
                {
                    sql += model.MaxValueOne.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.AddAmountTwo.HasValue)
                {
                    sql += model.AddAmountOne.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.MinValueThree.HasValue)
                {
                    sql += model.MinValueOne.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.MaxValueThree.HasValue)
                {
                    sql += model.MaxValueOne.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.AddAmountThree.HasValue)
                {
                    sql += model.AddAmountOne.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.MinValueFour.HasValue)
                {
                    sql += model.MinValueOne.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.MaxValueFour.HasValue)
                {
                    sql += model.MaxValueOne.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.AddAmountFour.HasValue)
                {
                    sql += model.AddAmountOne.Value + ",";
                }
                else
                {
                    sql += " null,";
                }


                if (model.MinValueFive.HasValue)
                {
                    sql += model.MinValueOne.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.MaxValueFive.HasValue)
                {
                    sql += model.MaxValueOne.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.AddAmountFive.HasValue)
                {
                    sql += model.AddAmountOne.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.RuleRemark))
                {
                    sql += " '" + model.RuleRemark.ToString() + "',";
                }
                else
                {
                    sql += " null,";
                }

                sql += " '" + model.CreateTime.ToString() + "',";

              


                sql = sql.Substring(0, sql.Length - 1);

                sql += ")";

            }

            int result = _dbHelper.ExecuteSql(sql);

            AjaxResult<int> returnResult;
            if (result >= 0)
            {

                returnResult = new AjaxResult<int>
                {
                    Success = true,
                    Data = result
                };

            }
            else
            {
                returnResult = new AjaxResult<int>
                {
                    Success = false,
                    Msg = "数据库保存失败"
                };
            }
            return returnResult;

        }

        #endregion

        #region  CustomerRule_Fanli

        /// <summary>
        /// 查询 CustomerRule_Fanli List
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<PageResult<CustomerRule_FanliDTO>> Fanli_GetDataList(PageInput input)
        {

            if (input.PageIndex < 1)
                input.PageIndex = 1;

            string sql = "select * from CustomerRule_Fanli where 1=1";
            string countSql = "select count(*) from CustomerRule_Fanli where 1=1";



            if (input.SearchKeyValues.Count > 0)
            {
                if (input.SearchKeyValues["Name"] != null && input.SearchKeyValues["Name"].ToString() != "")
                {
                    sql += " And Name='" + input.SearchKeyValues["Name"].ToString() + "'";
                    countSql += " And Name='" + input.SearchKeyValues["Name"].ToString() + "'";
                }

            }

            sql += " order by Id desc";

            string pageSql = string.Format(" offset {0} rows fetch next {1} rows only ;", (input.PageIndex - 1) * input.PageRows, input.PageRows);

            string pageResultSql = sql + pageSql;


            List<CustomerRule_FanliDTO> tempData = _dbHelper.GetListBySql<CustomerRule_FanliDTO>(pageResultSql);

            // string sql1 = "select count(*) from Base_YunData";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(countSql);
            string countStr = table.Rows[0][0].ToString();
            int total = Convert.ToInt32(countStr);
            var list = new PageResult<CustomerRule_FanliDTO> { Data = tempData, Total = total };

            list.Success = true;

            return list;
        }


        /// <summary>
        /// CustomerRule_Fanli  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<PageResult<CustomerRule_FanliDTO>> Fanli_GetTheData(string id)
        {
            if (string.IsNullOrEmpty(id))
                return null;

            string sql = string.Format("select * from CustomerRule_Fanli  where Id = '{0}';", id);
            List<CustomerRule_FanliDTO> tempData = _dbHelper.GetListBySql<CustomerRule_FanliDTO>(sql);
            var list = new PageResult<CustomerRule_FanliDTO> { Data = tempData, Total = 1 };
            list.Success = true;
            return list;
        }


        /// <summary>
        /// 删除CustomerRule_Fanli记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public async Task<int> Fanli_Delete(List<string> ids)
        {
            return await DeleteByIds("CustomerRule_Fanli", ids);
        }

        /// <summary>
        /// 修改CustomerRule_Fanli记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<AjaxResult<int>> Fanli_Update(CustomerRule_Fanli model)
        {
            int beforeUpdateResult = await this.CheckBeforeUpdate("CustomerRule_Fanli", "Name", model.Name, model.Id);
            if (beforeUpdateResult < 0)
            {
                return new AjaxResult<int>
                {
                    Success = false,
                    Msg = "修改失败，已存在重复数据[规则名称]"
                };
            }


            string sql = "";

            if (!string.IsNullOrEmpty(model.Id))
            {

                sql = "update CustomerRule_Fanli set ";

                if (!string.IsNullOrEmpty(model.Name))
                {
                    sql += " Name='" + model.Name + "',";
                }
                else
                {
                    sql += " Name='',";
                }

                if (!string.IsNullOrEmpty(model.Fanli_ProvinceStr))
                {
                    sql += " Fanli_ProvinceStr='" + model.Fanli_ProvinceStr + "',";
                }
                else
                {
                    sql += " Fanli_ProvinceStr='',";
                }

                if (model.Fanli_Weight.HasValue)
                {
                    sql += " Fanli_Weight=" + model.Fanli_Weight.Value + ",";
                }
                else
                {
                    sql += " Fanli_Weight=null,";
                }


                if (model.CreateTime.HasValue)
                {
                    sql += " CreateTime='" + model.CreateTime.Value.ToString() + "',";
                }
                else
                {
                    sql += " CreateTime=null,";
                }

                if (!string.IsNullOrEmpty(model.RuleRemark))
                {
                    sql += " RuleRemark='" + model.RuleRemark + "',";
                }
                else
                {
                    sql += " RuleRemark='',";
                }


                sql = sql.Substring(0, sql.Length - 1);

                sql += " where Id ='" + model.Id.ToString() + "'";
            }
            else
            {
                model.Id = Guid.NewGuid().ToString();

                sql = "insert into CustomerRule_Fanli (Id,Fanli_ProvinceStr,Fanli_Weight,CreateTime,Name,RuleRemark) values('";

                sql += model.Id + "',";

               

                if (!string.IsNullOrEmpty(model.Fanli_ProvinceStr))
                {
                    sql += "'" + model.Fanli_ProvinceStr + "',";
                }
                else
                {
                    sql += "'',";
                }

                if (model.Fanli_Weight.HasValue)
                {
                    sql +=  model.Fanli_Weight.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                sql += " '" + model.CreateTime.ToString() + "',";


                if (!string.IsNullOrEmpty(model.Name))
                {
                    sql += " '" + model.Name.ToString() + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (!string.IsNullOrEmpty(model.RuleRemark))
                {
                    sql += " '" + model.RuleRemark.ToString() + "',";
                }
                else
                {
                    sql += " null,";
                }

                sql = sql.Substring(0, sql.Length - 1);

                sql += ");";

            }

            int result = _dbHelper.ExecuteSql(sql);

            AjaxResult<int> returnResult;
            if (result >= 0)
            {

                returnResult = new AjaxResult<int>
                {
                    Success = true,
                    Data = result
                };

            }
            else
            {
                returnResult = new AjaxResult<int>
                {
                    Success = false,
                    Msg = "数据库保存失败"
                };
            }
            return returnResult;
        }

        #endregion


        #region CustomerRule_JZ


        /// <summary>
        /// CustomerRule_Jz  查询List
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<PageResult<CustomerRule_JZDTO>> JZ_GetDataList(PageInput input)
        {
            if (input.PageIndex < 1)
                input.PageIndex = 1;

            string sql = "select * from CustomerRule_JZ where 1=1";
            string countSql = "select count(*) from CustomerRule_JZ where 1=1";



            if (input.SearchKeyValues.Count > 0)
            {
                if (input.SearchKeyValues["Name"] != null && input.SearchKeyValues["Name"].ToString() != "")
                {
                    sql += " And Name='" + input.SearchKeyValues["Name"].ToString() + "'";
                    countSql += " And Name='" + input.SearchKeyValues["Name"].ToString() + "'";
                }

            }

            sql += " order by Id desc";

            string pageSql = string.Format(" offset {0} rows fetch next {1} rows only ;", (input.PageIndex - 1) * input.PageRows, input.PageRows);

            string pageResultSql = sql + pageSql;


            List<CustomerRule_JZDTO> tempData = _dbHelper.GetListBySql<CustomerRule_JZDTO>(pageResultSql);

            // string sql1 = "select count(*) from Base_YunData";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(countSql);
            string countStr = table.Rows[0][0].ToString();
            int total = Convert.ToInt32(countStr);
            var list = new PageResult<CustomerRule_JZDTO> { Data = tempData, Total = total };

            list.Success = true;

            return list;
        }


        /// <summary>
        /// CustomerRule_JZ  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<PageResult<CustomerRule_JZDTO>> JZ_GetTheData(string id)
        {
            if (string.IsNullOrEmpty(id))
                return null;

            string sql = string.Format("select * from CustomerRule_JZ  where Id = '{0}';", id);
            List<CustomerRule_JZDTO> tempData = _dbHelper.GetListBySql<CustomerRule_JZDTO>(sql);
            var list = new PageResult<CustomerRule_JZDTO> { Data = tempData, Total = 1 };
            list.Success = true;
            return list;
        }


        /// <summary>
        /// 删除CustomerRule_JZ记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public async Task<int> JZ_Delete(List<string> ids)
        {
            return await DeleteByIds("CustomerRule_JZ", ids);
        }

        /// <summary>
        /// 修改CustomerRule_JZ记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<AjaxResult<int>> JZ_Update(CustomerRule_JZ model)
        {

            int beforeUpdateResult = await this.CheckBeforeUpdate("CustomerRule_JZ", "Name", model.Name, model.Id);
            if (beforeUpdateResult < 0)
            {
                return new AjaxResult<int>
                {
                    Success = false,
                    Msg = "修改失败，已存在重复数据[规则名称]"
                };
            }

            string sql = "";

            if (!string.IsNullOrEmpty(model.Id))
            {

                sql = "update CustomerRule_JZ set ";


                if (!string.IsNullOrEmpty(model.Name))
                {
                    sql += " Name='" + model.Name + "',";
                }
                else
                {
                    sql += " Name='',";
                }

                if (!string.IsNullOrEmpty(model.JZ_ProvinceStr))
                {
                    sql += " JZ_ProvinceStr='" + model.JZ_ProvinceStr + "',";
                }
                else
                {
                    sql += " JZ_ProvinceStr='',";
                }


                if (model.JZ_Weight.HasValue)
                {
                    sql += " JZ_Weight=" + model.JZ_Weight.Value + ",";
                }
                else
                {
                    sql += " JZ_Weight=null,";
                }

                if (model.JZ_Weight_PJ.HasValue)
                {
                    sql += " JZ_Weight_PJ=" + model.JZ_Weight_PJ.Value + ",";
                }
                else
                {
                    sql += " JZ_Weight_PJ=null,";
                }

                if (model.AddAmount.HasValue)
                {
                    sql += " AddAmount=" + model.AddAmount.Value + ",";
                }
                else
                {
                    sql += " AddAmount=null,";
                }

                if (model.CreateTime.HasValue)
                {
                    sql += " CreateTime='" + model.CreateTime.Value.ToString() + "',";
                }
                else
                {
                    sql += " CreateTime=null,";
                }

                if (!string.IsNullOrEmpty(model.RuleRemark))
                {
                    sql += " RuleRemark='" + model.RuleRemark + "',";
                }
                else
                {
                    sql += " RuleRemark='',";
                }

                sql = sql.Substring(0, sql.Length - 1);

                sql += " where Id ='" + model.Id.ToString() + "'";
            }
            else
            {
                model.Id = Guid.NewGuid().ToString();

                sql = "insert into CustomerRule_JZ (Id,Name,JZ_ProvinceStr,JZ_Weight,JZ_Weight_PJ,AddAmount,CreateTime,RuleRemark) values('";

                sql +=  model.Id + "',";



                if (!string.IsNullOrEmpty(model.Name))
                {
                    sql += " '" + model.Name + "',";
                }
                else
                {
                    sql += "null,";
                }

                if (!string.IsNullOrEmpty(model.JZ_ProvinceStr))
                {
                    sql += " '" + model.JZ_ProvinceStr + "',";
                }
                else
                {
                    sql += " null,";
                }

                if (model.JZ_Weight.HasValue)
                {
                    sql +=  model.JZ_Weight.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.JZ_Weight_PJ.HasValue)
                {
                    sql += model.JZ_Weight_PJ.Value + ",";
                }
                else
                {
                    sql += " null,";
                }

                if (model.AddAmount.HasValue)
                {
                    sql += model.AddAmount.Value + ",";
                }
                else
                {
                    sql += " null,";
                }


                sql += "'" + model.CreateTime.ToString() + "',";

                if (!string.IsNullOrEmpty(model.RuleRemark))
                {
                    sql += " '" + model.RuleRemark + "',";
                }
                else
                {
                    sql += " null,";
                }

                sql = sql.Substring(0, sql.Length - 1);

                sql += ")";

            }

            int result = _dbHelper.ExecuteSql(sql);


            AjaxResult<int> returnResult;
            if (result >= 0)
            {

                returnResult = new AjaxResult<int>
                {
                    Success = true,
                    Data = result
                };

            }
            else
            {
                returnResult = new AjaxResult<int>
                {
                    Success = false,
                    Msg = "数据库保存失败"
                };
            }
            return returnResult;
        }

        #endregion



        #region CustomerRule_Hou2


        /// <summary>
        /// CustomerRule_Hou2 查询List
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<PageResult<CustomerRule_Hou2DTO>> H2_GetDataList(PageInput input)
        {
            if (input.PageIndex < 1)
                input.PageIndex = 1;

            string sql = "select * from CustomerRule_Hou2 where 1=1";
            string countSql = "select count(*) from CustomerRule_Hou2 where 1=1";



            if (input.SearchKeyValues.Count > 0)
            {
                if (input.SearchKeyValues["Name"] != null && input.SearchKeyValues["Name"].ToString() != "")
                {
                    sql += " And Name='" + input.SearchKeyValues["Name"].ToString() + "'";
                    countSql += " And Name='" + input.SearchKeyValues["Name"].ToString() + "'";
                }

            }

            sql += " order by Id desc";

            string pageSql = string.Format(" offset {0} rows fetch next {1} rows only ;", (input.PageIndex - 1) * input.PageRows, input.PageRows);

            string pageResultSql = sql + pageSql;


            List<CustomerRule_Hou2DTO> tempData = _dbHelper.GetListBySql<CustomerRule_Hou2DTO>(pageResultSql);

            // string sql1 = "select count(*) from Base_YunData";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(countSql);
            string countStr = table.Rows[0][0].ToString();
            int total = Convert.ToInt32(countStr);
            var list = new PageResult<CustomerRule_Hou2DTO> { Data = tempData, Total = total };

            list.Success = true;

            return list;
        }


        /// <summary>
        /// CustomerRule_Hou2  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<PageResult<CustomerRule_Hou2DTO>> H2_GetTheData(string id)
        {
            if (string.IsNullOrEmpty(id))
                return null;

            string sql = string.Format("select * from CustomerRule_Hou2  where Id = '{0}';", id);
            List<CustomerRule_Hou2DTO> tempData = _dbHelper.GetListBySql<CustomerRule_Hou2DTO>(sql);
            var list = new PageResult<CustomerRule_Hou2DTO> { Data = tempData, Total = 1 };
            list.Success = true;
            return list;
        }


        /// <summary>
        /// 删除CustomerRule_Hou2记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public async Task<int> H2_Delete(List<string> ids)
        {
            return await DeleteByIds("CustomerRule_Hou2", ids);
        }

        /// <summary>
        /// 修改CustomerRule_Hou2记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<AjaxResult<int>> H2_Update(CustomerRule_Hou2 model)
        {

            int beforeUpdateResult = await this.CheckBeforeUpdate("CustomerRule_Hou2", "Name", model.Name, model.Id);
            if (beforeUpdateResult < 0)
            {
                return new AjaxResult<int>
                {
                    Success = false,
                    Msg = "修改失败，已存在重复数据[规则名称]"
                };
            }

            string sql = "";

            if (!string.IsNullOrEmpty(model.Id))
            {

                sql = "update CustomerRule_Hou2 set ";


        

                if (model.Hou2_Weight.HasValue)
                {
                    sql += " Hou2_Weight=" + model.Hou2_Weight.Value + ",";
                }
                else
                {
                    sql += " Hou2_Weight=null,";
                }

                if (model.Hou2_100.HasValue)
                {
                    sql += " Hou2_100=" + model.Hou2_100.Value + ",";
                }
                else
                {
                    sql += " Hou2_100=null,";
                }

                if (model.SinglePrice.HasValue)
                {
                    sql += " SinglePrice=" + model.SinglePrice.Value + ",";
                }
                else
                {
                    sql += " SinglePrice=null,";
                }



                if (model.CreateTime.HasValue)
                {
                    sql += " CreateTime='" + model.CreateTime.Value.ToString() + "',";
                }
                else
                {
                    sql += " CreateTime=null,";
                }

             

                if (!string.IsNullOrEmpty(model.Name))
                {
                    sql += " Name='" + model.Name + "',";
                }
                else
                {
                    sql += " Name='',";
                }

                if (!string.IsNullOrEmpty(model.RuleRemark))
                {
                    sql += " RuleRemark='" + model.RuleRemark + "',";
                }
                else
                {
                    sql += " RuleRemark='',";
                }



                sql = sql.Substring(0, sql.Length - 1);

                sql += " where Id ='" + model.Id.ToString() + "'";
            }
            else
            {
                model.Id = Guid.NewGuid().ToString();

                sql = "insert into CustomerRule_Hou2 (Id,Hou2_ProvinceStr,Hou2_Weight,Hou2_100,SinglePrice,CreateTime,Name,RuleRemark) values('";

                sql +=  model.Id + "',";



             

                if (model.Hou2_Weight.HasValue)
                {
                    sql += model.Hou2_Weight.Value + ",";
                }
                else
                {
                    sql += "null,";
                }

                if (model.Hou2_100.HasValue)
                {
                    sql += model.Hou2_100.Value + ",";
                }
                else
                {
                    sql += "null,";
                }

                if (model.SinglePrice.HasValue)
                {
                    sql +=  model.SinglePrice + ",";
                }
                else
                {
                    sql += "null,";

                }

                sql += " '" + model.CreateTime.ToString() + "',";

                if (!string.IsNullOrEmpty(model.Name))
                {
                    sql += "'" + model.Name + "',";
                }
                else
                {
                    sql += " '',";

                }

                if (!string.IsNullOrEmpty(model.RuleRemark))
                {
                    sql += "'" + model.RuleRemark + "',";
                }
                else
                {
                    sql += " '',";

                }

                sql = sql.Substring(0, sql.Length - 1);

                sql += ")";

            }

            int result = _dbHelper.ExecuteSql(sql);

            AjaxResult<int> returnResult;
            if (result >= 0)
            {

                returnResult = new AjaxResult<int>
                {
                    Success = true,
                    Data = result
                };

            }
            else
            {
                returnResult = new AjaxResult<int>
                {
                    Success = false,
                    Msg = "数据库保存失败"
                };
            }
            return returnResult;

        }

        #endregion


        #region   查询客户规则选项

        /// <summary>
        /// 获取所有加收规则选项
        /// </summary>
        /// <returns></returns>
        public async Task<ObservableCollection<ISelectOption>> GetAddPayOptionList()
        {
            string sql = " select * from CustomerRule_AddPay";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(sql);
            List<CustomerRule_AddPay> userList = Extention.ToList<CustomerRule_AddPay>(table);

            List<SelectOption> tempResult = userList.Select(s => new SelectOption
            {
                Text = s.Name,
                Value = s.Id
            }).ToList();


            ObservableCollection<ISelectOption> result = new ObservableCollection<ISelectOption>();
            result.AddRange(tempResult);

            return result;
        }


        /// <summary>
        /// 获取所有加返规则选项
        /// </summary>
        /// <returns></returns>
        public async Task<ObservableCollection<ISelectOption>> GetAddFanLiOptionList()
        {
            string sql = " select * from CustomerRule_AddFanLi";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(sql);
            List<CustomerRule_AddFanLi> userList = Extention.ToList<CustomerRule_AddFanLi>(table);

            List<SelectOption> tempResult = userList.Select(s => new SelectOption
            {
                Text = s.Name,
                Value = s.Id
            }).ToList();


            ObservableCollection<ISelectOption> result = new ObservableCollection<ISelectOption>();
            result.AddRange(tempResult);

            return result;
        }

        /// <summary>
        /// 获取所有返利规则选项
        /// </summary>
        /// <returns></returns>
        public async Task<ObservableCollection<ISelectOption>> GetFanLiOptionList()
        {
            string sql = " select * from CustomerRule_Fanli";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(sql);
            List<CustomerRule_Fanli> userList = Extention.ToList<CustomerRule_Fanli>(table);

            List<SelectOption> tempResult = userList.Select(s => new SelectOption
            {
                Text = s.Name,
                Value = s.Id
            }).ToList();


            ObservableCollection<ISelectOption> result = new ObservableCollection<ISelectOption>();
            result.AddRange(tempResult);

            return result;
        }

        /// <summary>
        /// 获取所有后2规则选项
        /// </summary>
        /// <returns></returns>
        public async Task<ObservableCollection<ISelectOption>> GetH2OptionList()
        {
            string sql = " select * from CustomerRule_Hou2";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(sql);
            List<CustomerRule_Hou2> userList = Extention.ToList<CustomerRule_Hou2>(table);

            List<SelectOption> tempResult = userList.Select(s => new SelectOption
            {
                Text = s.Name,
                Value = s.Id
            }).ToList();


            ObservableCollection<ISelectOption> result = new ObservableCollection<ISelectOption>();
            result.AddRange(tempResult);

            return result;
        }

        /// <summary>
        /// 获取所有均重规则选项
        /// </summary>
        /// <returns></returns>
        public async Task<ObservableCollection<ISelectOption>> GetJZOptionList()
        {
            string sql = " select * from CustomerRule_JZ";
            System.Data.DataTable table = _dbHelper.GetDataTableWithSql(sql);
            List<CustomerRule_JZ> userList = Extention.ToList<CustomerRule_JZ>(table);

            List<SelectOption> tempResult = userList.Select(s => new SelectOption
            {
                Text = s.Name,
                Value = s.Id
            }).ToList();


            ObservableCollection<ISelectOption> result = new ObservableCollection<ISelectOption>();
            result.AddRange(tempResult);

            return result;
        }

        #endregion


        #region  汇总统计

        public AjaxResult<List<Base_StaticViewDTO>> Static_GetDataList(DateTime? startTime, DateTime? endTime, string customerName,string userSign,string customerType,string kuaidi)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                
                // 创建一个 SqlCommand 对象来执行存储过程
                using (SqlCommand command = new SqlCommand("SP_GetStaticData", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // 添加参数并设置值
                    command.Parameters.AddWithValue("@StartTime", startTime);
                    command.Parameters.AddWithValue("@EndTime", endTime);
                    command.Parameters.AddWithValue("@UserSign", userSign);
                    command.Parameters.AddWithValue("@CustomerType", customerType);
                    command.Parameters.AddWithValue("@CustomerName", customerName);
                    command.Parameters.AddWithValue("@KuaiDi", kuaidi);
         
                    // ...

                    // 创建一个 SqlDataAdapter 对象来填充数据
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        // 创建一个 DataTable 对象来保存结果
                        System.Data.DataTable dataTable = new System.Data.DataTable();

                        // 使用 SqlDataAdapter 填充数据到 DataTable
                        adapter.Fill(dataTable);

                        List<Base_StaticViewDTO> tempList;
                        try
                        {
                            tempList = Extention.ToList<Base_StaticViewDTO>(dataTable);
                            
                            return new AjaxResult<List<Base_StaticViewDTO>>
                            {
                                Success = true,
                                    Data = tempList
                            };
                            
                        }
                        catch (Exception e)
                        {
                            return new AjaxResult<List<Base_StaticViewDTO>> {
                                Success = false,
                                Msg = e.ToString()
                            };
                        } 
                    }
                }
            }
        }

        #endregion

    }
}
