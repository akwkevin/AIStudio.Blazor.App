﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIStudio.Wpf.Entity.Models
{
    /// <summary>
    /// 
    /// </summary>
    [Table("CustomerRule_JZ")]
    public class CustomerRule_JZ
    {

        /// <summary>
        /// Id
        /// </summary>
        public String Id { get; set; }

        /// <summary>
        /// Name
        /// </summary>
        public String Name { get; set; }

        /// <summary>
        /// 均重省份条件,逗号分隔
        /// </summary>
        public String JZ_ProvinceStr { get; set; }

        /// <summary>
        /// 均重重量条件
        /// </summary>
        public Decimal? JZ_Weight { get; set; }

        /// <summary>
        /// 均重平均值
        /// </summary>
        public Decimal? JZ_Weight_PJ { get; set; }

        /// <summary>
        /// AddAmount
        /// </summary>
        public Decimal? AddAmount { get; set; }

        /// <summary>
        /// CreateTime
        /// </summary>
        public DateTime? CreateTime { get; set; }

        public string RuleRemark { get; set; }

    }
}