﻿using AIStudio.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIStudio.Wpf.Entity.DTOModels.Base_Manage.InputDTO
{
    public class Base_ActionsInputDTO:SearchInput
    {
        public string[]? ActionIds { get; set; }
        public ActionType[]? Types { get; set; }

        public string? ParentId { get; set; }
    }
}
