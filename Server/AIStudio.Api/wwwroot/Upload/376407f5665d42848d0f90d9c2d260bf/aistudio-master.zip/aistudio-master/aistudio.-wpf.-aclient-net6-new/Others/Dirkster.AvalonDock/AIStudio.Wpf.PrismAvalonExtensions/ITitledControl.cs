﻿namespace AIStudio.Wpf.PrismAvalonExtensions
{
    public interface ITitledControl
    {
        string Title
        {
            get; set;
        }
    }
}
