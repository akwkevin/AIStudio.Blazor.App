﻿namespace AIStudio.Core
{
    /// <summary>
    /// 注入标记,生命周期为Scope
    /// </summary>
    public interface IScopedDependency
    {

    }
}
