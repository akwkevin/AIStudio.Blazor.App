﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIStudio.Wpf.Entity.Models
{
    /// <summary>
    /// 
    /// </summary>
    [Table("Base_CustomerRule")]
    public class Base_CustomerRule
    {

        /// <summary>
        /// Id
        /// </summary>
        public String Id { get; set; }

        /// <summary>
        /// 客户名称
        /// </summary>
        public String Customer { get; set; }

        /// <summary>
        /// 操作人标识
        /// </summary>
        public String UserSign { get; set; }

        /// <summary>
        /// 客户充单价
        /// </summary>
        public Decimal? KHCDJ { get; set; }

        /// <summary>
        /// 客户返利
        /// </summary>
        public Decimal? KHFL { get; set; }

        /// <summary>
        /// 站点充单价
        /// </summary>
        public Decimal? ZDCDJ { get; set; }

        /// <summary>
        /// 站点返利
        /// </summary>
        public Decimal? ZDFL { get; set; }

        /// <summary>
        /// 客户类型
        /// </summary>
        public String CustomerType { get; set; }

        /// <summary>
        /// 政策备注
        /// </summary>
        public string RuleRemark { get; set; }

      

        /// <summary>
        /// 开始时间
        /// </summary>
        public DateTime? StartTime { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        public DateTime? EndTime { get; set; }




        /// <summary>
        /// 额度
        /// </summary>
        public Decimal? Limit { get; set; }

        /// <summary>
        /// 站点
        /// </summary>
        public String KuaiDi { get; set; }


        /// <summary>
        /// 加返规则id
        /// </summary>
        public string AddFanLi_Id { get; set; }

        /// <summary>
        /// 加收规则id
        /// </summary>
        public string AddPay_Id { get; set; }

        /// <summary>
        /// 返利规则id
        /// </summary>
        public string FanLi_Id { get; set; }


        /// <summary>
        /// 均重规则id
        /// </summary>
        public string JZ_Id { get; set; }

        /// <summary>
        /// 后2规则id
        /// </summary>
        public string H2_Id { get; set; }


        /// <summary>
        /// 加返规则名称
        /// </summary>
        public string AddFanLi_Name { get; set;}

        /// <summary>
        /// 加收规则名称
        /// </summary>
        public string AddPay_Name { get;set;}

        /// <summary>
        /// 返利规则名称
        /// </summary>
        public string FanLi_Name { get;set; }


        /// <summary>
        /// 均重规则名称
        /// </summary>
        public string JZ_Name { get; set; }


        /// <summary>
        /// 后2规则名称
        /// </summary>
        public string H2_Name { get; set;}

    }
}