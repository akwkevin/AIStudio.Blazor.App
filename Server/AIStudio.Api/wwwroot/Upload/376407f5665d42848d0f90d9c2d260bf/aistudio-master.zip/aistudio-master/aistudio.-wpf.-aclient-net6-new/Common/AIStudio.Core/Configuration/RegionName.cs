﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIStudio.Core
{
    public static class RegionName
    {
        public static string MainContentRegion = "MainContentRegion";
        public static string TabContentRegion = "TabContentRegion";
        public static string SingleContentRegion = "SingleContentRegion";

    }
}
