﻿using AIStudio.Core;
using AIStudio.DbFactory.DataAccess;
using AIStudio.Wpf.Entity.DTOModels;
using AIStudio.Wpf.Entity.DTOModels.Base_Manage;
using AIStudio.Wpf.Entity.DTOModels.Base_Manage.InputDTO;
using AIStudio.Wpf.Entity.Models;
using AIStudio.Wpf.Entity.TreeModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;


namespace AIStudio.Wpf.Business
{

    public interface IDataProvider
    {

        Task<AjaxResult> GetToken(string url, string userName, string password, int headMode, TimeSpan timeout);

        string Url { get; set; }
        IAppHeader Header { get; set; }
        TimeSpan TimeOut { get; set; }

         string CurrentUserSign { get; set; }

        Dictionary<string, string> GetHeader();
       
        Task<AjaxResult<T>> PostData<T>(string url, Dictionary<string, string> data);

        Task<AjaxResult<T>> PostData<T>(string url, string json = "{}");

        Task<AjaxResult<T>> PostData<T>(string url, object data);

        Task<UploadResult> UploadFileByForm(string path);

        Task<AjaxResult<List<Base_DbLinkDTO>>> GetAllDbLink();

        Task<AjaxResult<List<BuildCode>>> GetDbTableList(string linkId);

        Task<int> DeleteByIds(string tableName,List<string> ids);

        Task<int> CheckBeforeUpdate(string tableName,string colunName,string value,string Id=null);

        Dictionary<string, List<TableInfo>> GetDbTableInfo(BuildInputDTO input);

        Task<ObservableCollection<SelectOption>> GetBase_UserOptionList();

        Task<ObservableCollection<SelectOption>> GetRoleOptionList();

        Task<ObservableCollection<TreeModel>> GetDepartmentTreeDataList(SearchInput input);

        /// <summary>
        /// 登录验证
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        Task<AjaxResult<Base_UserDTO>> CheckLogin(string userName,string password);

        /// <summary>
        /// 获取用户权限
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="isAdmin"></param>
        /// <returns></returns>
        Task<string[]> GetUserActionIds(string userId,bool isAdmin);


        /// <summary>
        /// 获取菜单
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<AjaxResult<List<Base_Action>>> GetTreeDataListAsync(Base_ActionsInputDTO input);

        Task<List<Base_ActionTree>> GetActionTreeDataList(Base_ActionsInputDTO input);

        Task<List<Base_ActionTree>> GetMenuTreeList(Base_ActionsInputDTO input);

        Task<AjaxResult<List<Base_ActionDTO>>> GetPermissionList(Base_ActionsInputDTO input);

        Task<List<Base_Dictionary>> GetDictionaryDataList(SearchInput input);

        Task<List<Base_DictionaryTree>> GetDic_TreeDataList(SearchInput input);


        Task<PageResult<Base_DepartmentDTO>> Department_GetTheData(string id);

        Task<AjaxResult<int>> Department_Update(Base_Department model);

        #region  Base_Action

        Task<List<Base_ActionTree>> Action_GetDataList(Base_ActionsInputDTO input);



        /// <summary>
        /// Base_YunData  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<Base_ActionDTO> Action_GetTheData(string id);


        /// <summary>
        /// 删除Base_YunData记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        Task<int> Action_Delete(List<string> ids);

        /// <summary>
        /// 修改Base_YunData记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        Task<AjaxResult<int>> Action_Update(Base_Action model);


        #endregion

        #region  Base_YunData

        Task<DataTable> YunData_GetDataTableToExcel(PageInput input);

            Task<PageResult<Base_YunDataDTO>> YunData_GetDataList(PageInput input);


            /// <summary>
            /// Base_YunData  根据id查询记录
            /// </summary>
            /// <param name="id"></param>
            /// <returns></returns>
            Task<PageResult<Base_YunDataDTO>> YunData_GetTheData(string id);


            /// <summary>
            /// 删除Base_YunData记录
            /// </summary>
            /// <param name="ids"></param>
            /// <returns></returns>
            Task<int> YunData_Delete(List<string> ids);

            /// <summary>
            /// 修改Base_YunData记录
            /// </summary>
            /// <param name="model"></param>
            /// <returns></returns>
            Task<int> UpdateYunDataById(Base_YunData model);
            
            /// <summary>
            /// 云仓数据删除重复记录（根据单号，操作人标识）
            /// </summary>
            /// <returns></returns>
            Task<int> YunData_DeleteSameRecord(int count);

        #endregion


        #region  Base_CustomerRecord

        Task<DataTable> CustomerRecord_ToExcel(PageInput input);

        Task<PageResult<Base_CustomerRecordDTO>> CustomerRecord_GetDataList(PageInput input);


        /// <summary>
        /// Base_YunData  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<PageResult<Base_CustomerRecordDTO>> CustomerRecord_GetTheData(string id);


        /// <summary>
        /// 删除Base_YunData记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        Task<int> CustomerRecord_Delete(List<string> ids);

        /// <summary>
        /// 修改Base_YunData记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        Task<AjaxResult<int>> CustomerRecord_Update(Base_CustomerRecord model);

        /// <summary>
        /// 客户信息修改后，去修改未匹配的出货记录
        /// </summary>
        /// <returns></returns>
        Task<int> UpdateSellRecordByNewCustomer();

        #endregion

        #region Base_SellRecord

        Task<DataTable> SellRecord_ToExcel(PageInput input);

        Task<PageResult<Base_SellRecordDTO>> SellRecord_GetDataList(PageInput input);


        /// <summary>
        /// Base_YunData  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<PageResult<Base_SellRecordDTO>> SellRecord_GetTheData(string id);


        /// <summary>
        /// 删除Base_YunData记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        Task<int> SellRecord_Delete(List<string> ids);

        /// <summary>
        /// 修改Base_YunData记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        Task<int> SellRecord_Update(Base_SellRecord model);


        /// <summary>
        /// 出货记录删除重复数据（根据OrderNo,UserSign）
        /// </summary>
        /// <returns></returns>
        Task<int> SellRecord_DeleteSameRecord(int count);


        /// <summary>
        /// 更新导入的出货记录，去云仓或客户表里查 客户  店铺信息
        /// </summary>
        /// <param name="count"></param>
        /// <returns></returns>
        Task<int> DealNewSellRecord(int count);


        /// <summary>
        /// 
        /// </summary>
        /// <param name="count"></param>
        /// <returns></returns>
        Task<int> UpdateYunDataBySellData(DateTime startTime,DateTime endTime,int count);

        #endregion


        #region  Base_User

        Task<PageResult<Base_UserDTO>> User_GetDataList(PageInput input);


        /// <summary>
        /// Base_YunData  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<PageResult<Base_UserDTO>> User_GetTheData(string id);


        /// <summary>
        /// 删除Base_YunData记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        Task<int> User_Delete(List<string> ids);

        /// <summary>
        /// 修改Base_YunData记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        Task<AjaxResult<int>> User_Update(Base_User model);

        #endregion


        #region  Base_CustomerRule


        Task<PageResult<Base_CustomerRuleDTO>> CustomerRule_GetDataList(PageInput input);


        /// <summary>
        /// Base_YunData  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<PageResult<Base_CustomerRuleDTO>> CustomerRule_GetTheData(string id);


        /// <summary>
        /// 删除Base_YunData记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        Task<int> CustomerRule_Delete(List<string> ids);

        /// <summary>
        /// 修改Base_YunData记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        Task<int> CustomerRule_Update(Base_CustomerRule model);


        

        #endregion

        #region  Base_KuaiDi

        Task<PageResult<Base_KuaiDiDTO>> KuaiDi_GetDataList(PageInput input);


        /// <summary>
        /// Base_YunData  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<PageResult<Base_KuaiDiDTO>> KuaiDi_GetTheData(string id);


        /// <summary>
        /// 删除Base_YunData记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        Task<int> KuaiDi_Delete(List<string> ids);

        /// <summary>
        /// 修改Base_YunData记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        Task<AjaxResult<int>> KuaiDi_Update(Base_KuaiDi model);

        #endregion


        #region  CustomerRule_AddFanli


        Task<PageResult<CustomerRule_AddFanLiDTO>> AddFanli_GetDataList(PageInput input);


        /// <summary>
        /// Base_YunData  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<PageResult<CustomerRule_AddFanLiDTO>> AddFanli_GetTheData(string id);


        /// <summary>
        /// 删除Base_YunData记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        Task<int> AddFanli_Delete(List<string> ids);

        /// <summary>
        /// 修改Base_YunData记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        Task<AjaxResult<int>> AddFanli_Update(CustomerRule_AddFanLi model);




        #endregion

        #region  CustomerRule_AddPay


        Task<PageResult<CustomerRule_AddPayDTO>> AddPay_GetDataList(PageInput input);


        /// <summary>
        /// Base_YunData  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<PageResult<CustomerRule_AddPayDTO>> AddPay_GetTheData(string id);


        /// <summary>
        /// 删除Base_YunData记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        Task<int> AddPay_Delete(List<string> ids);

        /// <summary>
        /// 修改Base_YunData记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        Task<AjaxResult<int>> AddPay_Update(CustomerRule_AddPay model);




        #endregion

        #region CustomerRule_Fanli

        Task<PageResult<CustomerRule_FanliDTO>> Fanli_GetDataList(PageInput input);


        /// <summary>
        /// Base_YunData  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<PageResult<CustomerRule_FanliDTO>> Fanli_GetTheData(string id);


        /// <summary>
        /// 删除Base_YunData记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        Task<int> Fanli_Delete(List<string> ids);

        /// <summary>
        /// 修改Base_YunData记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        Task<AjaxResult<int>> Fanli_Update(CustomerRule_Fanli model);

        #endregion

        #region CustomerRule_JZ

        Task<PageResult<CustomerRule_JZDTO>> JZ_GetDataList(PageInput input);


        /// <summary>
        /// Base_YunData  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<PageResult<CustomerRule_JZDTO>> JZ_GetTheData(string id);


        /// <summary>
        /// 删除Base_YunData记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        Task<int> JZ_Delete(List<string> ids);

        /// <summary>
        /// 修改Base_YunData记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        Task<AjaxResult<int>> JZ_Update(CustomerRule_JZ model);

        #endregion

        #region CustomerRule_Hou2

        Task<PageResult<CustomerRule_Hou2DTO>> H2_GetDataList(PageInput input);


        /// <summary>
        /// Base_YunData  根据id查询记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<PageResult<CustomerRule_Hou2DTO>> H2_GetTheData(string id);


        /// <summary>
        /// 删除Base_YunData记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        Task<int> H2_Delete(List<string> ids);

        /// <summary>
        /// 修改Base_YunData记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        Task<AjaxResult<int>> H2_Update(CustomerRule_Hou2 model);

        #endregion

      

        #region  政策规则下拉选项

        Task<ObservableCollection<ISelectOption>> GetAddPayOptionList();
        Task<ObservableCollection<ISelectOption>> GetAddFanLiOptionList();
        Task<ObservableCollection<ISelectOption>> GetFanLiOptionList();

        Task<ObservableCollection<ISelectOption>> GetH2OptionList();

        Task<ObservableCollection<ISelectOption>> GetJZOptionList();

        #endregion


        AjaxResult<List<Base_StaticViewDTO>> Static_GetDataList(DateTime? startTime, DateTime? endTime, string customerName, string userSign, string customerType, string kuaidi);

        /// <summary>
        /// SqlBulk批量插入
        /// </summary>
        /// <param name="TableName"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        int SqlBulkCopyByDatatable(string TableName, DataTable dt);


        int SqlBulkCopyByDatatable(string TableName, DataTable dt, string thenSql);



    }
}
