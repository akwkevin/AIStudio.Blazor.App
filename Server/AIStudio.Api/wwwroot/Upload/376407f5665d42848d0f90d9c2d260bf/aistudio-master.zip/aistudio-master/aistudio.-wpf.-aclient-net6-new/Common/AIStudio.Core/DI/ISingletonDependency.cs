﻿namespace AIStudio.Core
{
    /// <summary>
    /// 注入标记,生命周期为Singleton
    /// </summary>
    public interface ISingletonDependency
    {

    }
}
