﻿using AIStudio.Wpf.BasePage.Events;
using Prism.Events;
using AIStudio.Wpf.Controls;

namespace AIStudio.Wpf.Client.Views
{
    /// <summary>
    /// LoginWindow.xaml 的交互逻辑
    /// </summary>
    public partial class LoginWindow : WindowBase
    {
        public LoginWindow()
        {            
            InitializeComponent();
        }

    }
}
