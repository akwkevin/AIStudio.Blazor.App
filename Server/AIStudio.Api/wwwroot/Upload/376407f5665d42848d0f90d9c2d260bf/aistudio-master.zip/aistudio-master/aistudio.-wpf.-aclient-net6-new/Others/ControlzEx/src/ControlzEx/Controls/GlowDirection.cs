﻿namespace ControlzEx.Controls
{
	public enum GlowDirection
	{
		Left, Right, Top, Bottom,
	}
}