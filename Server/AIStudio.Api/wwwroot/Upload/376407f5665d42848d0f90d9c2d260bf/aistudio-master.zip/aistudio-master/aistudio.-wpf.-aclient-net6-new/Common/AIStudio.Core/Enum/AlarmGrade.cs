﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIStudio.Core
{
    public enum AlarmGrade
    {
        DarkDanger,
        Danger,
        Warning,
        DarkWarning,
        Info,
        DarkInfo,
        Success,
        DarkSuccess
    }
}
