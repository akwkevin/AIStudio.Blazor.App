﻿using System;
using System.Windows;
using System.Windows.Markup;

[assembly: CLSCompliant(true)]

[assembly: XmlnsPrefix("urn:controlzex", "controlzex")]
[assembly: XmlnsDefinition("urn:controlzex", "ControlzEx")]
[assembly: XmlnsDefinition("urn:controlzex", "ControlzEx.Controls")]
[assembly: XmlnsDefinition("urn:controlzex", "ControlzEx.Behaviors")]
[assembly: XmlnsDefinition("urn:controlzex", "ControlzEx.Theming")]
[assembly: XmlnsDefinition("urn:controlzex", "ControlzEx.Windows.Shell")]

[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]