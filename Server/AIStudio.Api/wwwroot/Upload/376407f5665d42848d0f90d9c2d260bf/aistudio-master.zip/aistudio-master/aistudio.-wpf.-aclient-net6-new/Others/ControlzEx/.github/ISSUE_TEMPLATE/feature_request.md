---
name: Feature request
about: Suggest an idea for ControlzEx
title: ''
labels: Feature Request
assignees: ''

---

## Describe the feature

<!-- 
Describe your feature request.
A clear and concise description of what you want to happen.
-->

## Additional context

<!-- Add any other context or screenshots about the feature request here. -->
