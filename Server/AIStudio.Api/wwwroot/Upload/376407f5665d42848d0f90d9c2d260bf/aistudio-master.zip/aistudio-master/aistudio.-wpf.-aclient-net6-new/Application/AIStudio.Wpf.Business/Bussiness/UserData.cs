﻿using AIStudio.Core;
using Newtonsoft.Json;
using NPOI.HSSF.Record;
using NPOI.SS.Formula.Functions;
using Prism.Ioc;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;

namespace AIStudio.Wpf.Business
{
    public class UserData : IUserData
    {
        IDataProvider _dataProvider { get; }
        public UserData()
        {
            _dataProvider = ContainerLocator.Current.Resolve<IDataProvider>();

        }

        public string[] ReadOnlySource { get; } = new string[] { "Id", "CreateTime", "ModifyTime", "CreatorName", "ModifyName" };
        public string[] IgnoreSource { get; } = new string[] { "IsChecked", "Deleted", "CreatorId", "ModifyId", };

        private ObservableCollection<ISelectOption> base_user { get; set; } = new ObservableCollection<ISelectOption>();

        private ObservableCollection<ISelectOption> base_role { get; set; } = new ObservableCollection<ISelectOption>();

        private ObservableCollection<ISelectOption> base_department { get; set; } = new ObservableCollection<ISelectOption>();

        private ObservableCollection<ISelectOption> base_departmenttree { get; set; } = new ObservableCollection<ISelectOption>();

        private ObservableCollection<ISelectOption> base_action { get; set; } = new ObservableCollection<ISelectOption>();

        private ObservableCollection<ISelectOption> base_actiontree { get; set; } = new ObservableCollection<ISelectOption>();

        private ObservableCollection<DictionaryTreeModel> base_dictionary { get; set; } = new ObservableCollection<DictionaryTreeModel>();

        public async Task<ObservableCollection<ISelectOption>> GetBase_User()
        {
            if (base_user.Count == 0)
            {
                var result = await _dataProvider.GetBase_UserOptionList();
                if (result != null || result.Count > 0)
                {
                    base_user.AddRange(result);
                }
                else
                {
                    throw new Exception("GetBase_UserOption返回为空");
                }

            }

            return base_user;
        }

        public void ClearBase_User()
        {
            base_user.Clear();
        }

        public async Task<ObservableCollection<ISelectOption>> GetBase_Role()
        {
            if (base_role.Count == 0)
            {
                var result = await _dataProvider.GetRoleOptionList();
                if (result != null || result.Count > 0)
                {
                    base_role.AddRange(result);
                }
                else
                {
                    throw new Exception("GetRoleOptionList返回为空");
                }
            }

            return base_role;
        }

        public void ClearBase_Role()
        {
            base_role.Clear();
        }

        public async Task<ObservableCollection<ISelectOption>> GetBase_DepartmentTree()
        {
            if (base_departmenttree.Count == 0)
            {
                var result = await _dataProvider.GetDepartmentTreeDataList(new Entity.DTOModels.Base_Manage.InputDTO.SearchInput());
                if (result != null || result.Count > 0)
                {
                    base_departmenttree.AddRange(result);
                }
                else
                {
                    throw new Exception("GetDepartmentTreeDataList返回为空");
                }
            }

            return base_departmenttree;
        }

        public async Task<ObservableCollection<ISelectOption>> GetBase_Department()
        {
            if (base_department.Count == 0)
            {
                var tree = await GetBase_DepartmentTree();
                base_department.AddRange(TreeHelper.GetTreeToList(tree.Select(p => p as TreeModel)));
            }

            return base_department;
        }

        public void ClearBase_Department()
        {
            base_departmenttree.Clear();
            base_department.Clear();
        }

        public async Task<ObservableCollection<ISelectOption>> GetBase_ActionTree()
        {
            if (base_actiontree.Count == 0)
            {
                var tempResult = await _dataProvider.GetActionTreeDataList(new Entity.DTOModels.Base_Manage.InputDTO.Base_ActionsInputDTO { 
                 ActionIds = new string[] { },
                 Types = new ActionType[] { }
                });
                if (tempResult != null || tempResult.Count > 0)
                {
                    string str = JsonConvert.SerializeObject(tempResult);
                    ObservableCollection<TreeModel> result = JsonConvert.DeserializeObject<ObservableCollection<TreeModel>>(str);
                    base_actiontree.AddRange(result);
                }
                else
                {
                    throw new Exception("GetActionTreeDataList返回为空");
                }
            }

            return base_actiontree;
        }

        public async Task<ObservableCollection<ISelectOption>> GetBase_Action()
        {
            if (base_action.Count == 0)
            {
                var tree = await GetBase_ActionTree();
                base_action.AddRange(TreeHelper.GetTreeToList(tree.Select(p => p as TreeModel)));
            }

            return base_action;
        }

        public void ClearBase_Action()
        {
            base_actiontree.Clear();
            base_action.Clear();
        }

        public async Task<ObservableCollection<DictionaryTreeModel>> GetBase_Dictionary()
        {
            if (base_dictionary.Count == 0)
            {
                //var result = await _dataProvider.PostData<ObservableCollection<DictionaryTreeModel>>("/Base_Manage/Base_Dictionary/GetTreeDataList");
                //if (!result.Success)
                //{
                //    throw new Exception(result.Msg);
                //}
                //else
                //{
                //    base_dictionary.AddRange(result.Data);
                //}

                var tempResult = await _dataProvider.GetDic_TreeDataList(new Entity.DTOModels.Base_Manage.InputDTO.SearchInput());
                if (tempResult != null || tempResult.Count > 0)
                {
                    string str =  JsonConvert.SerializeObject(tempResult);
                   List<DictionaryTreeModel> result =    JsonConvert.DeserializeObject<List<DictionaryTreeModel>>(str);
                  
                    base_dictionary.AddRange(result);
                }
                else
                {
                    throw new Exception("GetActionTreeDataList返回为空");
                }
            }

            return base_dictionary;
        }

        public void ClearBase_Dictionary()
        {
            base_dictionary.Clear();
        }

        public Dictionary<string, ObservableCollection<ISelectOption>> ItemSource { get; private set; } = new Dictionary<string, ObservableCollection<ISelectOption>>();
        public Dictionary<string, DictionaryTreeModel> Base_Dictionary { get; private set; } = new Dictionary<string, DictionaryTreeModel>();

        public async Task Init()
        {
            ClearBase_User();
            ClearBase_Role();
            ClearBase_Department();
            ClearBase_Dictionary();
            ClearBase_Action();

            ItemSource.Clear();
            Base_Dictionary.Clear();
            ItemSource.Add("Base_User", await GetBase_User());
            ItemSource.Add("Base_Role", await GetBase_Role());
            ItemSource.Add("Base_Department", await GetBase_Department());
            ItemSource.Add("Base_DepartmentTree", await GetBase_DepartmentTree());
            ItemSource.Add("Base_Action", await GetBase_Action());
            ItemSource.Add("Base_ActionTree", await GetBase_ActionTree());
            var datas = await GetBase_Dictionary();
            BuildDictionary(ItemSource, Base_Dictionary, datas);
        }

        public static void BuildDictionary(Dictionary<string, ObservableCollection<ISelectOption>> items, Dictionary<string, DictionaryTreeModel> dics, IEnumerable<DictionaryTreeModel> trees)
        {
            foreach (var tree in trees)
            {
                if (tree.Type == 0)
                {
                    dics.Add(tree.Value, tree);
                }

                if (tree.Children?.Count > 0)
                {
                    var datas = tree.Children.Where(p => p.Type == 1);
                    if (datas.Count() > 0)
                    {
                        items.Add(tree.Value, new ObservableCollection<ISelectOption>(datas.Select(p => new SelectOption() { Value = p.Value, Text = p.Text })));
                    }
                   
                    BuildDictionary(items, dics, tree.Children);                    
                }
            }
        }

      
    }
}