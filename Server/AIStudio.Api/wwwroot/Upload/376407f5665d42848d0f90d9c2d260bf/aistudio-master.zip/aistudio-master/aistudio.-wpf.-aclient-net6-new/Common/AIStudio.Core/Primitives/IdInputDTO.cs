﻿namespace AIStudio.Core
{
    public class IdInputDTO
    {
        /// <summary>
        /// id
        /// </summary>
        public string id { get; set; }
    }
}
