﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIStudio.Wpf.Entity.Models
{
    /// <summary>
    /// 
    /// </summary>
    [Table("Base_CustomerRecord")]
    public class Base_CustomerRecord
    {

        /// <summary>
        /// 店铺
        /// </summary>
        public String Shop { get; set; }

        /// <summary>
        /// 旺旺
        /// </summary>
        public String Wangwang { get; set; }

        /// <summary>
        /// 客户
        /// </summary>
        public String Customer { get; set; }

        /// <summary>
        /// 操作人标识
        /// </summary>
        public String UserSign { get; set; }

        /// <summary>
        /// Id
        /// </summary>
         [Key, Column(Order = 6)]
        public String Id { get; set; }

    }
}