using System.Reflection;

[assembly: AssemblyDescription("")]

[assembly: NUnit.Framework.Apartment(System.Threading.ApartmentState.STA)]