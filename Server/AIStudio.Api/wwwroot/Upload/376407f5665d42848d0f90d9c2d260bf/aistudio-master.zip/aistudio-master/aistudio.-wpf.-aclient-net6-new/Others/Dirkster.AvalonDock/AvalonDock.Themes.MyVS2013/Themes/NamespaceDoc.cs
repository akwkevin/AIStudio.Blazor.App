namespace AvalonDock.Themes.Themes
{
	/// <summary>This namespace defines the theme specific resources for this theme in AvalonDock.</summary>
	[System.Runtime.CompilerServices.CompilerGenerated]
	internal class NamespaceDoc
	{
	}
}
