﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIStudio.Wpf.Entity.Models
{
    /// <summary>
    /// 
    /// </summary>
    [Table("Base_YunData")]
    public class Base_YunData
    {

        /// <summary>
        /// 日期
        /// </summary>
        public DateTime? OrderDate { get; set; }

        /// <summary>
        /// 单号
        /// </summary>
        public String OrderNo { get; set; }

        /// <summary>
        /// 客户
        /// </summary>
        public String Customer { get; set; }

        /// <summary>
        /// 店铺
        /// </summary>
        public String Shop { get; set; }

        /// <summary>
        /// 操作人标识
        /// </summary>
        public String UserSign { get; set; }

        /// <summary>
        /// Id
        /// </summary>
        [Key, Column(Order = 6)]
        public String Id { get; set; }

        /// <summary>
        /// Deleted
        /// </summary>
        public Boolean? Deleted { get; set; }

        /// <summary>
        /// ModifyTime
        /// </summary>
        public DateTime? ModifyTime { get; set; }

        /// <summary>
        /// ModifyId
        /// </summary>
        public String ModifyId { get; set; }

        /// <summary>
        /// ModifyName
        /// </summary>
        public String ModifyName { get; set; }

        /// <summary>
        /// CreateTime
        /// </summary>
        public DateTime? CreateTime { get; set; }

        /// <summary>
        /// CreatorId
        /// </summary>
        public String CreatorId { get; set; }

        /// <summary>
        /// CreatorName
        /// </summary>
        public String CreatorName { get; set; }

        /// <summary>
        /// TenantId
        /// </summary>
        public String TenantId { get; set; }

    }
}