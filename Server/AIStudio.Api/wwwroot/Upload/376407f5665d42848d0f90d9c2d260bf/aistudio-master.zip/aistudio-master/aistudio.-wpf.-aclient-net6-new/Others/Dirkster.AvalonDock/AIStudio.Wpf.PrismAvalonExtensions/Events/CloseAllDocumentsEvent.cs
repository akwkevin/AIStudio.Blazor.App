﻿using Prism.Events;

namespace AIStudio.Wpf.PrismAvalonExtensions.Events
{
    public class CloseAllDocumentsEvent : PubSubEvent<CloseAllDocumentsEventArgs>
    {
    }
}
