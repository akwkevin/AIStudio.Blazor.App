﻿namespace DragablzDemo
{
    public class HeaderAndContentModel
    {
        public object Header { get; set; }
        public object Content { get; set; }
    }
}