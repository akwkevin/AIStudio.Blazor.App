﻿using AIStudio.Wpf.Logical.ViewModels;
using AIStudio.Wpf.DiagramDesigner;

namespace AIStudio.Wpf.Logical.Models
{
    public class LogicalGateItem : LogicalGateDesignerItemBase
    {
        public LogicalGateItem()
        {

        }
        public LogicalGateItem(LogicalGateItemViewModel item) : base(item)
        {

        }     



    }
}
