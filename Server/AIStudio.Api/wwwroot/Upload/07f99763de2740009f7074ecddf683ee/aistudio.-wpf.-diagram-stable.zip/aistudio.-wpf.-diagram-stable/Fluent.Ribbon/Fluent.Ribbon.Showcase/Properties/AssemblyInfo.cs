﻿using System.Reflection;

[assembly: AssemblyDescription("Showcase application for Fluent.Ribbon")]