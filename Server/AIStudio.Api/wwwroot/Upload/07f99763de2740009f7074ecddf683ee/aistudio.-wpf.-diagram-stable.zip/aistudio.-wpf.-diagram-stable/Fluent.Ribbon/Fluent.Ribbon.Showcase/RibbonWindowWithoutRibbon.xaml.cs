﻿using Fluent;

namespace FluentTest
{
    public partial class RibbonWindowWithoutRibbon : RibbonWindow
    {
        public RibbonWindowWithoutRibbon()
        {
            this.InitializeComponent();
        }
    }
}