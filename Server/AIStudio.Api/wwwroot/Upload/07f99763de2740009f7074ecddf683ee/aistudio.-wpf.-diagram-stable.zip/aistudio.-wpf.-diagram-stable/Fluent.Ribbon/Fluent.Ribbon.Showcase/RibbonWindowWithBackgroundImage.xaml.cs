﻿using Fluent;

namespace FluentTest
{
    public partial class RibbonWindowWithBackgroundImage : RibbonWindow
    {
        public RibbonWindowWithBackgroundImage()
        {
            this.InitializeComponent();
        }
    }
}