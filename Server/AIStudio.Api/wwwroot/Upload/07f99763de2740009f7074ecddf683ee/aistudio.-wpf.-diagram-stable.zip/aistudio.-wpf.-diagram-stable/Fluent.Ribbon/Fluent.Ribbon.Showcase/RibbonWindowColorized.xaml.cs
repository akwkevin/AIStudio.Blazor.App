﻿using Fluent;

namespace FluentTest
{
    public partial class RibbonWindowColorized : RibbonWindow
    {
        public RibbonWindowColorized()
        {
            this.InitializeComponent();
        }
    }
}