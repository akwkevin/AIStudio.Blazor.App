namespace FluentTest
{
    using Fluent;

    public partial class TestWindow : RibbonWindow
    {
        public TestWindow()
        {
            this.InitializeComponent();
        }
    }
}