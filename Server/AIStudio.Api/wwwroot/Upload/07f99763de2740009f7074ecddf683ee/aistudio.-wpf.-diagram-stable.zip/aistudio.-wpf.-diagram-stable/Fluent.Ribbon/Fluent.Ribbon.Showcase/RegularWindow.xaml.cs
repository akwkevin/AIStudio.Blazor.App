﻿using System.Windows;

namespace FluentTest
{
    public partial class RegularWindow : Window
    {
        public RegularWindow()
        {
            this.InitializeComponent();
        }
    }
}