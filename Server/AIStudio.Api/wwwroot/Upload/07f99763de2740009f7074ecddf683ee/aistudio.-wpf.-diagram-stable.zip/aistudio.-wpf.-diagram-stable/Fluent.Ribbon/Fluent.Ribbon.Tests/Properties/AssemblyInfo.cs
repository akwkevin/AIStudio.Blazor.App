using System;

[assembly: CLSCompliant(false)]

[assembly: NUnit.Framework.Apartment(System.Threading.ApartmentState.STA)]