using Fluent;

namespace FluentTest
{
    public partial class MinimalWindowSample : RibbonWindow
    {
        public MinimalWindowSample()
        {
            this.InitializeComponent();
        }
    }
}