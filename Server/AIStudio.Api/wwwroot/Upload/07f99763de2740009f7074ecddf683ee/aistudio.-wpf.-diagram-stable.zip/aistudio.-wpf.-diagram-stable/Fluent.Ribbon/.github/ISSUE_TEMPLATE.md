**Place your issue description here.**

**Please do not include large amounts of code in your issue. Please attach a zip file containing a repro instead.**

---
### Environment

- Fluent.Ribbon __v?.?.?__
- Windows __?__
- .NET Framework __?.?__
