﻿using Fluent;

namespace FluentTest
{
    public partial class RibbonWindowWithoutVisibleRibbon : RibbonWindow
    {
        public RibbonWindowWithoutVisibleRibbon()
        {
            this.InitializeComponent();
        }
    }
}