﻿using System.Windows.Controls;

namespace AIStudio.Wpf.DiagramApp.Views
{
    /// <summary>
    /// PropertyControl.xaml 的交互逻辑
    /// </summary>
    public partial class PropertyControl : UserControl
    {
        public PropertyControl()
        {
            InitializeComponent();
        }
    }
}
