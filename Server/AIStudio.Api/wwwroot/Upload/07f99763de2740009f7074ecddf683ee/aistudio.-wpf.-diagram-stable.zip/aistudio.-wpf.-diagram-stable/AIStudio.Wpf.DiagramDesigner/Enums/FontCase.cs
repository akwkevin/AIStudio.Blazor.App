﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AIStudio.Wpf.DiagramDesigner
{

    public enum FontCase
    {
        None,
        Upper,
        Lower,
    }
}
