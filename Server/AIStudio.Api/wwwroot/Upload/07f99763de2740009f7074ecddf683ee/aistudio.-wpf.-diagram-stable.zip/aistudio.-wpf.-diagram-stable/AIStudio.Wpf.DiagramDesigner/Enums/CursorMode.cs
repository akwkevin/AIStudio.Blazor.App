﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AIStudio.Wpf.DiagramDesigner
{
    public enum CursorMode
    {
        Normal = 0,
        Format = 1,
        Move = 2,
    }
}
