﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AIStudio.Wpf.DiagramDesigner
{
    public enum LineDashStyle
    {
        None,
        Dash1,
        Dash2,
        Dash3,
        Dash4,
        Dash5,
        Dash6,
        Dash7,
        Dash8,
        Dash9,
        Dash10,
        Dash11,
        Dash12,
        Dash13,
        Dash14,
        Dash15,
        Dash16,
        Dash17,
        Dash18,
        Dash19,
        Dash20,
        Dash21
    }
}
